# Adventurer — RideStory AI

Ride community app for adventure riders (India-focused), now with a working **RideStory AI Studio**:
long ride footage → scored moments → a rendered highlight reel → an AI travel story.

## Quick start

```bash
npm install
cp .env.example .env      # add MODEL_API_KEY to enable Meta AI (optional)
npm run dev               # starts the API server (:8787) and the web app (:3000)
```

Open http://localhost:3000 and click **Studio** in the header.

Production: `npm run build && npm start` — the server hosts the built app and the API on port 8787.

Requirements: Node.js 20+. Install **FFmpeg** for fast 1080p server rendering (optional — the browser can render too).

## What the Studio does

| Step | Runs where | Needs |
|---|---|---|
| **Capture** — record from phone/helmet camera, tap *Mark moment* (or press M) | Browser | Camera permission |
| **Analyse** — samples up to ~320 frames, scores colour, motion, sharpness, open sky, greenery, golden-hour light; detects scene cuts; penalises dark/idle/shaky footage; picks the best non-overlapping clips for the target length (30 s – 3 min) | Browser (video never uploaded) | — |
| **Enhance with Meta AI** — sends keyframes only to a vision model that labels, scores and flags faces/licence plates | Server → Meta Model API | `MODEL_API_KEY` |
| **Render in browser** — title card, clips with lower-thirds, end card, original audio; MP4 (H.264) or WebM | Browser (real-time) | Chrome/Edge/Firefox |
| **Render 1080p MP4 on server** — 16:9 or 9:16, title overlay | Server FFmpeg | FFmpeg installed |
| **Story** — caption, hashtags, diary, chapters in reel time, voice-over script in English/Hindi/Tamil/Marathi/Bengali; read aloud with speech synthesis | Server → Meta Model API (offline template fallback) | `MODEL_API_KEY` for AI writing |

## Server API (`server/index.mjs`, zero npm dependencies)

- `GET  /api/health` — model + FFmpeg availability
- `POST /api/ai` — `{system, prompt, json?, schema?}` → `{text}` (route planner, safety tips, ride insights)
- `POST /api/story/moments` — `{location, moments:[{id,time,image}]}` → AI labels/scores/privacy flags
- `POST /api/story/write` — moments → caption, diary, hashtags, chapters, narration
- `POST /api/render` — raw video body + `X-Render-Plan` header (base64 JSON) → MP4

Model calls use the OpenAI-compatible chat-completions format. The default is Meta Model API
(`https://api.meta.ai/v1`, `muse-spark-1.3`). Any OpenAI-compatible host serving Meta open-weights models
(Fireworks, Baseten, Modal) works by changing `MODEL_API_BASE_URL` / `MODEL_TEXT` / `MODEL_VISION`.
Check the hackathon docs for the current model IDs.

## Honest limits

- Scene scoring is signal-based computer vision, not semantic understanding; *Enhance with Meta AI* adds the semantic layer.
- Browser rendering records in real time (a 2-minute reel takes ~2 minutes); keep the tab visible.
- Capture records locally. Public live broadcasting needs a streaming ingest service (WebRTC/RTMP) and is not included.
- Face/plate detection only *flags* moments; automatic blurring is not implemented yet.
- Other screens (feeds, clubs, radar, expeditions) still use sample data.
- Keys stay server-side: never put them in `VITE_*` variables and never commit `.env`.
