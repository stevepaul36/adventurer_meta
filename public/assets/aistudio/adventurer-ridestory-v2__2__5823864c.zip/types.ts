// FIX: Import ComponentType from 'react' to resolve 'Cannot find namespace React' errors.
import type { ComponentType } from 'react';

export interface User {
  id: string;
  name: string;
  avatarUrl: string;
}

export interface RideStats {
  distance: number;
  duration: string;
  elevation: number;
}

export interface Comment {
  id: string;
  user: User;
  text: string;
}

export interface Post {
  id: string;
  user: User;
  timestamp: string;
  date: Date;
  caption: string;
  imageUrl?: string;
  rideStats?: RideStats;
  likes: number;
  comments: Comment[];
}

export interface Streamer extends User {}

export interface Stream {
    id:string;
    title: string;
    thumbnailUrl: string;
    streamer: Streamer;
    isLive: boolean;
    viewers: number;
}

export interface ChatMessage {
    id: string;
    user: User;
    message: string;
    isReaction: boolean;
}

export interface Shot {
    id: string;
    user: User;
    videoUrl: string; // Will use an image URL as a placeholder
    caption: string;
    likes: number;
    comments: Comment[];
    shares: number;
}

export interface Message {
    id: string;
    sender: User;
    text: string;
    timestamp: string;
    isRead: boolean;
}

export interface Conversation {
    id: string;
    participant: User;
    lastMessage: Message;
}

export interface Event {
    title: string;
    date: string;
}

export interface Notification {
    id: string;
    type: 'like' | 'comment' | 'follow' | 'event';
    user: User;
    timestamp: string;
    post?: {
        imageUrl: string;
    };
    event?: Event;
}

export interface AI_Route {
    title: string;
    description: string;
    distance: string;
    duration: string;
    waypoints: string[];
}

export interface Profile {
  id: string;
  user: User;
  bio: string;
  stats: {
    rides: number;
    friends: number;
  };
  friends: string[]; // Array of user IDs
}

export interface Activity {
  id: string;
  type: 'ride' | 'post';
  timestamp: string;
  title: string;
  details: string;
  imageUrl?: string;
}

export interface Journey {
    id: string;
    title: string;
    distance: number; // in km
    duration: string; // as a string like "3h 15m"
    elevation: number; // in meters
}

export interface Achievement {
    id: string;
    name: string;
    description: string;
    // FIX: Replaced React.ComponentType with the imported ComponentType to fix missing namespace error.
    icon: ComponentType<{ className?: string }>;
}

export type BadgeTier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum';

export type ActivityType = 'Motorcycling' | 'Cycling' | 'Walking' | 'Trekking/Hiking' | 'Car Trips' | 'Hybrid';

export interface Badge {
  id: string;
  activityType: ActivityType;
  name: string;
  tier: BadgeTier;
  description: string;
  // FIX: Replaced React.ComponentType with the imported ComponentType to fix missing namespace error.
  icon: ComponentType<{ className?: string }>;
}


export interface RidingGoal {
    id: string;
    name: string;
    target: number;
    type: 'distance' | 'elevation' | 'count';
    // FIX: Replaced React.ComponentType with the imported ComponentType to fix missing namespace error.
    icon: ComponentType<{ className?: string }>;
}

export interface RideShare {
  id: string;
  user: User;
  timestamp: string;
  date: Date;
  title: string;
  mapImageUrl: string;
  rideStats: RideStats;
  likes: number;
  comments: Comment[];
}

export type FeedItem = 
  | { type: 'post'; data: Post; }
  | { type: 'ride_share'; data: RideShare; }
  | { type: 'ride_story'; data: RideStory; };
  
export interface SavedRide {
  id: string;
  date: string;
  title: string;
  distance: number; // in km
  duration: string; // as a string like "1h 34m"
  mapImageUrl: string;
}

export interface LeaderboardEntry {
  user: User;
  rank: number;
  value: number;
}

export interface RideAnalysisStats {
  distance: number;
  duration: string;
  speed: number;
}

// --- Club System Types ---

export interface ClubMember {
    user: User;
    role: 'Admin' | 'Member';
}

export interface ClubGoal {
    id: string;
    name: string;
    description: string;
    target: number;
    current: number;
    type: 'distance' | 'elevation' | 'rides';
    // FIX: Replaced React.ComponentType with the imported ComponentType to fix missing namespace error.
    icon: ComponentType<{ className?: string }>;
}

export interface ClubAchievement {
    id: string;
    name: string;
    description: string;
    isUnlocked: boolean;
    // FIX: Replaced React.ComponentType with the imported ComponentType to fix missing namespace error.
    icon: ComponentType<{ className?: string }>;
}

export interface ClubChatMessage {
    id: string;
    user: User;
    text: string;
    timestamp: string;
}

export interface Club {
    id: string;
    name: string;
    badgeUrl: string;
    description: string;
    memberCount: number;
    isPrivate: boolean;
    members: ClubMember[];
    goals: ClubGoal[];
    achievements: ClubAchievement[];
    chat: ClubChatMessage[];
}

// --- Ride Story Types ---
export type StoryPost = (Post | RideShare) & {
    mapPosition: { x: number; y: number }; // Position on a relative map canvas (e.g., 0-100)
};

export interface RideStory {
    id: string;
    user: User;
    title: string;
    description: string;
    coverImageUrl: string;
    date: Date;
    storyPosts: StoryPost[];
    routePath: string; // SVG path data for the route line
}

export interface FriendRequest {
    id: string;
    from: User;
    timestamp: string;
}

// --- Challenges ---
export interface CommunityChallenge {
    id: string;
    title: string;
    description: string;
    type: 'distance' | 'elevation' | 'rides';
    goal: number;
    userProgress: number; // For the current user
    participants: number;
    timeframe: 'Weekly' | 'Monthly';
    icon: ComponentType<{ className?: string }>;
}

export interface ClubChallenge {
    id: string;
    title: string;
    description: string;
    type: 'distance' | 'elevation' | 'rides';
    goal: number;
    competingClubs: {
        clubId: string;
        progress: number;
    }[];
    startDate: Date;
    endDate: Date;
    winnerClubId?: string;
}