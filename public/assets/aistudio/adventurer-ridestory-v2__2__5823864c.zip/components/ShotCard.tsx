
import React, { useState } from 'react';
import type { Shot, Comment } from '../types';
import { HeartIcon, CommentIcon, ShareIcon, SendIcon } from './icons';
import { CURRENT_USER } from '../constants';

const CloseIcon: React.FC<{className?: string}> = (props) => (
    <svg {...props} xmlns="http://www.w.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const CommentsPanel: React.FC<{
    comments: Comment[];
    commentCount: number;
    onClose: () => void;
    onUserSelect: (userId: string) => void;
    onAddComment: (text: string) => void;
}> = ({ comments, commentCount, onClose, onUserSelect, onAddComment }) => {
    const [newComment, setNewComment] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim()) {
            onAddComment(newComment.trim());
            setNewComment('');
        }
    };

    return (
        <div className="absolute inset-0 bg-black/70 z-20 flex flex-col justify-end animate-fade-in" onClick={onClose}>
            <div 
                className="bg-slate-900 rounded-t-2xl h-[60vh] max-h-[600px] flex flex-col animate-slide-up"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="p-4 border-b border-slate-800 text-center relative flex-shrink-0">
                    <h3 className="font-bold text-white">{commentCount.toLocaleString()} Comments</h3>
                    <button onClick={onClose} className="absolute top-1/2 -translate-y-1/2 right-4 text-gray-400 hover:text-white p-1">
                        <CloseIcon className="w-6 h-6"/>
                    </button>
                </div>
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {comments.length > 0 ? comments.map(comment => (
                        <div key={comment.id} className="flex items-start space-x-3">
                            <button onClick={() => onUserSelect(comment.user.id)}>
                               <img src={comment.user.avatarUrl} alt={comment.user.name} className="w-8 h-8 rounded-full"/>
                            </button>
                            <div className="flex-1">
                                <button onClick={() => onUserSelect(comment.user.id)} className="font-semibold text-xs text-gray-400 hover:underline">{comment.user.name}</button>
                                <p className="text-sm text-gray-200">{comment.text}</p>
                            </div>
                        </div>
                    )) : (
                        <p className="text-center text-sm text-gray-500 pt-8">No comments yet. Be the first!</p>
                    )}
                </div>
                <form onSubmit={handleSubmit} className="p-4 border-t border-slate-800 flex items-center space-x-3 flex-shrink-0 bg-slate-900">
                    <img src={CURRENT_USER.avatarUrl} alt={CURRENT_USER.name} className="w-8 h-8 rounded-full"/>
                    <div className="flex-1 relative">
                        <input
                            type="text"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder="Add a comment..."
                            className="w-full bg-slate-800 rounded-full py-2 pl-4 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                        />
                        <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-orange-500">
                            <SendIcon className="w-5 h-5" />
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const ActionButton: React.FC<{ 
    icon: React.ReactNode; 
    value: string | number; 
    onClick?: () => void;
    isActive?: boolean;
}> = ({ icon, value, onClick, isActive=false }) => (
    <div className="flex flex-col items-center space-y-1">
        <button 
            onClick={onClick} 
            className={`w-12 h-12 rounded-full bg-black bg-opacity-40 flex items-center justify-center transition-colors ${isActive ? 'text-orange-500' : 'text-white'}`}
        >
            {icon}
        </button>
        <span className="text-sm font-semibold">{value}</span>
    </div>
);

interface ShotCardProps {
    shot: Shot;
    onUserSelect: (userId: string) => void;
}

const ShotCard: React.FC<ShotCardProps> = ({ shot, onUserSelect }) => {
    const [isLiked, setIsLiked] = useState(false);
    const [likeCount, setLikeCount] = useState(shot.likes);
    const [isCommentsOpen, setIsCommentsOpen] = useState(false);
    const [comments, setComments] = useState<Comment[]>(shot.comments);

    const handleLikeClick = () => {
        setIsLiked(!isLiked);
        setLikeCount(prevCount => isLiked ? prevCount - 1 : prevCount + 1);
    };

    const handleAddComment = (text: string) => {
        const newCommentObject: Comment = {
            id: `c-${Date.now()}`,
            user: CURRENT_USER,
            text: text,
        };
        setComments(prevComments => [...prevComments, newCommentObject]);
    };

    return (
        <div className="relative h-full w-full">
            <img src={shot.videoUrl} alt={shot.caption} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <div className="flex items-end">
                    <div className="flex-1">
                        <button onClick={() => onUserSelect(shot.user.id)} className="flex items-center space-x-2 mb-2 group">
                            <img src={shot.user.avatarUrl} alt={shot.user.name} className="w-10 h-10 rounded-full border-2 border-white group-hover:border-orange-500 transition-colors"/>
                            <p className="font-bold group-hover:text-orange-400 transition-colors">{shot.user.name}</p>
                        </button>
                        <p className="text-sm">{shot.caption}</p>
                    </div>
                  
                    <div className="flex flex-col space-y-4">
                        <ActionButton 
                            icon={<HeartIcon className="w-7 h-7" fill={isLiked ? 'currentColor' : 'none'}/>} 
                            value={likeCount.toLocaleString()} 
                            onClick={handleLikeClick}
                            isActive={isLiked}
                        />
                        <ActionButton 
                            icon={<CommentIcon className="w-7 h-7"/>} 
                            value={comments.length.toLocaleString()} 
                            onClick={() => setIsCommentsOpen(true)}
                        />
                        <ActionButton 
                            icon={<ShareIcon className="w-7 h-7"/>} 
                            value={shot.shares.toLocaleString()} 
                            onClick={() => alert('Sharing is not implemented yet!')}
                        />
                    </div>
                </div>
            </div>
            {isCommentsOpen && (
                <CommentsPanel 
                    comments={comments} 
                    commentCount={comments.length}
                    onClose={() => setIsCommentsOpen(false)} 
                    onUserSelect={(userId) => {
                        setIsCommentsOpen(false); // Close panel before navigating
                        onUserSelect(userId);
                    }} 
                    onAddComment={handleAddComment}
                />
            )}
        </div>
    );
};

export default ShotCard;