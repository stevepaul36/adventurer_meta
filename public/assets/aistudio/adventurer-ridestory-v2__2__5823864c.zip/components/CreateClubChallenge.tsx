import React, { useState } from 'react';
import type { Club } from '../types';
import { CLUBS } from '../constants';
import { XIcon, SwordsIcon } from './icons';

interface CreateClubChallengeProps {
    club: Club;
    onBack: () => void;
    // In a real app, this would take the form data
    onCreateChallenge: () => void;
}

type ChallengeType = 'distance' | 'elevation' | 'rides';
type Duration = '1 week' | '2 weeks' | '1 month';

const CreateClubChallenge: React.FC<CreateClubChallengeProps> = ({ club, onBack, onCreateChallenge }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [challengeType, setChallengeType] = useState<ChallengeType>('distance');
    const [goal, setGoal] = useState('');
    const [duration, setDuration] = useState<Duration>('1 week');
    const [opponentClubId, setOpponentClubId] = useState('');

    const opponentClubs = CLUBS.filter(c => c.id !== club.id);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Basic validation
        if (!title || !goal || !opponentClubId) {
            alert('Please fill out all required fields.');
            return;
        }
        // In a real app, you would pass this data up
        console.log({
            title,
            description,
            challengeType,
            goal: Number(goal),
            duration,
            opponentClubId
        });
        onCreateChallenge();
    };
    
    const typeOptions: {id: ChallengeType, label: string}[] = [
        {id: 'distance', label: 'Total Distance (km)'},
        {id: 'elevation', label: 'Total Elevation (m)'},
        {id: 'rides', label: 'Total Rides'},
    ];

    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center animate-fade-in" onClick={onBack}>
            <div 
                className="bg-slate-900 rounded-lg shadow-xl w-full max-w-lg m-4 border border-slate-700"
                onClick={e => e.stopPropagation()}
            >
                <form onSubmit={handleSubmit}>
                    <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                        <h2 className="text-xl font-bold text-white flex items-center"><SwordsIcon className="w-5 h-5 mr-2"/> Create a Club Challenge</h2>
                        <button type="button" onClick={onBack} className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-slate-800"><XIcon className="w-5 h-5"/></button>
                    </div>

                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div>
                            <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-1">Challenge Title</label>
                            <input
                                type="text"
                                id="title"
                                value={title}
                                onChange={e => setTitle(e.target.value)}
                                placeholder="e.g., The Great Mileage Race"
                                className="w-full bg-slate-800 border border-slate-700 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-1">Description</label>
                            <textarea
                                id="description"
                                value={description}
                                onChange={e => setDescription(e.target.value)}
                                placeholder="A short, fun description for the challenge."
                                className="w-full h-20 bg-slate-800 border border-slate-700 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                            />
                        </div>

                         <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Challenge Type</label>
                            <div className="grid grid-cols-3 gap-2">
                                {typeOptions.map(opt => (
                                    <button
                                        type="button"
                                        key={opt.id}
                                        onClick={() => setChallengeType(opt.id)}
                                        className={`p-2 text-sm rounded-md border-2 transition-colors ${challengeType === opt.id ? 'bg-orange-600 border-orange-500 text-white' : 'bg-slate-800 border-slate-700 text-gray-300 hover:border-orange-600'}`}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="goal" className="block text-sm font-medium text-gray-300 mb-1">Goal</label>
                                <input
                                    type="number"
                                    id="goal"
                                    value={goal}
                                    onChange={e => setGoal(e.target.value)}
                                    placeholder="e.g., 10000"
                                    className="w-full bg-slate-800 border border-slate-700 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor="duration" className="block text-sm font-medium text-gray-300 mb-1">Duration</label>
                                <select id="duration" value={duration} onChange={e => setDuration(e.target.value as Duration)} className="w-full bg-slate-800 border border-slate-700 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500">
                                    <option>1 week</option>
                                    <option>2 weeks</option>
                                    <option>1 month</option>
                                </select>
                            </div>
                        </div>

                        <div>
                             <label htmlFor="opponent" className="block text-sm font-medium text-gray-300 mb-1">Opponent Club</label>
                             <select id="opponent" value={opponentClubId} onChange={e => setOpponentClubId(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500" required>
                                <option value="">Select an opponent...</option>
                                {opponentClubs.map(op => <option key={op.id} value={op.id}>{op.name}</option>)}
                            </select>
                        </div>

                    </div>

                    <div className="p-4 border-t border-slate-800">
                        <button
                            type="submit"
                            className="w-full bg-orange-600 text-white font-bold py-2 px-6 rounded-full hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2 disabled:bg-slate-600"
                            disabled={!title || !goal || !opponentClubId}
                        >
                           <SwordsIcon className="w-5 h-5"/>
                           <span>Send Challenge</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateClubChallenge;