
import React from 'react';
import { NOTIFICATIONS } from '../constants';
import type { Notification } from '../types';
import { HeartIcon, CommentIcon, ProfileIcon } from './icons';

const NotificationItem: React.FC<{ notification: Notification }> = ({ notification }) => {
    let icon, text;

    switch (notification.type) {
        case 'like':
            icon = <HeartIcon className="w-5 h-5 text-red-500" />;
            text = <><strong>{notification.user.name}</strong> liked your post.</>;
            break;
        case 'comment':
            icon = <CommentIcon className="w-5 h-5 text-blue-500" />;
            text = <><strong>{notification.user.name}</strong> commented on your post.</>;
            break;
        case 'follow':
            icon = <ProfileIcon className="w-5 h-5 text-green-500" />;
            text = <><strong>{notification.user.name}</strong> started following you.</>;
            break;
        case 'event':
            icon = <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-orange-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg>;
            text = <>Reminder: <strong>{notification.event?.title}</strong> is {notification.event?.date}.</>;
            break;
    }

    return (
        <div className="flex items-start p-4 space-x-4 border-b border-slate-800">
            <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center flex-shrink-0">
                {icon}
            </div>
            <div className="flex-1">
                <p className="text-gray-300">{text}</p>
                <p className="text-sm text-gray-500">{notification.timestamp}</p>
            </div>
            {notification.post?.imageUrl && (
                 <img src={notification.post.imageUrl} alt="post" className="w-16 h-16 rounded-lg object-cover"/>
            )}
        </div>
    );
};

const NotificationsPanel: React.FC = () => {
  return (
    <div className="bg-slate-900 rounded-lg overflow-hidden mb-20 md:mb-0">
        <div className="p-4 border-b border-slate-800">
            <h2 className="text-2xl font-bold text-white">Notifications</h2>
        </div>
        <div>
            {NOTIFICATIONS.map(notif => (
                <NotificationItem key={notif.id} notification={notif} />
            ))}
        </div>
    </div>
  );
};

export default NotificationsPanel;
