
import React, { useState, useEffect } from 'react';
import { generateSafetyTip } from '../services/aiService';
import { LightBulbIcon } from './icons';

const SafetyTipsPanel: React.FC = () => {
    const [tip, setTip] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [currentContext, setCurrentContext] = useState<string>('General');

    const fetchTip = async (context?: string) => {
        setIsLoading(true);
        setError(null);
        setCurrentContext(context || 'General');
        try {
            const newTip = await generateSafetyTip(context);
            setTip(newTip);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
            setTip(null);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchTip(); // Fetch a general tip on initial load
    }, []);

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex items-center justify-center h-24 text-center">
                    <div>
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto"></div>
                        <p className="text-sm text-gray-400 mt-2">Getting {currentContext} tip...</p>
                    </div>
                </div>
            );
        }

        if (error) {
            return (
                <div className="text-center text-red-400">
                    <p>Could not load tip.</p>
                    <p className="text-sm">{error}</p>
                </div>
            );
        }

        if (tip) {
            return (
                <p className="text-gray-300 italic text-center">"{tip}"</p>
            );
        }

        return null;
    };
    
    const TipButton: React.FC<{ context: string }> = ({ context }) => (
      <button
          onClick={() => fetchTip(context)}
          disabled={isLoading}
          className="flex-1 bg-slate-800 text-orange-400 font-semibold py-2 px-3 rounded-lg hover:bg-slate-700 transition-colors text-xs disabled:opacity-50"
      >
        {context}
      </button>
    );

    return (
        <div className="bg-slate-900 rounded-lg p-4 shadow-lg">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <LightBulbIcon className="w-6 h-6 mr-2 text-yellow-400" />
                AI Safety Tip
            </h3>
            <div className="min-h-[8rem] flex items-center justify-center mb-4 p-3 bg-slate-800/50 rounded-md">
                 {renderContent()}
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2">
                <TipButton context="Long Trip" />
                <TipButton context="City Riding" />
                <TipButton context="Night Ride" />
            </div>
        </div>
    );
};

export default SafetyTipsPanel;