
import React, { useState, useRef } from 'react';
import type { Post } from '../types';
import { CURRENT_USER } from '../constants';
import { PhotoIcon, RoadIcon } from './icons';

interface CreatePostProps {
    onAddPost: (post: Post) => void;
    onBack: () => void;
}

const CreatePost: React.FC<CreatePostProps> = ({ onAddPost, onBack }) => {
    const [caption, setCaption] = useState('');
    const [imageSrc, setImageSrc] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [showStats, setShowStats] = useState(false);
    const [distance, setDistance] = useState('');
    const [duration, setDuration] = useState('');
    const [elevation, setElevation] = useState('');

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = (e) => {
                setImageSrc(e.target?.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleAddPhotoClick = () => {
        fileInputRef.current?.click();
    };

    const handleRemoveImage = () => {
        setImageSrc(null);
        if(fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleSubmit = () => {
        if (!caption.trim() && !imageSrc) {
            // Prevent empty posts
            return;
        }

        const rideStats = distance || duration || elevation
            ? {
                distance: Number(distance) || 0,
                duration: duration || '0m',
                elevation: Number(elevation) || 0,
            }
            : undefined;

        const newPost: Post = {
            id: `post-${Date.now()}`,
            user: CURRENT_USER,
            timestamp: 'Just now',
            date: new Date(),
            caption: caption,
            imageUrl: imageSrc || undefined,
            likes: 0,
            comments: [],
            rideStats: rideStats,
        };

        onAddPost(newPost);
        onBack();
    };

    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center animate-fade-in" onClick={onBack}>
            <div className="bg-slate-900 rounded-lg shadow-xl w-full max-w-lg m-4" onClick={(e) => e.stopPropagation()}>
                <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                    <h2 className="text-xl font-bold text-white">Create Post</h2>
                    <button onClick={onBack} className="text-gray-400 hover:text-white">&times;</button>
                </div>
                <div className="p-4">
                    <div className="flex items-start space-x-3">
                        <img src={CURRENT_USER.avatarUrl} alt={CURRENT_USER.name} className="w-12 h-12 rounded-full" />
                        <div className="flex-1">
                            <p className="font-bold text-white">{CURRENT_USER.name}</p>
                            <textarea
                                value={caption}
                                onChange={(e) => setCaption(e.target.value)}
                                placeholder="What's on your mind?"
                                className="w-full h-28 bg-transparent text-gray-200 resize-none focus:outline-none text-lg"
                            />
                        </div>
                    </div>

                    {imageSrc && (
                        <div className="mt-4 relative">
                            <img src={imageSrc} alt="Preview" className="w-full rounded-lg max-h-80 object-contain" />
                            <button 
                                onClick={handleRemoveImage}
                                className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1.5 hover:bg-black/80"
                                aria-label="Remove image"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                        </div>
                    )}
                    
                    {showStats && (
                        <div className="mt-4 p-4 bg-slate-800/50 rounded-lg space-y-3 animate-fade-in">
                            <h4 className="font-semibold text-white">Ride Stats</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <div>
                                    <label htmlFor="distance" className="block text-xs text-gray-400 mb-1">Distance (km)</label>
                                    <input
                                        type="number"
                                        id="distance"
                                        value={distance}
                                        onChange={e => setDistance(e.target.value)}
                                        placeholder="e.g., 125"
                                        className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="duration" className="block text-xs text-gray-400 mb-1">Duration</label>
                                    <input
                                        type="text"
                                        id="duration"
                                        value={duration}
                                        onChange={e => setDuration(e.target.value)}
                                        placeholder="e.g., 3h 15m"
                                        className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="elevation" className="block text-xs text-gray-400 mb-1">Elevation (m)</label>
                                    <input
                                        type="number"
                                        id="elevation"
                                        value={elevation}
                                        onChange={e => setElevation(e.target.value)}
                                        placeholder="e.g., 1200"
                                        className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                                    />
                                </div>
                            </div>
                        </div>
                    )}
                </div>
                <div className="p-4 border-t border-slate-800 flex justify-between items-center">
                    <div className="flex items-center space-x-1">
                        <input
                            type="file"
                            accept="image/*"
                            ref={fileInputRef}
                            onChange={handleImageChange}
                            className="hidden"
                        />
                        <button
                            onClick={handleAddPhotoClick}
                            className="p-2 rounded-full hover:bg-slate-800 text-gray-400 hover:text-orange-500 transition-colors"
                            aria-label="Add photo"
                        >
                            <PhotoIcon className="w-6 h-6" />
                        </button>
                        <button
                            onClick={() => setShowStats(!showStats)}
                            className={`p-2 rounded-full hover:bg-slate-800 transition-colors ${showStats ? 'bg-orange-900/50 text-orange-400' : 'text-gray-400 hover:text-orange-500'}`}
                            aria-label="Add ride stats"
                        >
                            <RoadIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <button
                        onClick={handleSubmit}
                        disabled={!caption.trim() && !imageSrc}
                        className="bg-orange-600 text-white font-bold py-2 px-6 rounded-full hover:bg-orange-700 transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed"
                    >
                        Post
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CreatePost;
