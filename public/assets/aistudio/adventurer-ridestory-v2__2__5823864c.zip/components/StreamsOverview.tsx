import React from 'react';
import { STREAMS } from '../constants';

interface StreamsOverviewProps {
    onShowStreams: () => void;
}

const StreamsOverview: React.FC<StreamsOverviewProps> = ({ onShowStreams }) => {
    const liveStreams = STREAMS.filter(s => s.isLive);
    
    if (liveStreams.length === 0) {
        return null; // Don't show the component if no one is live
    }

    return (
        <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-white">Live Now</h3>
                <button onClick={onShowStreams} className="text-sm font-semibold text-orange-400 hover:text-orange-300">
                    View All
                </button>
            </div>
            <div className="flex space-x-4 overflow-x-auto pb-2 scrollbar-hide">
                {liveStreams.map(stream => (
                    <div 
                        key={stream.id} 
                        onClick={onShowStreams} 
                        className="relative w-60 h-36 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer group shadow-lg"
                    >
                        <img 
                            src={stream.thumbnailUrl} 
                            alt={stream.title} 
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                        <div className="absolute top-2 left-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-md animate-pulse">
                            LIVE
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 p-2 text-white">
                            <div className="flex items-center space-x-2">
                                <img src={stream.streamer.avatarUrl} alt={stream.streamer.name} className="w-8 h-8 rounded-full border-2 border-slate-700"/>
                                <div>
                                    <p className="text-sm font-semibold truncate group-hover:text-orange-300 transition-colors">{stream.title}</p>
                                    <p className="text-xs text-gray-300 truncate">{stream.streamer.name}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StreamsOverview;
