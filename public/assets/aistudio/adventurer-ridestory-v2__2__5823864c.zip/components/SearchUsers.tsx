import React, { useState, useEffect, useRef } from 'react';
import { USERS } from '../constants';
import type { User } from '../types';
import { MicrophoneIcon } from './icons';

// For browser compatibility
// FIX: Cast window to `any` to access non-standard `SpeechRecognition` properties.
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const isSpeechRecognitionSupported = !!SpeechRecognition;

interface SearchUsersProps {
    onUserSelect: (userId: string) => void;
}

const SearchUsers: React.FC<SearchUsersProps> = ({ onUserSelect }) => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<User[]>([]);
    const [isFocused, setIsFocused] = useState(false);
    const [isListening, setIsListening] = useState(false);
    const searchRef = useRef<HTMLDivElement>(null);
    const recognitionRef = useRef<any>(null);

    const showResults = isFocused && results.length > 0;

    useEffect(() => {
        if (query.trim() === '') {
            setResults([]);
            return;
        }

        const allUsers = Object.values(USERS);
        const filteredUsers = allUsers.filter(user =>
            user.name.toLowerCase().includes(query.toLowerCase())
        );
        setResults(filteredUsers);
    }, [query]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
                setIsFocused(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleUserClick = (userId: string) => {
        onUserSelect(userId);
        setQuery('');
        setResults([]);
        setIsFocused(false);
    };

    const handleVoiceSearch = () => {
        if (!isSpeechRecognitionSupported) {
            alert("Sorry, your browser doesn't support voice search.");
            return;
        }

        if (isListening) {
            recognitionRef.current?.stop();
            setIsListening(false);
            return;
        }
        
        const recognition = new SpeechRecognition();
        recognitionRef.current = recognition;
        
        recognition.onstart = () => setIsListening(true);
        recognition.onend = () => setIsListening(false);
        recognition.onerror = (event: any) => {
            console.error('Speech recognition error:', event.error);
            setIsListening(false);
        };
        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            setQuery(transcript);
        };

        recognition.start();
    };

    return (
        <div className="relative mb-6" ref={searchRef}>
            <div className="relative">
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="absolute top-1/2 left-4 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    aria-hidden="true"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                </svg>
                <input
                    type="text"
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    onFocus={() => setIsFocused(true)}
                    placeholder="Search for riders..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-full py-3 pl-12 pr-12 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    role="combobox"
                    aria-autocomplete="list"
                    aria-haspopup="listbox"
                    aria-expanded={showResults}
                    aria-controls="search-results-listbox"
                />
                {isSpeechRecognitionSupported && (
                     <button 
                        onClick={handleVoiceSearch}
                        className={`absolute top-1/2 right-4 -translate-y-1/2 p-1 rounded-full transition-colors ${isListening ? 'text-orange-500 animate-pulse' : 'text-gray-400 hover:text-white'}`}
                        aria-label="Search by voice"
                     >
                        <MicrophoneIcon className="w-5 h-5"/>
                    </button>
                )}
            </div>
            {showResults && (
                <ul 
                    id="search-results-listbox"
                    role="listbox"
                    className="absolute top-full mt-2 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-lg z-10 overflow-hidden animate-fade-in"
                >
                    {results.map(user => (
                        <li key={user.id} role="option" aria-selected="false">
                            <button
                                onClick={() => handleUserClick(user.id)}
                                className="w-full flex items-center p-3 text-left hover:bg-slate-700 transition-colors"
                            >
                                <img src={user.avatarUrl} alt={user.name} className="w-10 h-10 rounded-full mr-3" />
                                <span className="text-white font-medium">{user.name}</span>
                            </button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default SearchUsers;