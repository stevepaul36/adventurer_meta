import React, { useState, useMemo } from 'react';
import { RupeeIcon, XIcon, CheckIcon, ShareIcon } from '../icons';
import type { SupportedLanguage } from '../../services/i18nService';

interface TripBudgetModalProps {
  language: SupportedLanguage;
  onClose: () => void;
}

export const TripBudgetModal: React.FC<TripBudgetModalProps> = ({ onClose }) => {
  const [distanceKm, setDistanceKm] = useState<number>(1240);
  const [bikeMileage, setBikeMileage] = useState<number>(28);
  const [fuelPrice, setFuelPrice] = useState<number>(104);
  const [tollFastag, setTollFastag] = useState<number>(650);
  const [dhabaMealsPerDay, setDhabaMealsPerDay] = useState<number>(750);
  const [tripDays, setTripDays] = useState<number>(8);
  const [stayPerNight, setStayPerNight] = useState<number>(1400);
  const [mechanicKitty, setMechanicKitty] = useState<number>(3000);
  const [ridersCount, setRidersCount] = useState<number>(4);
  const [copiedLink, setCopiedLink] = useState(false);

  // Computations
  const fuelExpense = useMemo(() => {
    const litersNeeded = distanceKm / (bikeMileage || 1);
    return Math.round(litersNeeded * fuelPrice);
  }, [distanceKm, bikeMileage, fuelPrice]);

  const foodExpense = useMemo(() => {
    return dhabaMealsPerDay * tripDays * ridersCount;
  }, [dhabaMealsPerDay, tripDays, ridersCount]);

  const stayExpense = useMemo(() => {
    // Shared rooms (assuming 2 per room)
    const roomsNeeded = Math.ceil(ridersCount / 2);
    return stayPerNight * tripDays * roomsNeeded;
  }, [stayPerNight, tripDays, ridersCount]);

  const totalTripCost = useMemo(() => {
    // Total includes convoy fuel, food, stay, tolls, mechanic kitty
    return fuelExpense * ridersCount + foodExpense + stayExpense + tollFastag * ridersCount + mechanicKitty;
  }, [fuelExpense, ridersCount, foodExpense, stayExpense, tollFastag, mechanicKitty]);

  const costPerRider = useMemo(() => {
    return Math.round(totalTripCost / (ridersCount || 1));
  }, [totalTripCost, ridersCount]);

  const upiId = 'apexconvoy@okhdfcbank';
  const upiUri = `upi://pay?pa=${upiId}&pn=ApexMotoConvoy&am=${costPerRider}&cu=INR`;

  const handleCopyUpi = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(upiUri).catch(() => {});
    }
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const applyPreset = (preset: 'leh' | 'ghats' | 'kolli') => {
    if (preset === 'leh') {
      setDistanceKm(1240);
      setTripDays(10);
      setTollFastag(950);
      setStayPerNight(1600);
      setMechanicKitty(4500);
    } else if (preset === 'ghats') {
      setDistanceKm(640);
      setTripDays(4);
      setTollFastag(420);
      setStayPerNight(1200);
      setMechanicKitty(2000);
    } else {
      setDistanceKm(340);
      setTripDays(2);
      setTollFastag(260);
      setStayPerNight(900);
      setMechanicKitty(1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl w-full p-6 shadow-2xl space-y-6 my-8 animate-fadeIn text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <RupeeIcon className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Trip Expense & Group Split Calculator (₹ INR)
              </h2>
              <p className="text-slate-400 text-xs">
                Accurate Indian highway budgeting with fuel, FASTag tolls, dhaba meals, homestays, and UPI split.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 border border-slate-700 hover:border-slate-600 transition-colors"
          >
            <XIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Presets:</span>
          <button
            onClick={() => applyPreset('leh')}
            className="px-3 py-1 text-xs font-semibold rounded-lg bg-slate-800 border border-slate-700 text-amber-300 hover:border-amber-400"
          >
            Ladakh 10-Day (1,240 km)
          </button>
          <button
            onClick={() => applyPreset('ghats')}
            className="px-3 py-1 text-xs font-semibold rounded-lg bg-slate-800 border border-slate-700 text-cyan-300 hover:border-cyan-400"
          >
            Western Ghats 4-Day (640 km)
          </button>
          <button
            onClick={() => applyPreset('kolli')}
            className="px-3 py-1 text-xs font-semibold rounded-lg bg-slate-800 border border-slate-700 text-emerald-300 hover:border-emerald-400"
          >
            Kolli 70 Hairpins Weekend (340 km)
          </button>
        </div>

        {/* Sliders & Inputs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Distance */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400 font-semibold uppercase">Total Route Distance</span>
              <span className="text-amber-400 font-bold">{distanceKm} km</span>
            </div>
            <input
              type="range"
              min={100}
              max={3000}
              step={20}
              value={distanceKm}
              onChange={e => setDistanceKm(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          {/* Riders Count */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400 font-semibold uppercase">Convoy Riders Count</span>
              <span className="text-cyan-400 font-bold">{ridersCount} Riders</span>
            </div>
            <input
              type="range"
              min={1}
              max={15}
              step={1}
              value={ridersCount}
              onChange={e => setRidersCount(Number(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>

          {/* Bike Mileage */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400 font-semibold uppercase">Bike Mileage (Efficiency)</span>
              <span className="text-emerald-400 font-bold">{bikeMileage} km/L</span>
            </div>
            <input
              type="range"
              min={15}
              max={55}
              step={1}
              value={bikeMileage}
              onChange={e => setBikeMileage(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
          </div>

          {/* Fuel Price */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400 font-semibold uppercase">Petrol Price / Litre</span>
              <span className="text-amber-300 font-bold">₹{fuelPrice} / L</span>
            </div>
            <input
              type="range"
              min={95}
              max={115}
              step={1}
              value={fuelPrice}
              onChange={e => setFuelPrice(Number(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>

          {/* Days */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400 font-semibold uppercase">Trip Duration</span>
              <span className="text-purple-400 font-bold">{tripDays} Days</span>
            </div>
            <input
              type="range"
              min={1}
              max={21}
              step={1}
              value={tripDays}
              onChange={e => setTripDays(Number(e.target.value))}
              className="w-full accent-purple-500"
            />
          </div>

          {/* Stay per Night */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400 font-semibold uppercase">Homestay / Camp per Room</span>
              <span className="text-indigo-400 font-bold">₹{stayPerNight} / night</span>
            </div>
            <input
              type="range"
              min={500}
              max={4000}
              step={100}
              value={stayPerNight}
              onChange={e => setStayPerNight(Number(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>
        </div>

        {/* Cost Breakdown Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">Fuel (Per Bike)</span>
            <span className="text-white font-bold text-base mt-1 block">₹{fuelExpense.toLocaleString()}</span>
            <span className="text-slate-400 text-[10px]">{Math.round(distanceKm / (bikeMileage || 1))} Litres</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">Dhabas & Food (All)</span>
            <span className="text-white font-bold text-base mt-1 block">₹{foodExpense.toLocaleString()}</span>
            <span className="text-slate-400 text-[10px]">₹{dhabaMealsPerDay}/day/rider</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">Stays & Camps (All)</span>
            <span className="text-white font-bold text-base mt-1 block">₹{stayExpense.toLocaleString()}</span>
            <span className="text-slate-400 text-[10px]">Twin sharing rooms</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 block text-[10px] uppercase">Mechanic Emergency Fund</span>
            <span className="text-white font-bold text-base mt-1 block">₹{mechanicKitty.toLocaleString()}</span>
            <span className="text-slate-400 text-[10px]">Common spare fund</span>
          </div>
        </div>

        {/* Total Cost & Per Rider Split Card */}
        <div className="bg-gradient-to-r from-amber-500/10 via-slate-900 to-cyan-500/10 border border-amber-500/30 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
              Convoy Split Calculation
            </span>
            <div className="text-3xl font-black text-white mt-1">
              ₹{costPerRider.toLocaleString()}
              <span className="text-xs text-slate-400 font-normal ml-2">/ rider (Total: ₹{totalTripCost.toLocaleString()})</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Includes individual fuel + equal share of rooms, dhaba meals, FASTags, and mechanic kitty.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={handleCopyUpi}
              className="w-full md:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
            >
              {copiedLink ? <CheckIcon className="w-4 h-4" /> : <ShareIcon className="w-4 h-4" />}
              <span>{copiedLink ? 'UPI Link Copied!' : 'Share UPI Split Link'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
