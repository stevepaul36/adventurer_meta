import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { SparklesIcon, XIcon, PlayIcon, PauseIcon, ShareIcon, CameraIcon, CheckIcon, MapPinIcon, MicrophoneIcon } from '../icons';
import type { SupportedLanguage } from '../../services/i18nService';
import { analyzeVideo, formatTime, type AnalysisResult, type Moment } from '../../services/videoAnalysis';
import { browserCanRender, renderReelInBrowser } from '../../services/reelRenderer';
import {
  getServerHealth, labelMomentsWithAI, renderOnServer, reselect, templateStory, writeStoryWithAI,
  type ServerHealth, type StoryCopy,
} from '../../services/storyApi';

interface AiStoryStudioModalProps {
  language: SupportedLanguage;
  onClose: () => void;
}

type Tab = 'capture' | 'highlights' | 'story';
type Aspect = 'landscape' | 'vertical';

const LANGS: { name: string; code: SupportedLanguage; speech: string }[] = [
  { name: 'English', code: 'en', speech: 'en-IN' },
  { name: 'Hindi', code: 'hi', speech: 'hi-IN' },
  { name: 'Tamil', code: 'ta', speech: 'ta-IN' },
  { name: 'Marathi', code: 'mr', speech: 'mr-IN' },
  { name: 'Bengali', code: 'bn', speech: 'bn-IN' },
];
const TARGETS = [
  { label: '30 sec', value: 30 },
  { label: '1 min', value: 60 },
  { label: '90 sec', value: 90 },
  { label: '2 min', value: 120 },
  { label: '3 min', value: 180 },
];
const TITLE_CARD_SECONDS = 2.5;

const download = (blob: Blob, name: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
};

export const AiStoryStudioModal: React.FC<AiStoryStudioModalProps> = ({ language, onClose }) => {
  const [tab, setTab] = useState<Tab>('highlights');
  const [health, setHealth] = useState<ServerHealth | null>(null);

  // Source + settings
  const [source, setSource] = useState<Blob | null>(null);
  const [sourceName, setSourceName] = useState('');
  const [sourceUrl, setSourceUrl] = useState<string | null>(null);
  const [bookmarks, setBookmarks] = useState<number[]>([]);
  const [title, setTitle] = useState('My ride, my story');
  const [location, setLocation] = useState('Western Ghats, India');
  const [storyLanguage, setStoryLanguage] = useState(LANGS.find(l => l.code === language)?.name ?? 'English');
  const [target, setTarget] = useState(60);
  const [aspect, setAspect] = useState<Aspect>('landscape');

  // Analysis
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [busy, setBusy] = useState<null | 'analyze' | 'ai' | 'render' | 'write'>(null);
  const [progress, setProgress] = useState({ value: 0, stage: '' });
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  // Preview + output
  const previewRef = useRef<HTMLVideoElement | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [reel, setReel] = useState<{ url: string; blob: Blob; ext: string; via: 'browser' | 'server' } | null>(null);

  // Story
  const [story, setStory] = useState<StoryCopy | null>(null);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => { getServerHealth().then(setHealth); }, []);

  useEffect(() => {
    if (!source) { setSourceUrl(null); return; }
    const url = URL.createObjectURL(source);
    setSourceUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [source]);

  useEffect(() => () => { if (reel) URL.revokeObjectURL(reel.url); }, [reel]);
  useEffect(() => () => { abortRef.current?.abort(); window.speechSynthesis?.cancel(); }, []);

  const selected = useMemo(() => moments.filter(m => m.selected).sort((a, b) => a.start - b.start), [moments]);
  const reelSeconds = useMemo(() => selected.reduce((s, m) => s + (m.end - m.start), 0), [selected]);
  const aiReady = Boolean(health?.online && health.ai.configured);

  const setNewSource = (blob: Blob, name: string, marks: number[] = []) => {
    abortRef.current?.abort();
    setSource(blob);
    setSourceName(name);
    setBookmarks(marks);
    setAnalysis(null);
    setMoments([]);
    setStory(null);
    setReel(null);
    setError(null);
  };

  // ---------------------------------------------------------------- analysis
  const runAnalysis = async () => {
    if (!sourceUrl) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setBusy('analyze');
    setError(null);
    setReel(null);
    setStory(null);
    try {
      const result = await analyzeVideo(sourceUrl, {
        targetSeconds: target,
        bookmarks,
        signal: controller.signal,
        onProgress: (value, stage) => setProgress({ value, stage }),
      });
      setAnalysis(result);
      setMoments(result.moments);
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setError((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  const enhanceWithAI = async () => {
    setBusy('ai');
    setError(null);
    setProgress({ value: 0.3, stage: `Asking ${health?.ai.visionModel ?? 'the vision model'} to review ${Math.min(16, moments.length)} keyframes` });
    try {
      const labelled = await labelMomentsWithAI(moments, location);
      setMoments(reselect(labelled, analysis?.targetSeconds ?? target));
    } catch (e) {
      setError(`AI labelling failed: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  };

  const toggleMoment = (id: string) => setMoments(ms => ms.map(m => (m.id === id ? { ...m, selected: !m.selected } : m)));

  // ---------------------------------------------------------------- preview
  const previewQueue = useRef<Moment[]>([]);
  const playPreview = () => {
    const v = previewRef.current;
    if (!v || !selected.length) return;
    if (previewing) { v.pause(); setPreviewing(false); previewQueue.current = []; return; }
    previewQueue.current = [...selected];
    v.currentTime = previewQueue.current[0].start;
    v.play().catch(() => {});
    setPreviewing(true);
  };
  const onPreviewTime = () => {
    const v = previewRef.current;
    const q = previewQueue.current;
    if (!v || !q.length) return;
    if (v.currentTime >= q[0].end) {
      q.shift();
      if (q.length) v.currentTime = q[0].start;
      else { v.pause(); setPreviewing(false); }
    }
  };
  const jumpTo = (m: Moment) => {
    const v = previewRef.current;
    if (!v) return;
    previewQueue.current = [m];
    v.currentTime = m.start;
    v.play().catch(() => {});
    setPreviewing(true);
  };

  // ---------------------------------------------------------------- render
  const segments = selected.map(m => ({ start: m.start, end: m.end, label: m.label }));

  const renderBrowser = async () => {
    if (!sourceUrl || !segments.length) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setBusy('render');
    setError(null);
    try {
      const result = await renderReelInBrowser({
        src: sourceUrl, segments, title, location, aspect, signal: controller.signal,
        endLines: [`${formatTime(analysis?.duration ?? 0)} of footage → ${formatTime(reelSeconds)}`, `${segments.length} moments`, 'Made with RideStory AI'],
        onProgress: (value, stage) => setProgress({ value, stage }),
      });
      setReel({ url: URL.createObjectURL(result.blob), blob: result.blob, ext: result.extension, via: 'browser' });
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setError(`Browser render failed: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  };

  const renderServer = async () => {
    if (!source || !segments.length) return;
    setBusy('render');
    setError(null);
    setProgress({ value: 0, stage: 'Uploading to RideStory server' });
    try {
      const blob = await renderOnServer({
        file: source, segments, title, location, aspect,
        onUploadProgress: f => setProgress({ value: f * 0.6, stage: f < 1 ? `Uploading · ${Math.round(f * 100)}%` : 'FFmpeg is rendering 1080p…' }),
      });
      setReel({ url: URL.createObjectURL(blob), blob, ext: 'mp4', via: 'server' });
    } catch (e) {
      setError(`Server render failed: ${(e as Error).message}`);
    } finally {
      setBusy(null);
    }
  };

  const cancel = () => { abortRef.current?.abort(); setBusy(null); };

  // ---------------------------------------------------------------- story
  const writeStory = async () => {
    if (!selected.length) return;
    const input = { title, location, language: storyLanguage, moments: selected, sourceDuration: analysis?.duration ?? 0, reelDuration: reelSeconds };
    setBusy('write');
    setError(null);
    try {
      setStory(aiReady ? await writeStoryWithAI(input) : templateStory(input));
    } catch (e) {
      setError(`AI story failed, used the offline template instead: ${(e as Error).message}`);
      setStory(templateStory(input));
    } finally {
      setBusy(null);
    }
  };

  // Chapter timestamps in the *reel* timeline (title card + cumulative clip lengths).
  const reelChapters = useMemo(() => {
    let t = TITLE_CARD_SECONDS;
    return selected.map((m, i) => {
      const chapterTitle = story?.chapters.find(c => Math.abs(c.time - m.peak) < 1)?.title || story?.chapters[i]?.title || m.label;
      const row = { at: t, title: chapterTitle };
      t += m.end - m.start;
      return row;
    });
  }, [selected, story]);

  const shareText = story ? `${story.caption}\n\n${story.hashtags.join(' ')}` : '';

  const copyCaption = async () => {
    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard blocked */ }
  };

  const speak = () => {
    if (!story || !('speechSynthesis' in window)) return;
    if (speaking) { window.speechSynthesis.cancel(); setSpeaking(false); return; }
    const u = new SpeechSynthesisUtterance(story.narration || story.caption);
    u.lang = LANGS.find(l => l.name === storyLanguage)?.speech ?? 'en-IN';
    u.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };

  const shareReel = async () => {
    if (!reel) return;
    const file = new File([reel.blob], `ridestory-reel.${reel.ext}`, { type: reel.blob.type });
    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (nav.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title, text: shareText || title }).catch(() => {});
    } else download(reel.blob, file.name);
  };

  const downloadDiary = () => {
    if (!story) return;
    const md = [
      `# ${title}`, `*${location}*`, '', story.diary, '', '## Chapters',
      ...reelChapters.map(c => `- ${formatTime(c.at)} ${c.title}`), '', story.hashtags.join(' '),
    ].join('\n');
    download(new Blob([md], { type: 'text/markdown' }), 'ridestory-diary.md');
  };

  const downloadEditPlan = () => {
    const plan = {
      product: 'RideStory AI', version: 2, source: sourceName, sourceDurationSeconds: analysis?.duration,
      title, location, language: storyLanguage, aspect, reelDurationSeconds: reelSeconds,
      analysis: { sampleIntervalSeconds: analysis?.sampleInterval, sceneCuts: analysis?.sceneCuts, bookmarks },
      segments: selected.map(m => ({ start: m.start, end: m.end, label: m.label, score: Number(m.score.toFixed(3)), tags: m.tags, aiLabeled: Boolean(m.aiLabeled) })),
    };
    download(new Blob([JSON.stringify(plan, null, 2)], { type: 'application/json' }), 'ridestory-edit-plan.json');
  };

  // ---------------------------------------------------------------- UI
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-start justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full p-4 sm:p-6 shadow-2xl space-y-5 my-4 animate-fade-in text-slate-100">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 shrink-0 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-slate-950 shadow-lg">
              <SparklesIcon className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">RideStory AI Studio</h2>
              <p className="text-slate-400 text-xs">Long ride footage → scored moments → a rendered highlight reel and travel story.</p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                <StatusChip ok={Boolean(health?.online)} label={health ? (health.online ? 'Server online' : 'Server offline · on-device mode') : 'Checking server…'} />
                <StatusChip ok={aiReady} label={aiReady ? `Meta AI · ${health?.ai.visionModel}` : 'AI labelling off (no model key)'} />
                <StatusChip ok={Boolean(health?.ffmpeg)} label={health?.ffmpeg ? 'FFmpeg 1080p render' : 'Browser render'} />
              </div>
            </div>
          </div>
          <button onClick={onClose} aria-label="Close studio" className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 border border-slate-700">
            <XIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {([
            ['capture', '1 · Capture'],
            ['highlights', '2 · Highlights'],
            ['story', '3 · Story'],
          ] as [Tab, string][]).map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${tab === key ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'}`}>
              {label}
            </button>
          ))}
        </div>

        {error && (
          <div role="alert" className="rounded-xl border border-rose-800 bg-rose-950/50 px-4 py-3 text-xs text-rose-200 flex justify-between gap-3">
            <span>{error}</span>
            <button onClick={() => setError(null)} className="text-rose-300 hover:text-white">Dismiss</button>
          </div>
        )}

        {busy && busy !== 'write' && (
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">{progress.stage || 'Working…'}</span>
              <span className="flex items-center gap-3">
                <span className="font-mono text-amber-300">{Math.round(progress.value * 100)}%</span>
                {(busy === 'analyze' || busy === 'render') && <button onClick={cancel} className="text-slate-400 hover:text-white">Cancel</button>}
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-amber-500 to-rose-500 transition-all" style={{ width: `${Math.max(3, progress.value * 100)}%` }} />
            </div>
            {busy === 'render' && <p className="text-[11px] text-slate-500">Browser rendering records in real time — keep this tab open.</p>}
          </div>
        )}

        {tab === 'capture' && (
          <CapturePanel onFinished={(blob, marks) => { setNewSource(blob, `ride-capture-${new Date().toISOString().slice(0, 16)}.webm`, marks); setTab('highlights'); }} />
        )}

        {tab === 'highlights' && (
          <div className="space-y-5">
            {/* Source + settings */}
            <section className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-400">Source footage · stays on your device</p>
                  <p className="text-xs text-slate-400 mt-1">Analysis runs in your browser. Only keyframes go to the AI model (if enabled); the full video uploads only when you choose server rendering.</p>
                </div>
                <label className="shrink-0 cursor-pointer rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400 text-center">
                  {source ? 'Replace video' : 'Choose ride video'}
                  <input type="file" accept="video/*" className="hidden" onChange={e => {
                    const file = e.currentTarget.files?.[0];
                    if (file) setNewSource(file, file.name);
                    e.currentTarget.value = '';
                  }} />
                </label>
              </div>

              {!sourceUrl ? (
                <div className="rounded-xl border border-dashed border-slate-700 bg-slate-900/60 p-6 text-center">
                  <p className="text-sm text-slate-300">No video yet</p>
                  <p className="text-xs text-slate-500 mt-1">Pick a helmet-cam or phone recording (MP4/WebM), or record one in the Capture tab.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                  <div className="lg:col-span-3 space-y-2">
                    <video ref={previewRef} src={sourceUrl} controls playsInline onTimeUpdate={onPreviewTime} onPause={() => { if (!previewQueue.current.length) setPreviewing(false); }}
                      className="w-full max-h-80 rounded-xl bg-black" />
                    <p className="text-[11px] text-slate-400 break-all">
                      {sourceName} · {(source!.size / 1048576).toFixed(1)} MB{analysis ? ` · ${formatTime(analysis.duration)} · ${analysis.width}×${analysis.height}` : ''}
                      {bookmarks.length > 0 && ` · ${bookmarks.length} marked moment${bookmarks.length > 1 ? 's' : ''}`}
                    </p>
                  </div>
                  <div className="lg:col-span-2 grid grid-cols-2 gap-3 content-start">
                    <Field label="Story title" className="col-span-2"><input value={title} onChange={e => setTitle(e.target.value)} className={inputCls} /></Field>
                    <Field label="Ride location" className="col-span-2">
                      <div className="relative"><MapPinIcon className="w-4 h-4 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" /><input value={location} onChange={e => setLocation(e.target.value)} className={`${inputCls} pl-8`} /></div>
                    </Field>
                    <Field label="Reel length">
                      <select value={target} onChange={e => setTarget(Number(e.target.value))} className={inputCls}>
                        {TARGETS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                      </select>
                    </Field>
                    <Field label="Format">
                      <select value={aspect} onChange={e => setAspect(e.target.value as Aspect)} className={inputCls}>
                        <option value="landscape">16:9 YouTube</option>
                        <option value="vertical">9:16 Reels/Shorts</option>
                      </select>
                    </Field>
                    <Field label="Story language" className="col-span-2">
                      <select value={storyLanguage} onChange={e => setStoryLanguage(e.target.value)} className={inputCls}>
                        {LANGS.map(l => <option key={l.name}>{l.name}</option>)}
                      </select>
                    </Field>
                    <button onClick={runAnalysis} disabled={!!busy} className="col-span-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 px-4 py-3 text-sm font-extrabold text-slate-950 disabled:opacity-40">
                      {analysis ? 'Re-analyse footage' : 'Find the best moments'}
                    </button>
                  </div>
                </div>
              )}
            </section>

            {analysis && (
              <>
                {/* Timeline */}
                <section className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="text-sm font-bold text-white">Moment timeline</h3>
                      <p className="text-[11px] text-slate-400">{analysis.samples.length} frames scored · {analysis.sceneCuts.length} scene changes · {moments.length} candidates · reel {formatTime(reelSeconds)} of {formatTime(analysis.targetSeconds)} target</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button onClick={playPreview} disabled={!selected.length} className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-semibold hover:border-amber-400 disabled:opacity-40">
                        {previewing ? <PauseIcon className="w-3.5 h-3.5" /> : <PlayIcon className="w-3.5 h-3.5" />}{previewing ? 'Stop preview' : 'Preview cut'}
                      </button>
                      <button onClick={enhanceWithAI} disabled={!aiReady || !!busy} title={aiReady ? 'Send keyframes to the vision model' : 'Set MODEL_API_KEY on the server to enable'}
                        className="flex items-center gap-1.5 rounded-lg bg-fuchsia-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-fuchsia-500 disabled:opacity-40 disabled:cursor-not-allowed">
                        <SparklesIcon className="w-3.5 h-3.5" />{busy === 'ai' ? 'Reviewing…' : 'Enhance with Meta AI'}
                      </button>
                    </div>
                  </div>
                  <Timeline analysis={analysis} moments={moments} bookmarks={bookmarks} onPick={jumpTo} />
                </section>

                {/* Moments */}
                <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {moments.map(m => (
                    <article key={m.id} className={`rounded-xl overflow-hidden border transition-all ${m.selected ? 'border-amber-500/70 bg-slate-950' : 'border-slate-800 bg-slate-950/40 opacity-70'}`}>
                      <button onClick={() => jumpTo(m)} className="relative block w-full aspect-video bg-black" aria-label={`Preview ${m.label}`}>
                        {m.thumbnail && <img src={m.thumbnail} alt="" className="w-full h-full object-cover" />}
                        <span className="absolute bottom-1.5 left-1.5 rounded bg-black/70 px-1.5 py-0.5 font-mono text-[10px] text-white">{formatTime(m.start)}–{formatTime(m.end)}</span>
                        {m.aiLabeled && <span className="absolute top-1.5 left-1.5 rounded bg-fuchsia-600/90 px-1.5 py-0.5 text-[9px] font-bold text-white">AI</span>}
                      </button>
                      <div className="p-3 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-xs font-bold text-white leading-snug">{m.label}</h4>
                          <label className="flex items-center gap-1 text-[10px] text-slate-400 shrink-0 cursor-pointer">
                            <input type="checkbox" checked={m.selected} onChange={() => toggleMoment(m.id)} className="accent-amber-500" />In reel
                          </label>
                        </div>
                        <div className="h-1 rounded bg-slate-800"><div className="h-full rounded bg-amber-400" style={{ width: `${Math.round(m.score * 100)}%` }} /></div>
                        <p className="text-[10px] text-slate-400 leading-relaxed">{m.description}</p>
                        <div className="flex flex-wrap gap-1">{m.tags.map(t => <span key={t} className="rounded bg-slate-800 px-1.5 py-0.5 text-[9px] text-slate-300">{t}</span>)}</div>
                        {(m.privacy?.faces || m.privacy?.plates) && (
                          <p className="text-[10px] text-amber-300">⚠ {[m.privacy.faces && 'faces', m.privacy.plates && 'licence plates'].filter(Boolean).join(' & ')} visible — check consent before posting publicly.</p>
                        )}
                      </div>
                    </article>
                  ))}
                </section>

                {/* Render */}
                <section className="rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-950/30 to-slate-950 p-4 space-y-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-bold text-white">Render highlight reel</h3>
                      <p className="text-[11px] text-slate-400">{selected.length} clips · {formatTime(reelSeconds + TITLE_CARD_SECONDS * 2)} with title and end cards · {aspect === 'vertical' ? '9:16' : '16:9'}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button onClick={renderBrowser} disabled={!!busy || !selected.length || !browserCanRender()} className="rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400 disabled:opacity-40">Render in browser</button>
                      <button onClick={renderServer} disabled={!!busy || !selected.length || !health?.ffmpeg} title={health?.ffmpeg ? 'Upload and render 1080p MP4 with FFmpeg' : 'Start the RideStory server with FFmpeg installed'}
                        className="rounded-xl border border-amber-500/60 px-4 py-2.5 text-xs font-bold text-amber-300 hover:bg-amber-500/10 disabled:opacity-40">Render 1080p MP4 on server</button>
                      <button onClick={downloadEditPlan} disabled={!selected.length} className="rounded-xl border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:border-slate-500 disabled:opacity-40">Edit plan (JSON)</button>
                    </div>
                  </div>
                  {reel && (
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-start">
                      <video src={reel.url} controls playsInline className={`md:col-span-3 w-full rounded-xl bg-black ${aspect === 'vertical' ? 'max-h-[28rem] object-contain' : ''}`} />
                      <div className="md:col-span-2 space-y-2">
                        <p className="text-xs text-emerald-300 flex items-center gap-1.5"><CheckIcon className="w-4 h-4" />Reel ready · {reel.ext.toUpperCase()} · {(reel.blob.size / 1048576).toFixed(1)} MB · rendered {reel.via === 'server' ? 'with FFmpeg' : 'in browser'}</p>
                        <button onClick={() => download(reel.blob, `ridestory-reel.${reel.ext}`)} className="w-full rounded-xl bg-emerald-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-emerald-400">Download reel</button>
                        <button onClick={shareReel} className="w-full rounded-xl border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500 flex items-center justify-center gap-2"><ShareIcon className="w-4 h-4" />Share</button>
                        <button onClick={() => setTab('story')} className="w-full rounded-xl border border-cyan-700 px-4 py-2.5 text-xs font-semibold text-cyan-300 hover:bg-cyan-500/10">Write the story →</button>
                      </div>
                    </div>
                  )}
                </section>
              </>
            )}
          </div>
        )}

        {tab === 'story' && (
          <div className="space-y-4">
            {!selected.length ? (
              <div className="rounded-2xl border border-dashed border-slate-700 p-6 text-center text-sm text-slate-400">Analyse a ride in the Highlights tab first — the story is written from the moments you keep.</div>
            ) : (
              <>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">Travel story · {storyLanguage}</h3>
                    <p className="text-[11px] text-slate-400">{aiReady ? `Written by ${health?.ai.textModel} from your ${selected.length} moments.` : 'Offline template from your moments. Add a model key on the server for AI writing in Indian languages.'}</p>
                  </div>
                  <button onClick={writeStory} disabled={busy === 'write'} className="rounded-xl bg-cyan-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-cyan-400 disabled:opacity-50 flex items-center gap-2">
                    <SparklesIcon className="w-4 h-4" />{busy === 'write' ? 'Writing…' : story ? 'Rewrite' : 'Write my story'}
                  </button>
                </div>

                {story && (
                  <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                    <div className="lg:col-span-3 space-y-4">
                      <Field label={`Caption${story.source === 'template' ? ' (template)' : ''}`}>
                        <textarea value={story.caption} onChange={e => setStory({ ...story, caption: e.target.value })} rows={3} className={`${inputCls} resize-y`} />
                      </Field>
                      <p className="text-xs text-cyan-300 break-words">{story.hashtags.join(' ')}</p>
                      <Field label="Diary">
                        <textarea value={story.diary} onChange={e => setStory({ ...story, diary: e.target.value })} rows={9} className={`${inputCls} resize-y leading-relaxed`} />
                      </Field>
                      <div className="flex flex-wrap gap-2">
                        <button onClick={copyCaption} className="rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400 flex items-center gap-2">
                          {copied ? <CheckIcon className="w-4 h-4" /> : <ShareIcon className="w-4 h-4" />}{copied ? 'Copied' : 'Copy caption + tags'}
                        </button>
                        <button onClick={downloadDiary} className="rounded-xl border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500">Download diary (.md)</button>
                        <button onClick={speak} className="rounded-xl border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-200 hover:border-slate-500 flex items-center gap-2">
                          <MicrophoneIcon className="w-4 h-4" />{speaking ? 'Stop narration' : 'Play narration'}
                        </button>
                      </div>
                    </div>
                    <div className="lg:col-span-2 space-y-3">
                      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4">
                        <p className="text-[10px] font-bold uppercase tracking-wider text-amber-400 mb-2">Chapters (reel time)</p>
                        <ol className="space-y-1.5">
                          {reelChapters.map((c, i) => (
                            <li key={i} className="flex gap-3 text-xs"><span className="font-mono text-amber-300 w-10 shrink-0">{formatTime(c.at)}</span><span className="text-slate-200">{c.title}</span></li>
                          ))}
                        </ol>
                      </div>
                      {story.narration && (
                        <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 mb-2">Voice-over script</p>
                          <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">{story.narration}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------

const inputCls = 'mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400';

const Field: React.FC<{ label: string; className?: string; children: React.ReactNode }> = ({ label, className = '', children }) => (
  <label className={`block text-xs text-slate-300 ${className}`}>{label}{children}</label>
);

const StatusChip: React.FC<{ ok: boolean; label: string }> = ({ ok, label }) => (
  <span className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-semibold ${ok ? 'border-emerald-700 bg-emerald-950/60 text-emerald-300' : 'border-slate-700 bg-slate-900 text-slate-400'}`}>
    <span className={`h-1.5 w-1.5 rounded-full ${ok ? 'bg-emerald-400' : 'bg-slate-500'}`} />{label}
  </span>
);

/** Score curve across the whole ride with candidate/selected windows, scene cuts and bookmarks. */
const Timeline: React.FC<{ analysis: AnalysisResult; moments: Moment[]; bookmarks: number[]; onPick: (m: Moment) => void }> = ({ analysis, moments, bookmarks, onPick }) => {
  const { duration, samples, sceneCuts } = analysis;
  const x = (t: number) => (t / duration) * 1000;
  const points = samples.map(s => `${x(s.time).toFixed(1)},${(60 - s.score * 52).toFixed(1)}`).join(' ');
  return (
    <div>
      <svg viewBox="0 0 1000 72" preserveAspectRatio="none" className="w-full h-20 rounded-lg bg-slate-900" role="img" aria-label="Moment score across the ride">
        {sceneCuts.map((c, i) => <line key={i} x1={x(c)} x2={x(c)} y1={0} y2={64} stroke="#334155" strokeWidth={1} vectorEffect="non-scaling-stroke" />)}
        {moments.map(m => (
          <rect key={m.id} x={x(m.start)} width={Math.max(2, x(m.end) - x(m.start))} y={0} height={64} fill={m.selected ? 'rgba(245,158,11,0.35)' : 'rgba(148,163,184,0.15)'}
            stroke={m.selected ? '#f59e0b' : 'none'} vectorEffect="non-scaling-stroke" className="cursor-pointer" onClick={() => onPick(m)} />
        ))}
        <polyline points={points} fill="none" stroke="#fb7185" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
        {bookmarks.map((b, i) => <circle key={i} cx={x(b)} cy={66} r={3} fill="#22d3ee" />)}
      </svg>
      <div className="flex justify-between mt-1 text-[10px] font-mono text-slate-500">
        <span>0:00</span>
        <span className="flex gap-3 font-sans">
          <span><span className="inline-block w-2 h-2 bg-amber-500/70 mr-1" />in reel</span>
          <span><span className="inline-block w-2 h-2 bg-slate-500/50 mr-1" />alternate</span>
          <span><span className="inline-block w-2 h-0.5 bg-rose-400 mr-1 align-middle" />score</span>
          {bookmarks.length > 0 && <span><span className="inline-block w-2 h-2 rounded-full bg-cyan-400 mr-1" />marked</span>}
        </span>
        <span>{formatTime(duration)}</span>
      </div>
    </div>
  );
};

/** Record from the phone/helmet camera on-device, tapping "Mark moment" for highlights. */
const CapturePanel: React.FC<{ onFinished: (blob: Blob, bookmarks: number[]) => void }> = ({ onFinished }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startedRef = useRef(0);
  const [cameraOn, setCameraOn] = useState(false);
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [marks, setMarks] = useState<number[]>([]);
  const marksRef = useRef<number[]>([]);
  const [err, setErr] = useState<string | null>(null);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    setCameraOn(false);
  }, []);

  useEffect(() => () => { if (recorderRef.current?.state === 'recording') recorderRef.current.stop(); stopCamera(); }, [stopCamera]);

  useEffect(() => {
    if (!recording) return;
    const id = window.setInterval(() => setElapsed((performance.now() - startedRef.current) / 1000), 250);
    return () => window.clearInterval(id);
  }, [recording]);

  const mark = useCallback(() => {
    if (!recording) return;
    marksRef.current = [...marksRef.current, Math.round((performance.now() - startedRef.current) / 100) / 10];
    setMarks(marksRef.current);
  }, [recording]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key.toLowerCase() === 'm' && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)) mark(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mark]);

  const startCamera = async () => {
    setErr(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: true });
      streamRef.current = stream;
      if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play().catch(() => {}); }
      setCameraOn(true);
    } catch (e) {
      setErr(`Camera unavailable: ${(e as Error).message}. Allow camera access, or use "Choose ride video" in Highlights.`);
    }
  };

  const startRecording = () => {
    if (!streamRef.current) return;
    const type = ['video/webm;codecs=vp9,opus', 'video/webm', 'video/mp4'].find(t => MediaRecorder.isTypeSupported(t));
    const rec = new MediaRecorder(streamRef.current, type ? { mimeType: type } : undefined);
    chunksRef.current = [];
    rec.ondataavailable = e => { if (e.data.size) chunksRef.current.push(e.data); };
    rec.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'video/webm' });
      stopCamera();
      onFinished(blob, marksRef.current);
    };
    rec.start(1000);
    recorderRef.current = rec;
    startedRef.current = performance.now();
    marksRef.current = [];
    setMarks([]);
    setElapsed(0);
    setRecording(true);
  };

  const stopRecording = () => { setRecording(false); recorderRef.current?.stop(); };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 space-y-3">
        <div className="relative aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800">
          <video ref={videoRef} muted playsInline className="w-full h-full object-cover" />
          {!cameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center p-6">
              <CameraIcon className="w-10 h-10 text-slate-500" />
              <p className="text-sm text-slate-300">Record your ride on this device</p>
              <button onClick={startCamera} className="rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400">Start camera</button>
            </div>
          )}
          {recording && (
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <span className="bg-rose-600 text-white font-bold text-[10px] px-2 py-0.5 rounded uppercase tracking-wider animate-pulse">REC</span>
              <span className="bg-black/60 text-white text-xs px-2 py-0.5 rounded font-mono">{formatTime(elapsed)}</span>
              <span className="bg-black/60 text-cyan-300 text-xs px-2 py-0.5 rounded font-mono">{marks.length} marked</span>
            </div>
          )}
        </div>
        {err && <p className="text-xs text-rose-300">{err}</p>}
        {cameraOn && (
          <div className="flex flex-wrap gap-2">
            {!recording ? (
              <button onClick={startRecording} className="rounded-xl bg-rose-600 px-4 py-2.5 text-xs font-extrabold text-white hover:bg-rose-500">● Start recording</button>
            ) : (
              <>
                <button onClick={mark} className="rounded-xl bg-cyan-500 px-5 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-cyan-400">★ Mark moment (M)</button>
                <button onClick={stopRecording} className="rounded-xl bg-slate-100 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-white">■ Stop & build reel</button>
              </>
            )}
            {!recording && <button onClick={stopCamera} className="rounded-xl border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-300">Turn off camera</button>}
          </div>
        )}
      </div>
      <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-3 text-xs">
        <h3 className="font-bold text-white text-sm">How capture works</h3>
        <ol className="list-decimal list-inside space-y-1.5 text-slate-400">
          <li>Mount the phone, start the camera and hit record.</li>
          <li>Tap <span className="text-cyan-300 font-semibold">Mark moment</span> (or press M) when something great happens — marked moments get a big boost when the reel is picked.</li>
          <li>Stop, and the recording opens straight in Highlights.</li>
        </ol>
        <p className="text-slate-500">Recording stays on this device. Public live broadcasting to viewers needs a streaming ingest service (WebRTC/RTMP) and is not part of this build.</p>
        {marks.length > 0 && (
          <div>
            <p className="text-[10px] font-bold uppercase text-cyan-400 mb-1">Marked</p>
            <div className="flex flex-wrap gap-1">{marks.map((m, i) => <span key={i} className="rounded bg-cyan-950 border border-cyan-800 px-1.5 py-0.5 font-mono text-[10px] text-cyan-200">{formatTime(m)}</span>)}</div>
          </div>
        )}
      </div>
    </div>
  );
};
