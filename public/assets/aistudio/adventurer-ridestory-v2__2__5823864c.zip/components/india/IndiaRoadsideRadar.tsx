import React, { useState } from 'react';
import { ShieldAlertIcon, WrenchIcon, MapPinIcon, CheckIcon, PlusIcon, XIcon, ClockIcon } from '../icons';
import type { SupportedLanguage } from '../../services/i18nService';
import { getTranslation } from '../../services/i18nService';

export interface RoadHazard {
  id: string;
  type: 'Pothole' | 'Landslide' | 'Cattle' | 'Waterlogging' | 'Black Ice' | 'Oil Spill';
  severity: 'Critical' | 'Warning' | 'Caution';
  location: string;
  highway: string;
  distanceKm: number;
  reportedBy: string;
  reportedAgo: string;
  upvotes: number;
  verified: boolean;
}

export interface MechanicShop {
  id: string;
  name: string;
  specialty: string;
  distanceKm: number;
  rating: number;
  reviewsCount: number;
  phone: string;
  open24x7: boolean;
  services: string[];
  location: string;
}

const INITIAL_HAZARDS: RoadHazard[] = [
  {
    id: 'hz-1',
    type: 'Black Ice',
    severity: 'Critical',
    location: 'Chang La High Pass Descent (North Face)',
    highway: 'Leh-Pangong Military Highway',
    distanceKm: 4.2,
    reportedBy: 'Stanzin Dorje (Ladakh Sweeper)',
    reportedAgo: '14 mins ago',
    upvotes: 38,
    verified: true,
  },
  {
    id: 'hz-2',
    type: 'Landslide',
    severity: 'Critical',
    location: 'Keylong to Jispa River Bend',
    highway: 'Manali-Leh NH-3',
    distanceKm: 18.5,
    reportedBy: 'Border Roads Organisation Scout',
    reportedAgo: '32 mins ago',
    upvotes: 64,
    verified: true,
  },
  {
    id: 'hz-3',
    type: 'Waterlogging',
    severity: 'Warning',
    location: 'Tamhini Ghat Hairpin #14 Waterfall Spill',
    highway: 'State Highway 70 (Maharashtra)',
    distanceKm: 27.1,
    reportedBy: 'Sahyadri Riders Club',
    reportedAgo: '1 hr ago',
    upvotes: 19,
    verified: true,
  },
  {
    id: 'hz-4',
    type: 'Cattle',
    severity: 'Caution',
    location: 'Blind Turn under Flyover Crossing',
    highway: 'NH-48 Pune-Bengaluru Corridor',
    distanceKm: 8.6,
    reportedBy: 'Pooja Deshmukh',
    reportedAgo: '45 mins ago',
    upvotes: 12,
    verified: false,
  },
  {
    id: 'hz-5',
    type: 'Pothole',
    severity: 'Warning',
    location: 'Deep Pothole Cluster right after Toll Plaza',
    highway: 'Mumbai-Goa NH-66',
    distanceKm: 12.3,
    reportedBy: 'Vikram RE Club',
    reportedAgo: '2 hrs ago',
    upvotes: 27,
    verified: true,
  },
];

const NEARBY_MECHANICS: MechanicShop[] = [
  {
    id: 'mech-1',
    name: 'Sardarji Bullet Works & High Altitude Tuning',
    specialty: 'Royal Enfield Specialist & Carb/FI Jetting',
    distanceKm: 2.4,
    rating: 4.9,
    reviewsCount: 142,
    phone: '+91 98290 11400',
    open24x7: true,
    services: ['Tubeless Plug & Patch', 'Clutch Wire Replacement', 'Brake Bleeding', 'Engine Oil Top-up'],
    location: 'Old Leh Fort Road, Ladakh',
  },
  {
    id: 'mech-2',
    name: 'Ghat Master Tyre Puncture & Tube Vulcanizing',
    specialty: 'All Adventure & Dirt Bike Tyres',
    distanceKm: 1.1,
    rating: 4.8,
    reviewsCount: 88,
    phone: '+91 94220 88219',
    open24x7: true,
    services: ['Heavy Duty Spoke Truing', 'Puncture Sealant', 'Chain Slack Adjust'],
    location: 'Amboli Ghat Top Junction',
  },
  {
    id: 'mech-3',
    name: 'Kaza Himalayan Garage & Welding',
    specialty: 'Luggage Rack Welding & Footpeg Repair',
    distanceKm: 5.7,
    rating: 4.7,
    reviewsCount: 63,
    phone: '+91 89880 55123',
    open24x7: false,
    services: ['Chassis Crack Welding', 'Chain Sprocket Swap', 'Battery Jump-Start'],
    location: 'Kaza Main Market, Spiti Valley',
  },
  {
    id: 'mech-4',
    name: 'Highway Patrol Rapid Assistance Mobile Van',
    specialty: '24x7 Emergency Tow & Flatbed',
    distanceKm: 7.9,
    rating: 4.9,
    reviewsCount: 310,
    phone: '+91 1800 200 4455',
    open24x7: true,
    services: ['Emergency Fuel Can (5L)', 'Hydraulic Tow Hook', 'First-Aid Oxygen'],
    location: 'NH-44 Mile Marker 312',
  },
];

interface IndiaRoadsideRadarProps {
  language: SupportedLanguage;
  onClose?: () => void;
}

export const IndiaRoadsideRadar: React.FC<IndiaRoadsideRadarProps> = ({ language, onClose }) => {
  const [hazards, setHazards] = useState<RoadHazard[]>(INITIAL_HAZARDS);
  const [activeTab, setActiveTab] = useState<'hazards' | 'mechanics' | 'sos'>('hazards');
  const [sosActive, setSosActive] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [newHazardType, setNewHazardType] = useState<RoadHazard['type']>('Pothole');
  const [newHazardLocation, setNewHazardLocation] = useState('');
  const [newHazardSeverity, setNewHazardSeverity] = useState<RoadHazard['severity']>('Warning');
  const [callAlert, setCallAlert] = useState<string | null>(null);

  const handleUpvote = (id: string) => {
    setHazards(prev =>
      prev.map(h => (h.id === id ? { ...h, upvotes: h.upvotes + 1 } : h))
    );
  };

  const handleAddHazard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHazardLocation.trim()) return;
    const item: RoadHazard = {
      id: `hz-${Date.now()}`,
      type: newHazardType,
      severity: newHazardSeverity,
      location: newHazardLocation,
      highway: 'Current GPS Segment',
      distanceKm: 0.8,
      reportedBy: 'You (Live Rider)',
      reportedAgo: 'Just now',
      upvotes: 1,
      verified: true,
    };
    setHazards([item, ...hazards]);
    setNewHazardLocation('');
    setShowReportModal(false);
  };

  const handleCallMechanic = (shop: MechanicShop) => {
    setCallAlert(`Dialing ${shop.name} at ${shop.phone}... Direct emergency line connected!`);
    setTimeout(() => setCallAlert(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header and SOS Quick Action */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <ShieldAlertIcon className="w-4 h-4 text-rose-500" />
              <span>{getTranslation('nav_radar', language)}</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
              Indian Highway Roadside Hazard Radar & 112 SOS
            </h2>
            <p className="text-slate-400 text-sm mt-0.5">
              Crowdsourced hazard markers, nearby mountain mechanics, and national 112 emergency telemetry dispatch.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSosActive(prev => !prev)}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 ${
                sosActive
                  ? 'bg-rose-600 text-white animate-pulse shadow-xl shadow-rose-600/50'
                  : 'bg-rose-950/80 hover:bg-rose-900 border border-rose-700/80 text-rose-200'
              }`}
            >
              <ShieldAlertIcon className="w-4 h-4 text-rose-400" />
              <span>{sosActive ? getTranslation('sos_active', language) : getTranslation('sos_trigger', language)}</span>
            </button>
          </div>
        </div>

        {/* SOS Activated Banner */}
        {sosActive && (
          <div className="mt-4 p-4 rounded-xl bg-rose-950/90 border border-rose-600 text-rose-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fadeIn">
            <div className="space-y-1">
              <div className="flex items-center gap-2 font-bold text-sm text-rose-200">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-ping" />
                <span>{getTranslation('sos_desc', language)}</span>
              </div>
              <div className="text-xs text-rose-300 font-mono">
                GPS: 34.1526° N, 77.5771° E (Elevation 11,480 ft) • Blood Group: O+ve • Bike: Himalayan 450
              </div>
              <div className="text-[11px] text-rose-400">
                Dispatched to: National Emergency 112 Grid, 4 Convoys within 15km, and Border Roads Patrol.
              </div>
            </div>

            <button
              onClick={() => setSosActive(false)}
              className="px-3.5 py-1.5 rounded-lg bg-rose-800 hover:bg-rose-700 text-white text-xs font-semibold whitespace-nowrap"
            >
              Cancel SOS Beacon
            </button>
          </div>
        )}

        {/* Call Feedback Toast */}
        {callAlert && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-950 border border-emerald-600 text-emerald-200 text-xs flex items-center gap-2">
            <CheckIcon className="w-4 h-4 text-emerald-400" />
            <span>{callAlert}</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('hazards')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'hazards'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <ShieldAlertIcon className="w-4 h-4" />
          <span>Active Hazards ({hazards.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('mechanics')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'mechanics'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <WrenchIcon className="w-4 h-4" />
          <span>Nearby Mechanics & Puncture ({NEARBY_MECHANICS.length})</span>
        </button>

        <button
          onClick={() => setShowReportModal(true)}
          className="ml-auto flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 border border-slate-700 text-slate-200 hover:border-amber-400 transition-colors"
        >
          <PlusIcon className="w-4 h-4 text-amber-400" />
          <span>Report Hazard</span>
        </button>
      </div>

      {/* Tab 1: Hazards List */}
      {activeTab === 'hazards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {hazards.map(hazard => (
            <div
              key={hazard.id}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 hover:border-slate-700 transition-all shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                        hazard.severity === 'Critical'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : hazard.severity === 'Warning'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-yellow-950 text-yellow-300 border border-yellow-800'
                      }`}
                    >
                      {hazard.type}
                    </span>
                    <span className="text-slate-500 text-xs font-mono">{hazard.distanceKm} km ahead</span>
                  </div>

                  {hazard.verified && (
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <CheckIcon className="w-2.5 h-2.5 text-emerald-400" />
                      <span>Verified</span>
                    </span>
                  )}
                </div>

                <h3 className="text-white font-bold text-base mt-2">{hazard.location}</h3>
                <p className="text-slate-400 text-xs mt-0.5">{hazard.highway}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-500 text-[11px]">
                  By {hazard.reportedBy} • {hazard.reportedAgo}
                </span>

                <button
                  onClick={() => handleUpvote(hazard.id)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700"
                >
                  <span className="text-amber-400 font-bold">▲</span>
                  <span>{hazard.upvotes} Confirm</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Nearby Mechanics */}
      {activeTab === 'mechanics' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {NEARBY_MECHANICS.map(shop => (
            <div
              key={shop.id}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 hover:border-cyan-500/50 transition-all shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-white font-bold text-base">{shop.name}</h3>
                    <p className="text-cyan-400 text-xs font-medium">{shop.specialty}</p>
                    <p className="text-slate-400 text-xs flex items-center gap-1 mt-1">
                      <MapPinIcon className="w-3.5 h-3.5 text-slate-500" />
                      <span>{shop.location} • <strong className="text-slate-200">{shop.distanceKm} km away</strong></span>
                    </p>
                  </div>

                  <div className="text-right">
                    <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-xs font-bold">
                      <span>★</span>
                      <span>{shop.rating}</span>
                      <span className="text-slate-500 text-[10px]">({shop.reviewsCount})</span>
                    </div>
                    {shop.open24x7 && (
                      <span className="block text-[10px] text-emerald-400 font-bold mt-1 uppercase">24x7 Open</span>
                    )}
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {shop.services.map((service, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] bg-slate-950 border border-slate-800 text-slate-400 px-2 py-0.5 rounded"
                    >
                      {service}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-slate-400 font-mono text-xs">{shop.phone}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCallMechanic(shop)}
                    className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5"
                  >
                    <WrenchIcon className="w-3.5 h-3.5" />
                    <span>Call Mechanic</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Report Road Hazard */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-white font-bold text-lg flex items-center gap-2">
                <ShieldAlertIcon className="w-5 h-5 text-amber-400" />
                <span>Report Road Hazard</span>
              </h3>
              <button
                onClick={() => setShowReportModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <XIcon className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddHazard} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Hazard Type</label>
                <select
                  value={newHazardType}
                  onChange={e => setNewHazardType(e.target.value as RoadHazard['type'])}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-sm focus:border-amber-400 focus:outline-none"
                >
                  <option value="Pothole">Pothole / Road Trench</option>
                  <option value="Landslide">Landslide / Rockfall</option>
                  <option value="Cattle">Stray Cattle / Animals</option>
                  <option value="Waterlogging">Monsoon Waterlogging / Flash Stream</option>
                  <option value="Black Ice">Black Ice Patch</option>
                  <option value="Oil Spill">Diesel / Oil Slick</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Location Details</label>
                <input
                  type="text"
                  placeholder="e.g. Tamhini Ghat Hairpin #8 near waterfall"
                  value={newHazardLocation}
                  onChange={e => setNewHazardLocation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-sm focus:border-amber-400 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Severity</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Critical', 'Warning', 'Caution'] as const).map(sev => (
                    <button
                      key={sev}
                      type="button"
                      onClick={() => setNewHazardSeverity(sev)}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-all border ${
                        newHazardSeverity === sev
                          ? sev === 'Critical'
                            ? 'bg-rose-900 border-rose-500 text-white'
                            : sev === 'Warning'
                            ? 'bg-amber-900 border-amber-500 text-white'
                            : 'bg-yellow-900 border-yellow-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {sev}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium bg-slate-800 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors shadow-lg shadow-amber-500/20"
                >
                  Broadcast Hazard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
