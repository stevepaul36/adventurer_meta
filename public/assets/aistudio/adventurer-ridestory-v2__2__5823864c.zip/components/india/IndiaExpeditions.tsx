import React, { useState } from 'react';
import { RouteIcon, CompassIcon, MapPinIcon, ShieldAlertIcon, WrenchIcon, CameraIcon, FemaleIcon, TrophyIcon, CheckIcon, ClockIcon } from '../icons';
import type { SupportedLanguage } from '../../services/i18nService';
import { getTranslation } from '../../services/i18nService';

export interface ExpeditionRoute {
  id: string;
  title: string;
  region: string;
  state: string;
  distanceKm: number;
  durationDays: string;
  highestPass: string;
  altitudeFt: number;
  difficulty: 'Moderate' | 'Challenging' | 'Extreme';
  isWomenFocused?: boolean;
  planA: string;
  planB: string;
  safetyScore: number;
  terrain: string;
  landmarks: string[];
  recommendedBike: string;
  oxygenAlert?: boolean;
  monsoonAlert?: boolean;
  image: string;
  roles: {
    leader: string;
    safetyOfficer: string;
    mechanic: string;
    photographer: string;
  };
}

const EXPEDITIONS: ExpeditionRoute[] = [
  {
    id: 'leh-ladakh',
    title: 'Leh-Ladakh Trans-Himalayan Circuit',
    region: 'North Himalayas',
    state: 'Ladakh / Himachal Pradesh',
    distanceKm: 1240,
    durationDays: '10 Days',
    highestPass: 'Khardung La (17,982 ft) & Umling La (19,024 ft)',
    altitudeFt: 19024,
    difficulty: 'Extreme',
    planA: 'Manali - Rohtang - Jispa - Sarchu - Tanglang La - Leh - Nubra - Pangong',
    planB: 'Srinagar - Sonamarg - Zoji La - Kargil - Leh (Lower elevation acclimation)',
    safetyScore: 9.4,
    terrain: 'Glacial water crossings, high passes, gravel shale, zero network stretches',
    landmarks: ['Magnetic Hill', 'Diskit Monastery', 'Pangong Tso', 'Khardung La Top'],
    recommendedBike: 'Royal Enfield Himalayan 450 / KTM 390 Adventure / BMW GS',
    oxygenAlert: true,
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
    roles: {
      leader: 'Vikram "Khar" Rathore',
      safetyOfficer: 'Dr. Tanya Sen (Wilderness Medic)',
      mechanic: 'Rajinder Bullet Works (Leh Certified)',
      photographer: 'Aarav FPV Pilot',
    },
  },
  {
    id: 'spiti-valley',
    title: 'Spiti Valley Cold Desert & Monasteries',
    region: 'Inner Himalayas',
    state: 'Himachal Pradesh',
    distanceKm: 890,
    durationDays: '7 Days',
    highestPass: 'Kunzum La (14,931 ft) & Chicham Bridge (13,596 ft)',
    altitudeFt: 14931,
    difficulty: 'Extreme',
    planA: 'Shimla - Kinnaur - Tabo - Kaza - Hikkim - Kunzum La - Chandra Taal',
    planB: 'Manali reverse exit via Atal Tunnel in case of Spiti river mallam blockage',
    safetyScore: 9.1,
    terrain: 'Loose scree, unpaved gorge roads, dry high-altitude canyon tracks',
    landmarks: ['Hikkim Highest Post Office', 'Key Monastery', 'Chandra Taal', 'Chicham Gorge'],
    recommendedBike: 'Dual Sport 250cc-650cc / High Ground Clearance',
    oxygenAlert: true,
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
    roles: {
      leader: 'Kabir Thapa',
      safetyOfficer: 'Neha Verma',
      mechanic: 'Manoj Singh',
      photographer: 'Siddharth Rao',
    },
  },
  {
    id: 'western-ghats',
    title: 'Western Ghats Monsoon Rain & Ridge Odyssey',
    region: 'Sahyadri & Malabar',
    state: 'Maharashtra / Karnataka / Goa',
    distanceKm: 760,
    durationDays: '5 Days',
    highestPass: 'Amboli Ghat & Varandha Ghat',
    altitudeFt: 4600,
    difficulty: 'Moderate',
    isWomenFocused: true,
    planA: 'Pune - Bhor - Varandha Ghat - Mahabaleshwar - Amboli - Chorla - Goa',
    planB: 'NH-66 Coastal detour if heavy monsoon landslides occur in Tamhini',
    safetyScore: 9.7,
    terrain: 'Lush rainforest switchbacks, cascading waterfalls, fog-laden asphalt',
    landmarks: ['Thoseghar Falls', 'Kaas Plateau of Flowers', 'Chorla Mist Pass'],
    recommendedBike: 'Triumph Scrambler 400X / Hunter 350 / Dominar 400',
    monsoonAlert: true,
    image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
    roles: {
      leader: 'Ananya Sharma (Queens on Wheels Lead)',
      safetyOfficer: 'Pooja Deshmukh',
      mechanic: 'Ramesh Garage Mahad',
      photographer: 'Deepa Krishnan',
    },
  },
  {
    id: 'kolli-hills',
    title: 'Kolli Hills 70 Continuous Hairpin Challenge',
    region: 'Eastern Ghats',
    state: 'Tamil Nadu',
    distanceKm: 340,
    durationDays: '2 Days',
    highestPass: 'Semmedu Peak (4,265 ft)',
    altitudeFt: 4265,
    difficulty: 'Challenging',
    planA: 'Namakkal - Karavalli - 70 Hairpin Climb - Solakkadu - Agaya Gangai Falls',
    planB: 'Sendamangalam foothill rest camp if uphill traffic congestion occurs',
    safetyScore: 9.5,
    terrain: 'Tight radius consecutive switchbacks, steep gradient, smooth tarmac',
    landmarks: ['Hairpin Bend #35 Viewpoint', 'Arapaleeswarar Temple', 'Agaya Gangai'],
    recommendedBike: 'Yamaha MT-15 / KTM Duke 250 / TVS Apache RR 310',
    image: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1200&q=80',
    roles: {
      leader: 'Karthik Subramanian',
      safetyOfficer: 'Arun Pandian',
      mechanic: 'Velu Moto Spares',
      photographer: 'Prasanna Kumar',
    },
  },
  {
    id: 'meghalaya-clouds',
    title: 'Meghalaya Abode of Clouds & Living Bridges',
    region: 'Northeast Frontier',
    state: 'Meghalaya / Assam',
    distanceKm: 580,
    durationDays: '4 Days',
    highestPass: 'Shillong Peak (6,447 ft)',
    altitudeFt: 6447,
    difficulty: 'Moderate',
    planA: 'Guwahati - Umiam Lake - Shillong - Cherrapunji (Sohra) - Dawki - Mawlynnong',
    planB: 'Jowai ridge road if heavy mist hits the Mawkdok Dympep Valley',
    safetyScore: 9.6,
    terrain: 'Rolling pine hills, crystal river gorges, bamboo bridges, moist curves',
    landmarks: ['Nohkalikai Falls', 'Double Decker Root Bridge', 'Dawki Umngot River'],
    recommendedBike: 'KTM Adventure / Hero Xpulse 200 4V / RE Scram 411',
    monsoonAlert: true,
    image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1200&q=80',
    roles: {
      leader: 'Bantei Khongwir',
      safetyOfficer: 'Mary Nongrum',
      mechanic: 'Northeast Moto Squad',
      photographer: 'Ricky Syiem',
    },
  },
];

interface IndiaExpeditionsProps {
  language: SupportedLanguage;
  onSelectRoute?: (route: ExpeditionRoute) => void;
  onOpenSos?: () => void;
}

export const IndiaExpeditions: React.FC<IndiaExpeditionsProps> = ({ language, onSelectRoute }) => {
  const [selectedRoute, setSelectedRoute] = useState<ExpeditionRoute>(EXPEDITIONS[0]);
  const [activePlan, setActivePlan] = useState<'planA' | 'planB'>('planA');
  const [filterWomenOnly, setFilterWomenOnly] = useState(false);
  const [downloadedRoutes, setDownloadedRoutes] = useState<Record<string, boolean>>({
    'leh-ladakh': true,
  });

  const filtered = filterWomenOnly ? EXPEDITIONS.filter(r => r.isWomenFocused) : EXPEDITIONS;

  const handleDownloadGpx = (routeId: string) => {
    setDownloadedRoutes(prev => ({
      ...prev,
      [routeId]: !prev[routeId],
    }));
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Filter Strip */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold tracking-wider uppercase mb-1">
              <CompassIcon className="w-4 h-4" />
              <span>{getTranslation('explore_routes', language)}</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
              Indian High-Altitude & Coastal Expeditions
            </h2>
            <p className="text-slate-400 text-sm mt-0.5">
              Collaborative convoy planning with assigned crew roles, GPX offline caching, and real-time Plan A / Plan B mountain detours.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setFilterWomenOnly(prev => !prev)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                filterWomenOnly
                  ? 'bg-fuchsia-600/30 border border-fuchsia-500 text-fuchsia-300 shadow-lg shadow-fuchsia-950/50'
                  : 'bg-slate-800 border border-slate-700 text-slate-300 hover:border-fuchsia-500/50'
              }`}
            >
              <FemaleIcon className="w-4 h-4 text-fuchsia-400" />
              <span>{getTranslation('women_riders', language)}</span>
              {filterWomenOnly && <span className="w-2 h-2 rounded-full bg-fuchsia-400 animate-pulse" />}
            </button>
          </div>
        </div>
      </div>

      {/* Route Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Route Selector List */}
        <div className="lg:col-span-5 space-y-3">
          {filtered.map(route => {
            const isSelected = selectedRoute.id === route.id;
            const isCached = downloadedRoutes[route.id];
            return (
              <div
                key={route.id}
                onClick={() => {
                  setSelectedRoute(route);
                  setActivePlan('planA');
                  if (onSelectRoute) onSelectRoute(route);
                }}
                className={`cursor-pointer rounded-2xl p-4 transition-all border ${
                  isSelected
                    ? 'bg-slate-800/95 border-amber-500/80 shadow-lg shadow-amber-500/10'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-amber-400">{route.region}</span>
                      <span className="text-slate-600">•</span>
                      <span className="text-xs text-slate-400">{route.state}</span>
                      {route.isWomenFocused && (
                        <span className="text-[10px] bg-fuchsia-950 text-fuchsia-300 px-1.5 py-0.5 rounded border border-fuchsia-800 font-semibold">
                          Women Bikers
                        </span>
                      )}
                    </div>
                    <h3 className="text-white font-bold text-base leading-snug">{route.title}</h3>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                      route.difficulty === 'Extreme'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : route.difficulty === 'Challenging'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}
                  >
                    {route.difficulty}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[10px]">DISTANCE</span>
                    <span className="text-slate-200 font-medium">{route.distanceKm} km</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">DURATION</span>
                    <span className="text-slate-200 font-medium">{route.durationDays}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">MAX ALTITUDE</span>
                    <span className="text-slate-200 font-medium">{route.altitudeFt.toLocaleString()} ft</span>
                  </div>
                </div>

                <div className="mt-2.5 flex items-center justify-between text-xs pt-2">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                    <ShieldAlertIcon className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Safety: <strong className="text-emerald-400">{route.safetyScore}/10</strong></span>
                  </div>

                  <span className={`text-[11px] font-medium flex items-center gap-1 ${isCached ? 'text-cyan-400' : 'text-slate-500'}`}>
                    <CheckIcon className="w-3 h-3" />
                    {isCached ? 'GPX Cached Offline' : 'Click to Cache GPX'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Active Route Details & Convoy Roles */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between">
          <div>
            {/* Header image banner with badges */}
            <div className="relative h-56 w-full overflow-hidden bg-slate-950">
              <img
                src={selectedRoute.image}
                alt={selectedRoute.title}
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

              <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                {selectedRoute.oxygenAlert && (
                  <div className="bg-rose-950/90 backdrop-blur-md border border-rose-600/80 text-rose-200 text-xs font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5">
                    <ShieldAlertIcon className="w-3.5 h-3.5 text-rose-400" />
                    <span>O2 Saturation Warning (&gt;14,000 ft)</span>
                  </div>
                )}
                {selectedRoute.monsoonAlert && (
                  <div className="bg-sky-950/90 backdrop-blur-md border border-sky-600/80 text-sky-200 text-xs font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5">
                    <ShieldAlertIcon className="w-3.5 h-3.5 text-sky-400" />
                    <span>Wet Weather & Ghat Fog Advisory</span>
                  </div>
                )}
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                <div>
                  <span className="text-amber-400 text-xs font-semibold uppercase tracking-wider">
                    {selectedRoute.region} • {selectedRoute.state}
                  </span>
                  <h3 className="text-white text-xl md:text-2xl font-black">{selectedRoute.title}</h3>
                </div>

                <button
                  onClick={() => handleDownloadGpx(selectedRoute.id)}
                  className={`text-xs px-3 py-1.5 rounded-lg font-medium border transition-colors flex items-center gap-1.5 backdrop-blur-md ${
                    downloadedRoutes[selectedRoute.id]
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                      : 'bg-slate-900/80 border-slate-600 text-slate-200 hover:border-amber-400'
                  }`}
                >
                  <RouteIcon className="w-3.5 h-3.5" />
                  <span>{downloadedRoutes[selectedRoute.id] ? 'GPX Saved (Offline)' : 'Download GPX'}</span>
                </button>
              </div>
            </div>

            {/* Plan A vs Plan B Navigation Strategy */}
            <div className="p-5 border-b border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Dynamic Mountain Detour Strategy
                </span>
                <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    onClick={() => setActivePlan('planA')}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                      activePlan === 'planA'
                        ? 'bg-amber-500 text-slate-950 shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Primary: Plan A
                  </button>
                  <button
                    onClick={() => setActivePlan('planB')}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                      activePlan === 'planB'
                        ? 'bg-cyan-500 text-slate-950 shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Weather Fallback: Plan B
                  </button>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                <p className="text-sm text-slate-200">
                  <strong className={activePlan === 'planA' ? 'text-amber-400' : 'text-cyan-400'}>
                    {activePlan === 'planA' ? 'Plan A Route: ' : 'Plan B Fallback: '}
                  </strong>
                  {activePlan === 'planA' ? selectedRoute.planA : selectedRoute.planB}
                </p>
                <div className="mt-2 text-xs text-slate-400 flex items-center gap-2">
                  <CompassIcon className="w-3.5 h-3.5 text-slate-500" />
                  <span>Terrain: {selectedRoute.terrain}</span>
                </div>
              </div>
            </div>

            {/* Assigned Convoy Roles */}
            <div className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Convoy Crew & Certified Roles
                </span>
                <span className="text-xs text-amber-400 font-medium">4 Verified Riders Assigned</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <CompassIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Lead Rider</span>
                    <span className="text-xs font-bold text-slate-200">{selectedRoute.roles.leader}</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <ShieldAlertIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Safety & Wilderness Medic</span>
                    <span className="text-xs font-bold text-slate-200">{selectedRoute.roles.safetyOfficer}</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <WrenchIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Expedition Mechanic</span>
                    <span className="text-xs font-bold text-slate-200">{selectedRoute.roles.mechanic}</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-fuchsia-500/10 border border-fuchsia-500/30 flex items-center justify-center text-fuchsia-400">
                    <CameraIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold">Trail Photographer</span>
                    <span className="text-xs font-bold text-slate-200">{selectedRoute.roles.photographer}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Landmark Badges */}
            <div className="px-5 pb-5">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-2">
                GPS Landmark Checkpoint Badges
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedRoute.landmarks.map((landmark, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium bg-slate-950 border border-slate-800 text-slate-300"
                  >
                    <TrophyIcon className="w-3.5 h-3.5 text-amber-400" />
                    <span>{landmark}</span>
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Action Footer */}
          <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-slate-400">
              <span>Recommended Machine: </span>
              <strong className="text-slate-200">{selectedRoute.recommendedBike}</strong>
            </div>

            <button
              onClick={() => {
                if (onSelectRoute) onSelectRoute(selectedRoute);
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20"
            >
              Join Convoy Ride
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
