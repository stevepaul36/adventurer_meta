
import React, { useState } from 'react';
import { CONVERSATIONS, CURRENT_USER } from '../constants';
import type { Conversation, Message } from '../types';
import { SendIcon } from './icons';

const ConversationItem: React.FC<{ convo: Conversation; isActive: boolean; onClick: () => void; }> = ({ convo, isActive, onClick }) => (
    <div onClick={onClick} className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors ${isActive ? 'bg-slate-800' : 'hover:bg-slate-800/50'}`}>
        <div className="relative">
            <img src={convo.participant.avatarUrl} alt={convo.participant.name} className="w-12 h-12 rounded-full"/>
            {!convo.lastMessage.isRead && convo.lastMessage.sender.id !== CURRENT_USER.id && (
                 <span className="absolute top-0 right-0 block h-3 w-3 rounded-full bg-orange-500 ring-2 ring-slate-900"></span>
            )}
        </div>
        <div className="flex-1 ml-4 overflow-hidden">
            <p className="font-bold text-white truncate">{convo.participant.name}</p>
            <p className={`text-sm truncate ${!convo.lastMessage.isRead && convo.lastMessage.sender.id !== CURRENT_USER.id ? 'text-white' : 'text-gray-400'}`}>
                {convo.lastMessage.text}
            </p>
        </div>
        <p className="text-xs text-gray-500">{convo.lastMessage.timestamp}</p>
    </div>
);

const ChatBubble: React.FC<{ message: Message; isMe: boolean }> = ({ message, isMe }) => (
    <div className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${isMe ? 'bg-orange-600 text-white rounded-br-none' : 'bg-slate-700 text-gray-200 rounded-bl-none'}`}>
            <p>{message.text}</p>
        </div>
    </div>
);

const MessagesPanel: React.FC = () => {
  const [activeConvo, setActiveConvo] = useState<Conversation>(CONVERSATIONS[0]);

  const DUMMY_MESSAGES: Message[] = [
    {id: 'd1', sender: activeConvo.participant, text: 'Hey, are we still on for the ride this weekend?', timestamp: '10:30', isRead: false},
    {id: 'd2', sender: CURRENT_USER, text: "Yeah, I'll send you the route details.", timestamp: '10:31', isRead: true},
  ];

  return (
    <div className="flex h-[calc(100vh-5rem)] bg-slate-900 rounded-lg overflow-hidden mb-20 md:mb-0">
      <div className="w-full md:w-2/5 lg:w-1/3 bg-slate-900 border-r border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-800">
            <h2 className="text-2xl font-bold text-white">Messages</h2>
        </div>
        <div className="flex-1 p-2 overflow-y-auto space-y-1">
            {CONVERSATIONS.map(convo => (
                <ConversationItem key={convo.id} convo={convo} isActive={activeConvo.id === convo.id} onClick={() => setActiveConvo(convo)} />
            ))}
        </div>
      </div>

      <div className="hidden md:flex flex-1 flex-col">
        <div className="flex items-center p-4 border-b border-slate-800">
            <img src={activeConvo.participant.avatarUrl} alt={activeConvo.participant.name} className="w-10 h-10 rounded-full"/>
            <p className="ml-3 font-bold text-lg text-white">{activeConvo.participant.name}</p>
        </div>
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
            {DUMMY_MESSAGES.map(msg => (
                <ChatBubble key={msg.id} message={msg} isMe={msg.sender.id === CURRENT_USER.id} />
            ))}
        </div>
        <div className="p-4 border-t border-slate-800 flex items-center space-x-2 bg-slate-900">
            <input type="text" placeholder="Type a message..." className="w-full bg-slate-800 rounded-full py-3 px-5 focus:outline-none focus:ring-2 focus:ring-orange-500" />
            <button className="bg-orange-600 text-white p-3 rounded-full hover:bg-orange-700 transition-colors"><SendIcon/></button>
        </div>
      </div>
    </div>
  );
};

export default MessagesPanel;
