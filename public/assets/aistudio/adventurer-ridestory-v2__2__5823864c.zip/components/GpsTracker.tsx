
import React, { useState, useEffect } from 'react';
import { BackIcon, PauseIcon, PlayIcon, LocateIcon, SparklesIcon } from './icons';
import type { SavedRide, RideAnalysisStats } from '../types';
import { generateRideInsights } from '../services/aiService';
import { gamificationService } from '../services/gamificationService';


const Stat: React.FC<{ label: string; value: string; unit: string; }> = ({label, value, unit}) => (
    <div className="text-center">
        <p className="text-sm text-gray-400">{label}</p>
        <p className="text-4xl font-bold text-white tracking-tight">{value}</p>
        <p className="text-lg text-gray-300">{unit}</p>
    </div>
);

const ConfirmationModal: React.FC<{ onConfirm: () => void; onCancel: () => void; }> = ({ onConfirm, onCancel }) => (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in">
        <div className="bg-slate-800 rounded-lg p-8 m-4 max-w-sm w-full text-center shadow-lg">
            <h2 className="text-2xl font-bold text-white mb-2">End Ride?</h2>
            <p className="text-gray-400 mb-6">Are you sure you want to end this ride?</p>
            <div className="flex justify-center space-x-4">
                <button 
                    onClick={onCancel}
                    className="bg-slate-700 text-white font-bold py-3 px-6 rounded-full hover:bg-slate-600 transition-colors"
                >
                    Cancel
                </button>
                <button 
                    onClick={onConfirm}
                    className="bg-red-600 text-white font-bold py-3 px-6 rounded-full hover:bg-red-700 transition-colors"
                >
                    Yes, End Ride
                </button>
            </div>
        </div>
    </div>
);

const AnalysisModal: React.FC<{ stats: RideAnalysisStats; onSave: () => void }> = ({ stats, onSave }) => {
    const [isLoading, setIsLoading] = useState(true);
    const [insights, setInsights] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        const getInsights = async () => {
            try {
                const result = await generateRideInsights(stats);
                setInsights(result);
            } catch (e) {
                setError(e instanceof Error ? e.message : 'Could not get insights.');
            } finally {
                setIsLoading(false);
            }
        };
        getInsights();
    }, [stats]);

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in">
            <div className="bg-slate-800 rounded-lg p-8 m-4 max-w-sm w-full text-center shadow-lg">
                <SparklesIcon className="w-12 h-12 text-orange-400 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-white mb-2">AI Ride Analysis</h2>
                <div className="min-h-[100px] flex items-center justify-center my-4">
                    {isLoading && <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>}
                    {error && <p className="text-red-400">{error}</p>}
                    {insights && <p className="text-gray-300">{insights}</p>}
                </div>
                <button 
                    onClick={onSave}
                    className="bg-orange-600 text-white font-bold py-3 px-6 rounded-full hover:bg-orange-700 transition-colors disabled:bg-slate-600"
                    disabled={isLoading}
                >
                    {isLoading ? 'Analyzing...' : 'Save Ride & Close'}
                </button>
            </div>
        </div>
    );
};


interface GpsTrackerProps {
    onBack: () => void;
}

const GpsTracker: React.FC<GpsTrackerProps> = ({ onBack }) => {
    const [rideState, setRideState] = useState<'recording' | 'paused'>('recording');
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [showAnalysisModal, setShowAnalysisModal] = useState(false);
    
    // Using mock data for demonstration
    const MOCK_RIDE_STATS: RideAnalysisStats = { distance: 72.4, duration: '1h 34m', speed: 88 };

    const handleTogglePause = () => {
        setRideState(prevState => prevState === 'recording' ? 'paused' : 'recording');
    };

    const handleEndRideRequest = () => {
        setShowConfirmModal(true);
    };
    
    const handleConfirmEndRide = () => {
        setShowConfirmModal(false);
        setShowAnalysisModal(true);
    };
    
    const handleSaveAndClose = () => {
        const newRide: SavedRide = {
            id: new Date().toISOString(),
            date: new Date().toISOString(),
            title: `Ride - ${new Date().toLocaleString()}`,
            distance: MOCK_RIDE_STATS.distance,
            duration: MOCK_RIDE_STATS.duration,
            mapImageUrl: `https://picsum.photos/seed/${Date.now()}/400/200`,
        };

        try {
            const ridesJSON = localStorage.getItem('adventurer_rides');
            const rides = ridesJSON ? JSON.parse(ridesJSON) : [];
            rides.unshift(newRide);
            localStorage.setItem('adventurer_rides', JSON.stringify(rides));
        } catch (error) {
            console.error("Failed to save ride:", error);
        }

        // Award gamification progress
        gamificationService.recordActivityProgress({
            distanceKm: MOCK_RIDE_STATS.distance,
            speedKmH: MOCK_RIDE_STATS.speed,
            elevationM: 450,
        });
        
        setShowAnalysisModal(false);
        onBack();
    };

    const [locationToast, setLocationToast] = useState(false);

    const handleRecenter = () => {
        setLocationToast(true);
        setTimeout(() => setLocationToast(false), 2000);
    };

  return (
    <>
        <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col">
            <div className="flex-1 bg-gray-700 relative">
                <img src="https://picsum.photos/seed/map/1200/800" alt="Map of ride" className="w-full h-full object-cover opacity-50"/>
                <button onClick={onBack} className="absolute top-4 left-4 bg-black bg-opacity-50 hover:bg-opacity-75 text-white p-2 rounded-full transition-colors z-10">
                    <BackIcon className="w-6 h-6"/>
                </button>
                {locationToast && (
                    <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 text-white text-xs px-3 py-1.5 rounded-full z-10 animate-fade-in shadow-md">
                        Map re-centered on your GPS location
                    </div>
                )}
                <button 
                    onClick={handleRecenter}
                    className="absolute bottom-4 right-4 bg-black bg-opacity-50 hover:bg-opacity-75 text-white p-2 rounded-full transition-colors z-10"
                    aria-label="Center map on current location"
                >
                    <LocateIcon className="w-6 h-6"/>
                </button>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    {rideState === 'recording' && (
                        <p className="text-white text-2xl font-bold bg-black/50 p-4 rounded-lg animate-fade-in">GPS Tracking Active</p>
                    )}
                    {rideState === 'paused' && (
                        <p className="text-white text-3xl font-bold bg-black/50 p-6 rounded-lg animate-fade-in">Ride Paused</p>
                    )}
                </div>
            </div>
            <div className="grid grid-cols-3 gap-4 p-6 border-t border-slate-800 bg-slate-900/80 backdrop-blur-sm">
                <Stat label="Speed" value={String(MOCK_RIDE_STATS.speed)} unit="km/h" />
                <Stat label="Distance" value={String(MOCK_RIDE_STATS.distance)} unit="km" />
                <Stat label="Duration" value="1:34" unit="h:m" />
            </div>
            <div className="p-4 flex justify-around items-center bg-slate-900">
                <button 
                    onClick={handleTogglePause} 
                    className="bg-slate-700 text-white p-4 rounded-full hover:bg-slate-600 transition-colors"
                    aria-label={rideState === 'recording' ? 'Pause ride' : 'Resume ride'}
                >
                    {rideState === 'recording' ? <PauseIcon className="w-8 h-8"/> : <PlayIcon className="w-8 h-8"/>}
                </button>
                <button 
                    onClick={handleEndRideRequest} 
                    className="bg-red-600 text-white font-bold py-4 px-10 rounded-full hover:bg-red-700 transition-colors"
                >
                    End Ride
                </button>
            </div>
        </div>
        {showConfirmModal && <ConfirmationModal onConfirm={handleConfirmEndRide} onCancel={() => setShowConfirmModal(false)} />}
        {showAnalysisModal && <AnalysisModal stats={MOCK_RIDE_STATS} onSave={handleSaveAndClose} />}
    </>
  );
};

export default GpsTracker;