
import React, { useState } from 'react';
import type { Post, Comment } from '../types';
import { HeartIcon, CommentIcon, ShareIcon, MapPinIcon, ClockIcon, ArrowUpIcon, RepostIcon, LinkIcon, SendIcon } from './icons';
import { CURRENT_USER } from '../constants';

interface PostCardProps {
    post: Post;
    onUserSelect: (userId: string) => void;
}

const RideStat: React.FC<{ icon: React.ReactNode; label: string; value: string | number }> = ({ icon, label, value }) => (
    <div className="flex items-center space-x-2 text-gray-400">
        <div className="bg-slate-800 p-2 rounded-full">{icon}</div>
        <div>
            <p className="text-xs">{label}</p>
            <p className="font-bold text-sm text-white">{value}</p>
        </div>
    </div>
);

const PostCard: React.FC<PostCardProps> = ({ post, onUserSelect }) => {
  const [isShareMenuOpen, setIsShareMenuOpen] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [comments, setComments] = useState<Comment[]>(post.comments);
  const [newComment, setNewComment] = useState('');

  const handleLikeClick = () => {
      setIsLiked(!isLiked);
      setLikeCount(prevCount => isLiked ? prevCount - 1 : prevCount + 1);
  };

  const handleShareClick = () => {
    setIsShareMenuOpen(!isShareMenuOpen);
  };

  const handleShareOptionClick = (option: string) => {
    // In a real app, this would trigger navigator.clipboard.writeText or a network request.
    alert(`${option} successful!`);
    setIsShareMenuOpen(false);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (newComment.trim()) {
          const newCommentObject: Comment = {
              id: `c-${Date.now()}`,
              user: CURRENT_USER,
              text: newComment.trim(),
          };
          setComments(prevComments => [...prevComments, newCommentObject]);
          setNewComment('');
      }
  };

  return (
    <div className="bg-slate-900 rounded-lg overflow-hidden shadow-lg">
      <div className="p-4">
        <button onClick={() => onUserSelect(post.user.id)} className="flex items-center text-left group w-full">
            <img src={post.user.avatarUrl} alt={post.user.name} className="w-12 h-12 rounded-full mr-4 transition-all duration-300 group-hover:ring-2 group-hover:ring-orange-500" />
            <div className="flex-1">
                <p className="font-bold text-white transition-colors group-hover:text-orange-400">{post.user.name}</p>
                <p className="text-sm text-gray-500">{post.timestamp}</p>
            </div>
        </button>
        <p className="text-gray-300 mt-4">{post.caption}</p>
      </div>
      {post.imageUrl && <img src={post.imageUrl} alt="Ride" className="w-full h-auto object-cover" />}
      {post.rideStats && (
        <div className="grid grid-cols-3 gap-4 p-4 bg-slate-800/50">
           <RideStat icon={<MapPinIcon className="w-5 h-5 text-orange-400"/>} label="Distance" value={`${post.rideStats.distance} km`} />
           <RideStat icon={<ClockIcon className="w-5 h-5 text-orange-400"/>} label="Duration" value={post.rideStats.duration} />
           <RideStat icon={<ArrowUpIcon className="w-5 h-5 text-orange-400"/>} label="Elevation" value={`${post.rideStats.elevation} m`} />
        </div>
      )}
      <div className="flex justify-around items-center p-2 border-t border-slate-800">
        <button
            onClick={handleLikeClick}
            className={`flex items-center space-x-2 transition-colors ${isLiked ? 'text-orange-500' : 'text-gray-400 hover:text-orange-500'}`}
            aria-pressed={isLiked}
            aria-label={isLiked ? 'Unlike post' : 'Like post'}
        >
            <HeartIcon className="w-5 h-5" fill={isLiked ? 'currentColor' : 'none'}/> <span>{likeCount}</span>
        </button>
        <button 
            onClick={() => setIsCommentsOpen(!isCommentsOpen)}
            className="flex items-center space-x-2 text-gray-400 hover:text-orange-500 transition-colors"
            aria-expanded={isCommentsOpen}
        >
            <CommentIcon className="w-5 h-5"/> <span>{comments.length}</span>
        </button>
        
        <div className="relative">
            <button 
                onClick={handleShareClick}
                className="flex items-center space-x-2 text-gray-400 hover:text-orange-500 transition-colors"
                aria-haspopup="true"
                aria-expanded={isShareMenuOpen}
            >
                <ShareIcon className="w-5 h-5"/> <span>Share</span>
            </button>
            
            {isShareMenuOpen && (
                 <>
                    {/* Backdrop to close menu on outside click */}
                    <div className="fixed inset-0 z-10" onClick={() => setIsShareMenuOpen(false)}></div>
                    <div 
                        className="absolute bottom-full mb-2 w-56 bg-slate-800 rounded-lg shadow-lg p-2 z-20 left-1/2 -translate-x-1/2 animate-fade-in"
                        role="menu"
                    >
                        <button 
                            onClick={() => handleShareOptionClick('Share to profile')}
                            className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                            role="menuitem"
                        >
                            <RepostIcon className="w-5 h-5 text-green-400"/>
                            <span>Share to your Profile</span>
                        </button>
                         <button 
                            onClick={() => handleShareOptionClick('Copy link')}
                            className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                            role="menuitem"
                        >
                            <LinkIcon className="w-5 h-5 text-blue-400"/>
                            <span>Copy Link</span>
                        </button>
                    </div>
                </>
            )}
        </div>
      </div>
      {isCommentsOpen && (
          <div className="p-4 space-y-3 border-t border-slate-800 animate-fade-in">
            {comments.map(comment => (
                <div key={comment.id} className="flex items-start space-x-3">
                    <img src={comment.user.avatarUrl} alt={comment.user.name} className="w-8 h-8 rounded-full"/>
                    <div className="bg-slate-800 rounded-lg p-2 flex-1">
                        <button onClick={() => onUserSelect(comment.user.id)} className="font-semibold text-sm text-white hover:underline">{comment.user.name}</button>
                        <p className="text-sm text-gray-300">{comment.text}</p>
                    </div>
                </div>
            ))}
            {comments.length === 0 && <p className="text-center text-sm text-gray-500 py-2">No comments yet.</p>}
             <form onSubmit={handleCommentSubmit} className="flex items-center space-x-3 pt-2">
                <img src={CURRENT_USER.avatarUrl} alt={CURRENT_USER.name} className="w-8 h-8 rounded-full"/>
                 <div className="flex-1 relative">
                    <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Add a comment..."
                        className="w-full bg-slate-800 rounded-full py-2 pl-4 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-orange-500">
                        <SendIcon className="w-5 h-5" />
                    </button>
                 </div>
             </form>
          </div>
      )}
    </div>
  );
};

export default PostCard;