
import React from 'react';
import type { Stream, ChatMessage } from '../types';
import { USERS } from '../constants';
import { BackIcon, SendIcon, HeartIcon } from './icons';

const DUMMY_CHAT: ChatMessage[] = [
    { id: 'cm1', user: USERS.u2, message: 'This is an awesome view!', isReaction: false },
    { id: 'cm2', user: USERS.u3, message: 'So cool!', isReaction: false },
    { id: 'cm3', user: USERS.u4, message: '❤️', isReaction: true },
    { id: 'cm4', user: USERS.u5, message: 'Where is this?', isReaction: false },
];

interface StreamViewerProps {
    stream: Stream;
    onBack: () => void;
}

const StreamViewer: React.FC<StreamViewerProps> = ({ stream, onBack }) => {
  return (
    <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col md:flex-row">
      <div className="flex-1 flex flex-col">
        <div className="relative w-full aspect-video bg-black">
          <img src={stream.thumbnailUrl.replace('/400/225', '/1280/720')} alt="Live Stream" className="w-full h-full object-cover"/>
          <button onClick={onBack} className="absolute top-4 left-4 bg-black bg-opacity-50 hover:bg-opacity-75 text-white p-2 rounded-full transition-colors">
            <BackIcon className="w-6 h-6"/>
          </button>
        </div>
        <div className="p-4 border-b border-slate-800">
            <h2 className="text-2xl font-bold text-white">{stream.title}</h2>
            <div className="flex items-center space-x-4 mt-2">
                <img src={stream.streamer.avatarUrl} alt={stream.streamer.name} className="w-12 h-12 rounded-full" />
                <div>
                    <p className="font-semibold text-white">{stream.streamer.name}</p>
                    <p className="text-sm text-red-500 font-bold">{stream.viewers.toLocaleString()} viewers</p>
                </div>
            </div>
        </div>
      </div>

      <div className="w-full md:w-96 bg-slate-900 flex flex-col border-l border-slate-800">
        <div className="p-4 border-b border-slate-800">
            <h3 className="font-bold text-white text-lg">Live Chat</h3>
        </div>
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {DUMMY_CHAT.map(chat => (
                <div key={chat.id} className="flex items-start space-x-2 text-sm">
                    <img src={chat.user.avatarUrl} alt={chat.user.name} className="w-6 h-6 rounded-full"/>
                    <div className="flex-1">
                        <span className="font-semibold text-gray-400 mr-2">{chat.user.name}</span>
                        <span className="text-gray-200">{chat.message}</span>
                    </div>
                </div>
            ))}
        </div>
        <div className="p-4 border-t border-slate-800 flex items-center space-x-2">
            <input type="text" placeholder="Send a message" className="w-full bg-slate-800 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-orange-500" />
            <button className="text-gray-400 hover:text-orange-500 p-2 rounded-full"><HeartIcon/></button>
            <button className="bg-orange-600 text-white p-2 rounded-full hover:bg-orange-700"><SendIcon/></button>
        </div>
      </div>
    </div>
  );
};

export default StreamViewer;
