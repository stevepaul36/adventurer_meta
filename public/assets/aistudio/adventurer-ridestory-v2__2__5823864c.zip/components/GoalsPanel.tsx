
import React from 'react';
import { RIDING_GOALS } from '../constants';
import type { Journey, RidingGoal } from '../types';

interface GoalsPanelProps {
    journeys: Journey[];
}

const GoalProgress: React.FC<{ goal: RidingGoal, current: number }> = ({ goal, current }) => {
    const progress = Math.min((current / goal.target) * 100, 100);
    const unit = goal.type === 'count' ? '' : 'km';

    return (
        <div>
            <div className="flex justify-between items-baseline mb-1">
                <div className="flex items-center space-x-2">
                    <goal.icon className="w-5 h-5 text-orange-400" />
                    <h4 className="font-bold text-white">{goal.name}</h4>
                </div>
                <span className="text-sm font-semibold text-gray-400">
                    {current.toLocaleString()}/{goal.target.toLocaleString()}{unit}
                </span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2.5">
                <div
                    className="bg-orange-500 h-2.5 rounded-full"
                    style={{ width: `${progress}%` }}
                ></div>
            </div>
        </div>
    );
};

const GoalsPanel: React.FC<GoalsPanelProps> = ({ journeys }) => {
    const stats = journeys.reduce(
        (acc, journey) => {
            acc.totalDistance += journey.distance;
            acc.totalElevation += journey.elevation;
            return acc;
        },
        { totalDistance: 0, totalElevation: 0, rideCount: journeys.length }
    );

    const getProgressForGoal = (goal: RidingGoal) => {
        switch (goal.type) {
            case 'distance': return stats.totalDistance;
            case 'elevation': return stats.totalElevation;
            case 'count': return stats.rideCount;
            default: return 0;
        }
    };

    return (
        <div className="bg-slate-900 rounded-lg p-4 shadow-lg">
            <h3 className="text-xl font-bold text-white mb-4">Riding Goals</h3>
            <div className="space-y-4">
                {RIDING_GOALS.map(goal => (
                    <GoalProgress key={goal.id} goal={goal} current={getProgressForGoal(goal)} />
                ))}
            </div>
        </div>
    );
};

export default GoalsPanel;
