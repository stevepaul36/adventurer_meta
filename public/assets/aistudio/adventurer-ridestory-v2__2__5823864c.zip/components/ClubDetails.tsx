import React, { useState } from 'react';
import type { Club, AI_Route, ClubChallenge, LeaderboardEntry } from '../types';
import { generateGroupJourney } from '../services/aiService';
import { CLUBS, CLUB_CHALLENGES, CLUB_LEADERBOARDS, CURRENT_USER } from '../constants';
import { BackIcon, UsersIcon, TrophyIcon, SendIcon, RouteIcon, SparklesIcon, RoadIcon, MountainIcon, SwordsIcon } from './icons';
import CreateClubChallenge from './CreateClubChallenge';

const GoalProgress: React.FC<{ goal: Club['goals'][0] }> = ({ goal }) => {
    const progress = Math.min((goal.current / goal.target) * 100, 100);
    return (
        <div>
            <div className="flex justify-between items-baseline mb-1">
                <div className="flex items-center space-x-2">
                    <goal.icon className="w-5 h-5 text-orange-400" />
                    <h4 className="font-bold text-white text-sm">{goal.name}</h4>
                </div>
                <span className="text-xs font-semibold text-gray-400">
                    {goal.current.toLocaleString()}/{goal.target.toLocaleString()}
                </span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2">
                <div className="bg-orange-500 h-2 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
        </div>
    );
};

const ChallengeCard: React.FC<{ challenge: ClubChallenge; isHistory: boolean }> = ({ challenge, isHistory }) => {
    const [clubAData, clubBData] = challenge.competingClubs;
    const clubA = CLUBS.find(c => c.id === clubAData.clubId);
    const clubB = CLUBS.find(c => c.id === clubBData.clubId);

    if (!clubA || !clubB) return null;
    
    const totalProgress = clubAData.progress + clubBData.progress;
    const progressAPercentage = totalProgress > 0 ? (clubAData.progress / totalProgress) * 100 : 50;

    const unit = challenge.type === 'distance' ? 'km' : challenge.type === 'elevation' ? 'm' : 'rides';

    const getTimeRemaining = (endDate: Date) => {
        const total = endDate.getTime() - new Date().getTime();
        if (total < 0) return 'Ended';
        const days = Math.floor(total / (1000 * 60 * 60 * 24));
        const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
        if (days > 0) return `Ends in ${days} day${days > 1 ? 's' : ''}`;
        return `Ends in ${hours} hour${hours > 1 ? 's' : ''}`;
    };

    const WinnerBadge: React.FC<{ clubId: string }> = ({ clubId }) => (
        challenge.winnerClubId === clubId ? (
            <div className="flex items-center space-x-1 bg-yellow-500/20 text-yellow-400 text-xs font-bold px-2 py-0.5 rounded-full">
                <TrophyIcon className="w-3 h-3" />
                <span>WINNER</span>
            </div>
        ) : null
    );

    return (
        <div className="bg-slate-800/50 rounded-lg p-4">
            <div className="flex justify-between items-start">
                <div>
                    <h4 className="font-bold text-white">{challenge.title}</h4>
                    <p className="text-xs text-gray-400 mb-2">{challenge.description}</p>
                </div>
                <span className="text-xs text-gray-500 font-semibold flex-shrink-0 ml-2">{isHistory ? `Ended ${challenge.endDate.toLocaleDateString()}`: getTimeRemaining(challenge.endDate)}</span>
            </div>

            <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-2">
                        <img src={clubA.badgeUrl} alt={clubA.name} className="w-6 h-6 rounded-md" />
                        <span className="font-semibold">{clubA.name}</span>
                        {isHistory && <WinnerBadge clubId={clubA.id} />}
                    </div>
                    <span className="font-bold">{clubAData.progress.toLocaleString()} {unit}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                     <div className="flex items-center space-x-2">
                        <img src={clubB.badgeUrl} alt={clubB.name} className="w-6 h-6 rounded-md" />
                        <span className="font-semibold">{clubB.name}</span>
                         {isHistory && <WinnerBadge clubId={clubB.id} />}
                    </div>
                    <span className="font-bold">{clubBData.progress.toLocaleString()} {unit}</span>
                </div>
            </div>
             <div className="flex w-full h-3 bg-slate-700 rounded-full overflow-hidden mt-3">
                <div className="bg-orange-500 h-full" style={{ width: `${progressAPercentage}%` }}></div>
                <div className="bg-blue-500 h-full" style={{ width: `${100 - progressAPercentage}%` }}></div>
            </div>
        </div>
    );
};

const AIGroupPlanner: React.FC<{ club: Club }> = ({ club }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [route, setRoute] = useState<AI_Route | null>(null);

    const handleGenerate = async () => {
        if (!prompt) return;
        setIsLoading(true);
        setError(null);
        setRoute(null);
        try {
            const result = await generateGroupJourney(prompt, 'Motorcycling', club.memberCount);
            setRoute(result);
        } catch (e) {
            setError(e instanceof Error ? e.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="bg-slate-800/50 rounded-lg p-4">
            <h4 className="font-bold text-white mb-2 flex items-center"><SparklesIcon className="w-5 h-5 mr-2 text-orange-400" /> AI Group Journey Planner</h4>
            {!route ? (
                <>
                    <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder={`e.g., A scenic half-day ride for our group of ${club.memberCount} starting near our city.`}
                        className="w-full h-24 bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-orange-500 resize-none"
                        disabled={isLoading}
                    />
                    <button onClick={handleGenerate} disabled={isLoading || !prompt} className="w-full bg-orange-600 text-white font-semibold py-2 px-3 rounded-lg hover:bg-orange-700 transition-colors text-sm disabled:bg-slate-600 mt-2">
                        {isLoading ? 'Generating...' : 'Plan Journey'}
                    </button>
                    {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
                </>
            ) : (
                <div className="animate-fade-in">
                    <h5 className="font-bold text-orange-400">{route.title}</h5>
                    <p className="text-xs text-gray-300 mb-2">{route.description}</p>
                    <ul className="text-xs space-y-1 pl-4 list-disc text-gray-400">
                        {route.waypoints.slice(0, 3).map((wp, i) => <li key={i}>{wp}</li>)}
                         {route.waypoints.length > 3 && <li>...and more!</li>}
                    </ul>
                    <button onClick={() => setRoute(null)} className="text-center w-full text-xs text-gray-500 hover:text-white mt-2">Plan another</button>
                </div>
            )}
        </div>
    );
};

const ClubLeaderboardList: React.FC<{ entries: LeaderboardEntry[]; unit: string; onUserSelect: (userId: string) => void; }> = ({ entries, unit, onUserSelect }) => (
    <div className="space-y-2 animate-fade-in mt-3">
        {entries.map(entry => (
            <div 
                key={entry.user.id} 
                className={`flex items-center p-2 rounded-md ${entry.user.id === CURRENT_USER.id ? 'bg-orange-900/50' : 'bg-slate-900/50'}`}
            >
                <div className="w-6 text-center font-bold text-gray-400">{entry.rank}</div>
                <button onClick={() => onUserSelect(entry.user.id)} className="flex items-center text-left group flex-1 mx-2">
                    <img src={entry.user.avatarUrl} alt={entry.user.name} className="w-8 h-8 rounded-full mr-2 group-hover:ring-1 group-hover:ring-orange-500 transition-ring" />
                    <div>
                        <p className="font-semibold text-white text-sm group-hover:text-orange-400 transition-colors">{entry.user.name}</p>
                        {entry.user.id === CURRENT_USER.id && <p className="text-xs text-orange-400 -mt-1">You</p>}
                    </div>
                </button>
                <div className="text-right">
                    <p className="font-bold text-white text-sm">{entry.value.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">{unit}</p>
                </div>
            </div>
        ))}
        {entries.length === 0 && (
            <p className="text-center text-sm text-gray-500 py-4">No activity logged for this category yet.</p>
        )}
    </div>
);

interface ClubDetailsProps {
    club: Club;
    onBack: () => void;
    onUserSelect: (userId: string) => void;
}

const ClubDetails: React.FC<ClubDetailsProps> = ({ club, onBack, onUserSelect }) => {
    const [showCreateChallenge, setShowCreateChallenge] = useState(false);
    const [activeChallengeTab, setActiveChallengeTab] = useState<'active' | 'history'>('active');
    const [activeLeaderboard, setActiveLeaderboard] = useState<'distance' | 'elevation' | 'rides'>('distance');
    
    const leaderboards = CLUB_LEADERBOARDS[club.id];
    const isCurrentUserAdmin = club.members.some(m => m.user.id === CURRENT_USER.id && m.role === 'Admin');

    const now = new Date();
    const allClubChallenges = CLUB_CHALLENGES.filter(c => c.competingClubs.some(cc => cc.clubId === club.id));
    const activeChallenges = allClubChallenges.filter(c => c.endDate > now);
    const pastChallenges = allClubChallenges.filter(c => c.endDate <= now);

    const leaderboardCategories = [
        { id: 'distance' as const, label: 'Distance', icon: RoadIcon, data: leaderboards.distance, unit: 'km' },
        { id: 'elevation' as const, label: 'Elevation', icon: MountainIcon, data: leaderboards.elevation, unit: 'm' },
        { id: 'rides' as const, label: 'Rides', icon: TrophyIcon, data: leaderboards.rides, unit: 'rides' },
    ];
    const activeLeaderboardData = leaderboardCategories.find(c => c.id === activeLeaderboard);
    
    return (
        <>
            <div className="bg-slate-900 rounded-lg overflow-hidden mb-20 md:mb-0 animate-fade-in">
                <header className="p-4 flex items-center space-x-4 border-b border-slate-800">
                    <button onClick={onBack} className="text-white p-2 rounded-full hover:bg-slate-800 transition-colors">
                        <BackIcon className="w-6 h-6"/>
                    </button>
                    <img src={club.badgeUrl} alt={`${club.name} badge`} className="w-12 h-12 rounded-lg" />
                    <div>
                        <h2 className="text-2xl font-bold text-white">{club.name}</h2>
                        <p className="text-gray-400 text-sm">{club.description}</p>
                    </div>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4">
                    {/* Left Column */}
                    <div className="md:col-span-2 space-y-6">
                        
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <div className="flex justify-between items-center mb-3">
                                <h3 className="font-bold text-white text-lg">Club Challenges</h3>
                                {isCurrentUserAdmin && (
                                    <button onClick={() => setShowCreateChallenge(true)} className="flex items-center space-x-2 bg-orange-600 text-white font-semibold py-1 px-3 rounded-full text-xs hover:bg-orange-700 transition-colors">
                                        <SwordsIcon className="w-4 h-4" />
                                        <span>Create Challenge</span>
                                    </button>
                                )}
                            </div>
                             <div className="flex border-b border-slate-700">
                                <button
                                    onClick={() => setActiveChallengeTab('active')}
                                    className={`flex-1 flex items-center justify-center space-x-2 py-2 text-sm font-semibold transition-colors ${activeChallengeTab === 'active' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-gray-400 hover:text-white border-b-2 border-transparent'}`}
                                >
                                    <span>Active</span>
                                </button>
                                <button
                                    onClick={() => setActiveChallengeTab('history')}
                                    className={`flex-1 flex items-center justify-center space-x-2 py-2 text-sm font-semibold transition-colors ${activeChallengeTab === 'history' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-gray-400 hover:text-white border-b-2 border-transparent'}`}
                                >
                                    <span>History</span>
                                </button>
                            </div>
                            <div className="mt-4 space-y-4">
                                {activeChallengeTab === 'active' && (
                                    activeChallenges.length > 0 
                                    ? activeChallenges.map(c => <ChallengeCard key={c.id} challenge={c} isHistory={false} />)
                                    : <p className="text-center text-sm text-gray-500 py-4">No active challenges. {isCurrentUserAdmin ? "Why not create one?" : ""}</p>
                                )}
                                {activeChallengeTab === 'history' && (
                                    pastChallenges.length > 0 
                                    ? pastChallenges.map(c => <ChallengeCard key={c.id} challenge={c} isHistory={true} />)
                                    : <p className="text-center text-sm text-gray-500 py-4">No past challenges to show.</p>
                                )}
                            </div>
                        </div>

                        {/* Leaderboards */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <h3 className="font-bold text-white mb-2 text-lg">Club Leaderboards</h3>
                            <div className="flex border-b border-slate-700">
                                {leaderboardCategories.map(cat => (
                                    <button
                                        key={cat.id}
                                        onClick={() => setActiveLeaderboard(cat.id)}
                                        className={`flex-1 flex items-center justify-center space-x-2 py-2 text-xs font-semibold transition-colors ${
                                            activeLeaderboard === cat.id 
                                            ? 'text-orange-500 border-b-2 border-orange-500' 
                                            : 'text-gray-400 hover:text-white border-b-2 border-transparent'
                                        }`}
                                    >
                                        <cat.icon className="w-4 h-4" />
                                        <span>{cat.label}</span>
                                    </button>
                                ))}
                            </div>
                            {activeLeaderboardData && (
                                <ClubLeaderboardList entries={activeLeaderboardData.data} unit={activeLeaderboardData.unit} onUserSelect={onUserSelect} />
                            )}
                        </div>
                        
                        {/* Goals */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <h3 className="font-bold text-white mb-3 text-lg">Club Goals</h3>
                            <div className="space-y-3">
                                {club.goals.map(goal => <GoalProgress key={goal.id} goal={goal} />)}
                            </div>
                        </div>

                        {/* Achievements */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <h3 className="font-bold text-white mb-3 text-lg">Club Achievements</h3>
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                                {club.achievements.map(ach => (
                                    <div key={ach.id} className={`text-center group ${!ach.isUnlocked && 'opacity-40'}`} title={ach.description}>
                                        <ach.icon className={`w-12 h-12 mx-auto ${ach.isUnlocked ? 'text-yellow-400' : 'text-gray-500'} transition-transform group-hover:scale-110`} />
                                        <p className="text-xs font-semibold mt-1">{ach.name}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                        
                        <AIGroupPlanner club={club} />
                    </div>

                    {/* Right Column */}
                    <div className="space-y-6">
                        {/* Members */}
                        <div className="bg-slate-800/50 rounded-lg p-4">
                            <h3 className="font-bold text-white mb-3 text-lg flex items-center">
                                <UsersIcon className="w-5 h-5 mr-2" /> Members ({club.memberCount})
                            </h3>
                            <div className="space-y-2 max-h-48 overflow-y-auto">
                                {club.members.map(member => (
                                    <button key={member.user.id} onClick={() => onUserSelect(member.user.id)} className="w-full flex items-center space-x-2 text-left hover:bg-slate-700 p-1 rounded-md">
                                        <img src={member.user.avatarUrl} alt={member.user.name} className="w-8 h-8 rounded-full" />
                                        <span className="text-sm font-medium">{member.user.name}</span>
                                        {member.role === 'Admin' && <span className="text-xs bg-orange-500/50 text-orange-300 px-1.5 py-0.5 rounded-full">Admin</span>}
                                    </button>
                                ))}
                            </div>
                        </div>
                        {/* Chat */}
                        <div className="bg-slate-800/50 rounded-lg flex flex-col h-96">
                            <h3 className="font-bold text-white p-4 border-b border-slate-700 text-lg">Club Chat</h3>
                            <div className="flex-1 p-4 space-y-3 overflow-y-auto">
                            {club.chat.map(msg => (
                                <div key={msg.id} className="flex items-start space-x-2">
                                    <img src={msg.user.avatarUrl} alt={msg.user.name} className="w-6 h-6 rounded-full mt-1" />
                                    <div>
                                        <p className="text-xs text-gray-400">{msg.user.name} <span className="ml-2 text-gray-500">{msg.timestamp}</span></p>
                                        <p className="text-sm bg-slate-900/70 p-2 rounded-lg inline-block">{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                            </div>
                            <div className="p-2 border-t border-slate-700">
                                <div className="relative">
                                    <input type="text" placeholder="Message club..." className="w-full bg-slate-700 rounded-full py-2 pl-4 pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-orange-500" />
                                    <button className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-orange-500">
                                        <SendIcon className="w-5 h-5" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {showCreateChallenge && <CreateClubChallenge club={club} onBack={() => setShowCreateChallenge(false)} onCreateChallenge={() => { alert('Challenge has been sent!'); setShowCreateChallenge(false); }} />}
        </>
    );
};

export default ClubDetails;