import React, { useState } from 'react';
import type { FriendRequest, User } from '../types';
import { USERS } from '../constants';
import { BackIcon, CheckIcon, XIcon, UsersIcon } from './icons';

interface FriendRequestsPanelProps {
    onBack: () => void;
    onUserSelect: (userId: string) => void;
    requests: FriendRequest[];
    friends: string[];
    onAccept: (userId: string) => void;
    onDecline: (userId: string) => void;
}

type Tab = 'requests' | 'friends';

const FriendRequestsPanel: React.FC<FriendRequestsPanelProps> = ({ onBack, onUserSelect, requests, friends, onAccept, onDecline }) => {
    const [activeTab, setActiveTab] = useState<Tab>('requests');
    const friendUsers: User[] = friends.map(id => USERS[id]).filter(Boolean);

    const handleUserClick = (userId: string) => {
        onUserSelect(userId);
        onBack();
    };

    return (
        <div className="fixed inset-0 bg-slate-950 z-50 animate-fade-in flex flex-col">
             <header className="flex items-center p-4 border-b border-slate-800 flex-shrink-0">
                <button onClick={onBack} className="text-white p-2 rounded-full hover:bg-slate-800 transition-colors">
                    <BackIcon className="w-6 h-6"/>
                </button>
                <h2 className="text-xl font-bold text-white ml-4">Friends</h2>
            </header>

            <div className="flex border-b border-slate-800 flex-shrink-0">
                <button 
                    onClick={() => setActiveTab('requests')}
                    className={`flex-1 py-3 text-sm font-semibold flex items-center justify-center space-x-2 transition-colors ${activeTab === 'requests' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-gray-400 hover:text-white'}`}
                >
                    <span>Requests</span>
                    {requests.length > 0 && <span className="bg-orange-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">{requests.length}</span>}
                </button>
                 <button 
                    onClick={() => setActiveTab('friends')}
                    className={`flex-1 py-3 text-sm font-semibold transition-colors ${activeTab === 'friends' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-gray-400 hover:text-white'}`}
                >
                    All Friends
                </button>
            </div>

            <div className="flex-1 overflow-y-auto">
                {activeTab === 'requests' && (
                    <div className="p-2 space-y-2">
                        {requests.length > 0 ? requests.map(req => (
                             <div key={req.id} className="flex items-center p-3 bg-slate-900 rounded-lg">
                                <button onClick={() => handleUserClick(req.from.id)} className="flex items-center text-left group flex-1">
                                    <img src={req.from.avatarUrl} alt={req.from.name} className="w-12 h-12 rounded-full mr-3" />
                                    <div>
                                        <p className="font-bold text-white group-hover:underline">{req.from.name}</p>
                                        <p className="text-xs text-gray-500">{req.timestamp}</p>
                                    </div>
                                </button>
                                <div className="flex space-x-2">
                                    <button onClick={() => onDecline(req.from.id)} className="p-3 bg-slate-700 rounded-full hover:bg-slate-600 text-gray-300 transition-colors"><XIcon className="w-5 h-5"/></button>
                                    <button onClick={() => onAccept(req.from.id)} className="p-3 bg-green-600 rounded-full hover:bg-green-700 text-white transition-colors"><CheckIcon className="w-5 h-5"/></button>
                                </div>
                            </div>
                        )) : (
                            <div className="text-center py-16 text-gray-500">
                                <p>No pending friend requests.</p>
                            </div>
                        )}
                    </div>
                )}
                {activeTab === 'friends' && (
                     <div className="p-2 space-y-2">
                        {friendUsers.length > 0 ? friendUsers.map(friend => (
                            <button key={friend.id} onClick={() => handleUserClick(friend.id)} className="w-full flex items-center p-3 bg-slate-900 hover:bg-slate-800 rounded-lg text-left">
                                <img src={friend.avatarUrl} alt={friend.name} className="w-12 h-12 rounded-full mr-3" />
                                <p className="font-bold text-white">{friend.name}</p>
                            </button>
                        )) : (
                             <div className="text-center py-16 text-gray-500 flex flex-col items-center">
                                <UsersIcon className="w-12 h-12 mb-2"/>
                                <p>You haven't added any friends yet.</p>
                            </div>
                        )}
                    </div>
                )}
            </div>

        </div>
    );
};

export default FriendRequestsPanel;
