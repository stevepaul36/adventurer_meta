import React, { useState } from 'react';
import { CLUBS, USER_CLUBS } from '../constants';
import type { Club } from '../types';
import ClubDetails from './ClubDetails';
import { UsersIcon, PlusIcon } from './icons';

interface ClubPanelProps {
    onUserSelect: (userId: string) => void;
}

const ClubCard: React.FC<{ club: Club; onClick: () => void }> = ({ club, onClick }) => (
    <div 
        onClick={onClick}
        className="bg-slate-800/50 rounded-lg p-4 flex items-center space-x-4 cursor-pointer hover:bg-slate-700 transition-colors group"
    >
        <img src={club.badgeUrl} alt={`${club.name} badge`} className="w-16 h-16 rounded-lg" />
        <div className="flex-1">
            <h3 className="font-bold text-lg text-white group-hover:text-orange-400">{club.name}</h3>
            <p className="text-sm text-gray-400 flex items-center">
                <UsersIcon className="w-4 h-4 mr-1.5"/>
                {club.memberCount} members
            </p>
        </div>
        <svg className="w-5 h-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
    </div>
);


const ClubPanel: React.FC<ClubPanelProps> = ({ onUserSelect }) => {
    const [selectedClub, setSelectedClub] = useState<Club | null>(null);

    const myClubs = CLUBS.filter(club => USER_CLUBS.includes(club.id));
    const discoverClubs = CLUBS.filter(club => !USER_CLUBS.includes(club.id));

    if (selectedClub) {
        return <ClubDetails club={selectedClub} onBack={() => setSelectedClub(null)} onUserSelect={onUserSelect} />;
    }

    return (
        <div className="space-y-8 mb-20 md:mb-0 animate-fade-in">
            <div>
                <h2 className="text-3xl font-bold text-white mb-4">My Clubs</h2>
                <div className="space-y-4">
                    {myClubs.map(club => (
                        <ClubCard key={club.id} club={club} onClick={() => setSelectedClub(club)} />
                    ))}
                </div>
            </div>

            <div>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-3xl font-bold text-white">Discover Clubs</h2>
                    <button className="bg-orange-600 text-white font-semibold py-2 px-4 rounded-full flex items-center space-x-2 hover:bg-orange-700 transition-colors">
                        <PlusIcon className="w-5 h-5" />
                        <span>Create Club</span>
                    </button>
                </div>
                 <div className="space-y-4">
                    {discoverClubs.map(club => (
                        <ClubCard key={club.id} club={club} onClick={() => setSelectedClub(club)} />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ClubPanel;