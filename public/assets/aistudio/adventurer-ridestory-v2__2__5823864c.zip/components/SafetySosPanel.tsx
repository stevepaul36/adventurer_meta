import React from 'react';

const SafetySosPanel: React.FC = () => {
    const handleSosClick = () => {
        // In a real app, this would trigger a sequence of events:
        // 1. Confirm the user's intent to prevent accidental activation.
        // 2. Get the user's current GPS location.
        // 3. Send an alert to pre-defined emergency contacts with the location.
        alert('SOS ACTIVATED! Emergency contacts have been notified with your location.');
    };

  return (
    <div className="bg-red-900/50 rounded-lg p-4 shadow-lg border border-red-800 text-center">
      <h3 className="text-xl font-bold text-white mb-2">Safety SOS</h3>
      <p className="text-sm text-red-200 mb-4">In an emergency, press the button below to alert your contacts.</p>
      <button
        onClick={handleSosClick}
        className="w-full bg-red-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-red-700 transition-transform hover:scale-105 active:scale-100 shadow-lg"
      >
        ACTIVATE SOS
      </button>
    </div>
  );
};

export default SafetySosPanel;
