export type GameState = 'title' | 'playing' | 'paused' | 'gameover';

export type CameraView = 'chase' | 'cockpit' | 'cinema';

export interface GameStats {
    score: number;
    distance: number; // in meters
    speed: number; // km/h
    topSpeed: number;
    nearMisses: number;
    coinsCollected: number;
    nitroCount: number;
    timeElapsed: number; // in seconds
    multiplier: number;
}

export interface HighScoreRecord {
    score: number;
    distance: number;
    topSpeed: number;
    date: string;
}

export interface TrafficEntity {
    id: number;
    mesh: any; // THREE.Group
    x: number;
    z: number;
    targetX: number;
    speed: number;
    type: 'car' | 'suv' | 'truck' | 'sportbike';
    length: number;
    width: number;
    passed: boolean;
    nearMissTriggered: boolean;
}

export interface CollectibleEntity {
    id: number;
    mesh: any; // THREE.Group
    x: number;
    z: number;
    type: 'boost' | 'coin' | 'repair';
    collected: boolean;
}

export interface Particle {
    mesh: any;
    vx: number;
    vy: number;
    vz: number;
    life: number;
    maxLife: number;
    color: number;
}
