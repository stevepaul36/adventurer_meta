import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { soundService } from './soundService';
import {
    createHeroMotorcycle,
    createTrafficVehicle,
    createCollectibleMesh,
    createCanyonEnvironment,
} from './models';
import type { GameState, CameraView, GameStats, HighScoreRecord, TrafficEntity, CollectibleEntity, Particle } from './types';

interface ApexMotoGameProps {
    onExit: () => void;
    onShareToFeed?: (stats: { distanceKm: number; topSpeedKmH: number; score: number }) => void;
}

const HIGH_SCORE_KEY = 'adventurer_apex_high_score';

export const ApexMotoGame: React.FC<ApexMotoGameProps> = ({ onExit, onShareToFeed }) => {
    // --- React UI States ---
    const [gameState, setGameState] = useState<GameState>('title');
    const [cameraView, setCameraView] = useState<CameraView>('chase');
    const [isMuted, setIsMuted] = useState(soundService.getMuted());
    const [highScore, setHighScore] = useState<HighScoreRecord>(() => {
        try {
            const saved = localStorage.getItem(HIGH_SCORE_KEY);
            return saved ? JSON.parse(saved) : { score: 0, distance: 0, topSpeed: 0, date: '' };
        } catch {
            return { score: 0, distance: 0, topSpeed: 0, date: '' };
        }
    });

    // Reactive HUD metrics (updated at low frequency or via refs for 60fps purity)
    const [hudStats, setHudStats] = useState({
        speed: 0,
        score: 0,
        distance: 0,
        health: 100,
        nitro: 100,
        multiplier: 1,
        nearMissAlert: '',
    });

    const [isNewHighScore, setIsNewHighScore] = useState(false);

    // Canvas container ref
    const containerRef = useRef<HTMLDivElement>(null);

    // Mutable simulation refs (never re-renders React loop)
    const stateRef = useRef<{
        gameState: GameState;
        cameraView: CameraView;
        keys: {
            left: boolean;
            right: boolean;
            up: boolean;
            down: boolean;
            boost: boolean;
        };
        stats: GameStats;
        health: number;
        nitro: number;
        isBoosting: boolean;
        hitstopRemaining: number;
        cameraShake: number;
        flashColor: string | null;
        lastNearMissTime: number;
        nearMissCombo: number;
        // Motorcycle physics
        bikeX: number;
        bikeZ: number;
        bikeSpeed: number; // current speed m/s
        targetSpeed: number;
        bikeLean: number;
        steerAngle: number;
        traffic: TrafficEntity[];
        collectibles: CollectibleEntity[];
        particles: Particle[];
        nextSpawnZ: number;
        roadScrollZ: number;
        titleTime: number;
    }>({
        gameState: 'title',
        cameraView: 'chase',
        keys: { left: false, right: false, up: false, down: false, boost: false },
        stats: {
            score: 0,
            distance: 0,
            speed: 0,
            topSpeed: 0,
            nearMisses: 0,
            coinsCollected: 0,
            nitroCount: 0,
            timeElapsed: 0,
            multiplier: 1,
        },
        health: 100,
        nitro: 100,
        isBoosting: false,
        hitstopRemaining: 0,
        cameraShake: 0,
        flashColor: null,
        lastNearMissTime: 0,
        nearMissCombo: 0,
        bikeX: 0,
        bikeZ: 0,
        bikeSpeed: 0,
        targetSpeed: 0,
        bikeLean: 0,
        steerAngle: 0,
        traffic: [],
        collectibles: [],
        particles: [],
        nextSpawnZ: 60,
        roadScrollZ: 0,
        titleTime: 0,
    });

    // Update stateRef when gameState or cameraView changes
    useEffect(() => {
        stateRef.current.gameState = gameState;
        if (gameState === 'playing') {
            soundService.startEngine();
        } else if (gameState === 'paused' || gameState === 'gameover') {
            soundService.stopEngine();
        }
    }, [gameState]);

    useEffect(() => {
        stateRef.current.cameraView = cameraView;
    }, [cameraView]);

    const handleStartGame = useCallback(() => {
        soundService.playStartGameFanfare();
        const s = stateRef.current;
        s.stats = {
            score: 0,
            distance: 0,
            speed: 0,
            topSpeed: 0,
            nearMisses: 0,
            coinsCollected: 0,
            nitroCount: 0,
            timeElapsed: 0,
            multiplier: 1,
        };
        s.health = 100;
        s.nitro = 100;
        s.bikeX = 0;
        s.bikeZ = 0;
        s.bikeSpeed = 22; // Start rolling at ~80 km/h
        s.bikeLean = 0;
        s.steerAngle = 0;
        s.cameraShake = 0;
        s.hitstopRemaining = 0;
        s.nextSpawnZ = 40;
        s.roadScrollZ = 0;
        s.nearMissCombo = 0;
        setIsNewHighScore(false);
        setGameState('playing');
    }, []);

    const handleToggleMute = useCallback(() => {
        const muted = soundService.toggleMuted();
        setIsMuted(muted);
    }, []);

    // --- Keyboard & Window Blur Management ---
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            // Prevent scrolling on arrows/space during game
            if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
                e.preventDefault();
            }

            const s = stateRef.current;

            if (e.code === 'KeyM') {
                handleToggleMute();
                return;
            }

            if (e.code === 'KeyC') {
                setCameraView((prev) => (prev === 'chase' ? 'cockpit' : prev === 'cockpit' ? 'cinema' : 'chase'));
                return;
            }

            if (e.code === 'Escape') {
                if (s.gameState === 'playing') {
                    setGameState('paused');
                } else if (s.gameState === 'paused') {
                    setGameState('playing');
                }
                return;
            }

            if ((e.code === 'Enter' || e.code === 'Space') && s.gameState === 'title') {
                handleStartGame();
                return;
            }

            if (e.code === 'ArrowLeft' || e.code === 'KeyA') s.keys.left = true;
            if (e.code === 'ArrowRight' || e.code === 'KeyD') s.keys.right = true;
            if (e.code === 'ArrowUp' || e.code === 'KeyW') s.keys.up = true;
            if (e.code === 'ArrowDown' || e.code === 'KeyS') s.keys.down = true;
            if (e.code === 'Space') {
                s.keys.boost = true;
                if (s.nitro > 15 && !s.isBoosting && s.gameState === 'playing') {
                    s.isBoosting = true;
                    soundService.playNitroWhoosh();
                }
            }
        };

        const handleKeyUp = (e: KeyboardEvent) => {
            const s = stateRef.current;
            if (e.code === 'ArrowLeft' || e.code === 'KeyA') s.keys.left = false;
            if (e.code === 'ArrowRight' || e.code === 'KeyD') s.keys.right = false;
            if (e.code === 'ArrowUp' || e.code === 'KeyW') s.keys.up = false;
            if (e.code === 'ArrowDown' || e.code === 'KeyS') s.keys.down = false;
            if (e.code === 'Space') {
                s.keys.boost = false;
                s.isBoosting = false;
            }
        };

        const handleBlur = () => {
            const s = stateRef.current;
            s.keys.left = false;
            s.keys.right = false;
            s.keys.up = false;
            s.keys.down = false;
            s.keys.boost = false;
            s.isBoosting = false;
            if (s.gameState === 'playing') {
                setGameState('paused');
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        window.addEventListener('blur', handleBlur);

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
            window.removeEventListener('blur', handleBlur);
        };
    }, [handleStartGame, handleToggleMute]);

    // --- Primary Three.js Game Loop & Lifecycle ---
    useEffect(() => {
        const container = containerRef.current;
        if (!container) return;

        // Software WebGL Detection (Three.js skill directive)
        const isSoftwareGl = (() => {
            const gl = document.createElement('canvas').getContext('webgl2');
            if (!gl) return true;
            const ext = gl.getExtension('WEBGL_debug_renderer_info');
            const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
            const gpu = String(gl.getParameter(param));
            gl.getExtension('WEBGL_lose_context')?.loseContext();
            return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
        })();

        // 1. Scene, Camera, Renderer
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x13111c);
        scene.fog = new THREE.FogExp2(0x13111c, 0.0075);

        const camera = new THREE.PerspectiveCamera(65, container.clientWidth / container.clientHeight, 0.1, 800);
        camera.position.set(0, 3.2, -6.5);
        camera.lookAt(0, 1.2, 5);

        const renderer = new THREE.WebGLRenderer({
            antialias: !isSoftwareGl,
            powerPreference: 'high-performance',
        });
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.15;
        renderer.setSize(container.clientWidth, container.clientHeight);
        renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
        renderer.shadowMap.enabled = !isSoftwareGl;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;

        container.appendChild(renderer.domElement);

        // 2. Studio PBR Reflection Environment (RoomEnvironment)
        const pmremGenerator = new THREE.PMREMGenerator(renderer);
        scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
        pmremGenerator.dispose();

        // 3. Studio Lighting Rig
        // Warm Directional Sun Key Light
        const dirLight = new THREE.DirectionalLight(0xffedd5, 2.2);
        dirLight.position.set(18, 35, 25);
        dirLight.castShadow = !isSoftwareGl;
        if (dirLight.shadow) {
            dirLight.shadow.mapSize.width = 1024;
            dirLight.shadow.mapSize.height = 1024;
            dirLight.shadow.camera.near = 1;
            dirLight.shadow.camera.far = 120;
            dirLight.shadow.camera.left = -20;
            dirLight.shadow.camera.right = 20;
            dirLight.shadow.camera.top = 20;
            dirLight.shadow.camera.bottom = -20;
            dirLight.shadow.bias = -0.0005;
        }
        scene.add(dirLight);

        // Cool Horizon Hemisphere Light
        const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e1b4b, 1.2);
        hemiLight.position.set(0, 40, 0);
        scene.add(hemiLight);

        // 4. Highway Canyon Environment
        const env = createCanyonEnvironment(scene);

        // 5. Hero Motorcycle
        const heroBike = createHeroMotorcycle(0xea580c);
        scene.add(heroBike.group);

        // Hero Headlight Spotlight illuminating the road ahead
        const headlightBeam = new THREE.SpotLight(0xfffbeb, 4, 45, Math.PI / 6, 0.4, 1.2);
        headlightBeam.position.set(0, 0.9, 0.7);
        headlightBeam.target.position.set(0, 0.3, 20);
        heroBike.group.add(headlightBeam);
        heroBike.group.add(headlightBeam.target);

        // Scratch math helpers (zero GC in render loop)
        const _targetCamPos = new THREE.Vector3();
        const _targetCamLook = new THREE.Vector3();

        // Resize handler
        const handleResize = () => {
            if (!container) return;
            const w = container.clientWidth;
            const h = container.clientHeight;
            camera.aspect = w / h;
            camera.updateProjectionMatrix();
            renderer.setSize(w, h);
        };
        window.addEventListener('resize', handleResize);

        // Clean traffic & collectibles helpers
        const clearSpawns = () => {
            const s = stateRef.current;
            s.traffic.forEach((t) => scene.remove(t.mesh));
            s.collectibles.forEach((c) => scene.remove(c.mesh));
            s.traffic = [];
            s.collectibles = [];
        };

        // --- Spawn Traffic & Collectibles Ahead ---
        const spawnRow = (zPos: number) => {
            const s = stateRef.current;
            const lanes = [-5.2, -1.8, 1.8, 5.2];
            const lane = lanes[Math.floor(Math.random() * lanes.length)];

            // 70% chance traffic, 30% collectible
            if (Math.random() < 0.65) {
                const types: ('car' | 'suv' | 'truck' | 'sportbike')[] = ['car', 'suv', 'truck', 'sportbike'];
                const type = types[Math.floor(Math.random() * types.length)];
                const colors = [0x2563eb, 0xdc2626, 0x16a34a, 0x9333ea, 0x475569, 0xf59e0b];
                const color = colors[Math.floor(Math.random() * colors.length)];

                const mesh = createTrafficVehicle(type, color);
                mesh.position.set(lane, 0, zPos);
                scene.add(mesh);

                s.traffic.push({
                    id: Math.random(),
                    mesh,
                    x: lane,
                    z: zPos,
                    targetX: lane,
                    speed: 14 + Math.random() * 8, // Traffic travels at ~50-80 km/h
                    type,
                    length: type === 'truck' ? 6.5 : 3.8,
                    width: type === 'truck' ? 2.2 : 1.8,
                    passed: false,
                    nearMissTriggered: false,
                });
            } else {
                const cType = Math.random() < 0.25 ? 'boost' : Math.random() < 0.2 ? 'repair' : 'coin';
                const mesh = createCollectibleMesh(cType);
                mesh.position.set(lane, 0.8, zPos);
                scene.add(mesh);

                s.collectibles.push({
                    id: Math.random(),
                    mesh,
                    x: lane,
                    z: zPos,
                    type: cType,
                    collected: false,
                });
            }
        };

        // Particle pool for exhaust and sparks
        const particleGeo = new THREE.SphereGeometry(0.08, 6, 6);
        const spawnParticles = (pos: THREE.Vector3, count: number, color: number, speedMultiplier: number = 1) => {
            const s = stateRef.current;
            for (let i = 0; i < count; i++) {
                if (s.particles.length > 80) break; // cap particles
                const mat = new THREE.MeshBasicMaterial({ color });
                const mesh = new THREE.Mesh(particleGeo, mat);
                mesh.position.copy(pos);
                scene.add(mesh);

                s.particles.push({
                    mesh,
                    vx: (Math.random() - 0.5) * 4 * speedMultiplier,
                    vy: (Math.random() * 3 + 1) * speedMultiplier,
                    vz: (Math.random() * -6 - 2) * speedMultiplier,
                    life: 0,
                    maxLife: 0.35 + Math.random() * 0.3,
                    color,
                });
            }
        };

        let lastTime = performance.now();
        let animationFrameId = 0;
        let hudUpdateCounter = 0;

        // --- 60fps SIMULATION TICK ---
        const tick = () => {
            animationFrameId = requestAnimationFrame(tick);

            const now = performance.now();
            const rawDt = (now - lastTime) / 1000;
            lastTime = now;
            // Clamp dt to prevent physics explosions on background tab
            const dt = Math.min(rawDt, 0.05);

            const s = stateRef.current;

            // 1. Hitstop Handling (Simulation freeze on heavy collision)
            if (s.hitstopRemaining > 0) {
                s.hitstopRemaining -= dt;
                renderer.render(scene, camera);
                return;
            }

            // --- TITLE SCREEN LIVE-WORLD SHOWCASE ---
            if (s.gameState === 'title') {
                s.titleTime += dt;
                // Live camera orbit showcase around hero motorcycle
                const orbitRadius = 4.2;
                const camX = Math.sin(s.titleTime * 0.45) * orbitRadius;
                const camZ = Math.cos(s.titleTime * 0.45) * orbitRadius;
                camera.position.set(camX, 2.0 + Math.sin(s.titleTime * 0.3) * 0.5, camZ);
                camera.lookAt(0, 0.9, 0);

                // Idle motorcycle vibration
                heroBike.group.position.set(0, Math.sin(s.titleTime * 12) * 0.008, 0);
                heroBike.group.rotation.set(0, Math.sin(s.titleTime * 0.3) * 0.1, 0);

                // Spin wheels slightly
                heroBike.frontWheel.rotation.x += dt * 2;
                heroBike.rearWheel.rotation.x += dt * 2;

                renderer.render(scene, camera);
                return;
            }

            // --- PAUSED STATE ---
            if (s.gameState === 'paused') {
                renderer.render(scene, camera);
                return;
            }

            // --- PLAYING STATE ---
            if (s.gameState === 'playing') {
                s.stats.timeElapsed += dt;

                // 1. Controls & Acceleration Physics
                const maxSpeed = s.isBoosting ? 58 : 42; // ~150 to 210 km/h
                const accel = s.isBoosting ? 28 : 16;
                const brake = 22;

                if (s.keys.up) {
                    s.bikeSpeed = Math.min(maxSpeed, s.bikeSpeed + accel * dt);
                } else if (s.keys.down) {
                    s.bikeSpeed = Math.max(12, s.bikeSpeed - brake * dt);
                } else {
                    // Natural cruising speed
                    const cruising = 28;
                    if (s.bikeSpeed > cruising) s.bikeSpeed -= 6 * dt;
                    else s.bikeSpeed += 8 * dt;
                }

                // Nitro Consumption & Regeneration
                if (s.isBoosting) {
                    s.nitro = Math.max(0, s.nitro - 35 * dt);
                    if (s.nitro <= 0) s.isBoosting = false;
                } else {
                    s.nitro = Math.min(100, s.nitro + 8 * dt);
                }

                // Steering & Bank Leaning
                const steerSpeed = 10.5;
                if (s.keys.left) {
                    s.bikeX = Math.max(-6.8, s.bikeX - steerSpeed * dt);
                    s.bikeLean = THREE.MathUtils.damp(s.bikeLean, 0.42, 10, dt);
                    s.steerAngle = THREE.MathUtils.damp(s.steerAngle, -0.25, 12, dt);
                } else if (s.keys.right) {
                    s.bikeX = Math.min(6.8, s.bikeX + steerSpeed * dt);
                    s.bikeLean = THREE.MathUtils.damp(s.bikeLean, -0.42, 10, dt);
                    s.steerAngle = THREE.MathUtils.damp(s.steerAngle, 0.25, 12, dt);
                } else {
                    s.bikeLean = THREE.MathUtils.damp(s.bikeLean, 0, 12, dt);
                    s.steerAngle = THREE.MathUtils.damp(s.steerAngle, 0, 14, dt);
                }

                // Bike Model Pose & Ground Contact
                heroBike.group.position.x = s.bikeX;
                heroBike.group.position.y = 0;
                heroBike.group.rotation.z = s.bikeLean;
                heroBike.group.rotation.y = s.steerAngle * 0.4;
                heroBike.handlebars.rotation.y = s.steerAngle;
                heroBike.riderTorso.rotation.z = s.bikeLean * 0.7; // Rider shifts body into lean

                // Spin wheels with road speed
                const wheelAngVel = s.bikeSpeed / 0.45;
                heroBike.frontWheel.rotation.x += wheelAngVel * dt;
                heroBike.rearWheel.rotation.x += wheelAngVel * dt;

                // Brake light intensity
                if (s.keys.down) {
                    (heroBike.brakeLight.material as THREE.MeshBasicMaterial).color.setHex(0xff0000);
                } else {
                    (heroBike.brakeLight.material as THREE.MeshBasicMaterial).color.setHex(0x991b1b);
                }

                // Distance & Speed Metrics
                const distanceDelta = s.bikeSpeed * dt;
                s.stats.distance += distanceDelta;
                const speedKmh = Math.round(s.bikeSpeed * 3.6);
                s.stats.speed = speedKmh;
                if (speedKmh > s.stats.topSpeed) s.stats.topSpeed = speedKmh;

                // Continuous score gain based on speed and multiplier
                s.stats.score += Math.round(s.bikeSpeed * 0.8 * s.stats.multiplier * dt * 10);

                // Audio update
                soundService.updateEngineSpeed(s.bikeSpeed / 42, s.isBoosting);

                // Boost Exhaust Flame Particles
                if (s.isBoosting) {
                    const exhaustPos = heroBike.exhaustParticlesOrigin.clone().applyMatrix4(heroBike.group.matrixWorld);
                    spawnParticles(exhaustPos, 2, 0x06b6d4, 1.4);
                }

                // 2. Road Infinite Scroll Simulation
                s.roadScrollZ += s.bikeSpeed * dt;
                const roadTexture = (env.roadMesh.material as THREE.MeshStandardMaterial).map;
                if (roadTexture) {
                    roadTexture.offset.y = -(s.roadScrollZ * 0.04) % 1;
                }

                // 3. Traffic Logic & Encounters
                // Spawn new traffic as player travels
                s.nextSpawnZ -= s.bikeSpeed * dt;
                if (s.nextSpawnZ <= 0) {
                    spawnRow(120 + Math.random() * 40);
                    // Spawn frequency scales with player distance
                    s.nextSpawnZ = Math.max(16, 38 - Math.min(22, s.stats.distance * 0.005));
                }

                // Update Traffic Entities
                for (let i = s.traffic.length - 1; i >= 0; i--) {
                    const t = s.traffic[i];
                    // Traffic moves forward relative to player
                    const relativeSpeed = s.bikeSpeed - t.speed;
                    t.z -= relativeSpeed * dt;
                    t.mesh.position.z = t.z;

                    // AI Lane wandering (traffic occasionally switches lanes)
                    if (Math.random() < 0.005 && Math.abs(t.x - t.targetX) < 0.1) {
                        const lanes = [-5.2, -1.8, 1.8, 5.2];
                        t.targetX = lanes[Math.floor(Math.random() * lanes.length)];
                    }
                    t.x = THREE.MathUtils.damp(t.x, t.targetX, 2, dt);
                    t.mesh.position.x = t.x;

                    // Collision Detection (AABB)
                    const bikeHitRadius = 0.5;
                    const dx = Math.abs(s.bikeX - t.x);
                    const dz = Math.abs(0 - t.z); // Player is at z=0

                    if (dx < bikeHitRadius + t.width * 0.45 && dz < 1.2 + t.length * 0.45) {
                        // CRASH! Heavy collision
                        soundService.playCrashSound();
                        s.health -= 38;
                        s.bikeSpeed = Math.max(10, s.bikeSpeed * 0.35);
                        s.cameraShake = 0.8;
                        s.hitstopRemaining = 0.06; // 60ms hitstop
                        s.flashColor = 'rgba(239, 68, 68, 0.45)';

                        // Sparks burst
                        const contactPt = new THREE.Vector3(s.bikeX, 0.8, 0);
                        spawnParticles(contactPt, 18, 0xf59e0b, 2.2);

                        // Push traffic away
                        t.z += 15;

                        if (s.health <= 0) {
                            // GAME OVER!
                            s.health = 0;
                            setGameState('gameover');
                            // Check High Score
                            if (s.stats.score > highScore.score) {
                                const newRecord: HighScoreRecord = {
                                    score: s.stats.score,
                                    distance: Math.round(s.stats.distance),
                                    topSpeed: s.stats.topSpeed,
                                    date: new Date().toLocaleDateString(),
                                };
                                setHighScore(newRecord);
                                setIsNewHighScore(true);
                                try {
                                    localStorage.setItem(HIGH_SCORE_KEY, JSON.stringify(newRecord));
                                } catch {
                                    // ignore
                                }
                            }
                            return;
                        }
                    }

                    // Near-Miss Encounter Detection
                    // Passes close by (dx between 1.0 and 2.4, and dz crossing zero)
                    if (!t.passed && t.z < 0) {
                        t.passed = true;
                        if (!t.nearMissTriggered && dx > 0.7 && dx < 2.6) {
                            t.nearMissTriggered = true;
                            s.stats.nearMisses += 1;
                            s.nearMissCombo += 1;
                            s.stats.multiplier = Math.min(5, 1 + Math.floor(s.nearMissCombo / 2));
                            s.stats.score += 250 * s.stats.multiplier;
                            s.nitro = Math.min(100, s.nitro + 25); // Near-miss rewards nitro!
                            s.lastNearMissTime = s.stats.timeElapsed;
                            soundService.playNearMissChime();

                            // Show HUD toast
                            setHudStats((prev) => ({
                                ...prev,
                                nearMissAlert: `NEAR MISS! +${250 * s.stats.multiplier}`,
                            }));
                            setTimeout(() => {
                                setHudStats((prev) => ({ ...prev, nearMissAlert: '' }));
                            }, 1200);
                        }
                    }

                    // Remove traffic far behind player
                    if (t.z < -25) {
                        scene.remove(t.mesh);
                        s.traffic.splice(i, 1);
                    }
                }

                // Near Miss combo reset if inactive for 4 seconds
                if (s.stats.timeElapsed - s.lastNearMissTime > 4.5 && s.nearMissCombo > 0) {
                    s.nearMissCombo = 0;
                    s.stats.multiplier = 1;
                }

                // 4. Update Collectibles
                for (let i = s.collectibles.length - 1; i >= 0; i--) {
                    const c = s.collectibles[i];
                    c.z -= s.bikeSpeed * dt;
                    c.mesh.position.z = c.z;
                    c.mesh.rotation.y += dt * 3.5;

                    // Collect collision
                    const dx = Math.abs(s.bikeX - c.x);
                    const dz = Math.abs(0 - c.z);
                    if (dx < 1.1 && dz < 1.2 && !c.collected) {
                        c.collected = true;
                        if (c.type === 'coin') {
                            s.stats.coinsCollected += 1;
                            s.stats.score += 500 * s.stats.multiplier;
                            soundService.playCoinChime();
                            spawnParticles(c.mesh.position, 10, 0xf59e0b, 1.2);
                        } else if (c.type === 'boost') {
                            s.nitro = 100;
                            s.stats.nitroCount += 1;
                            s.stats.score += 300;
                            soundService.playNitroWhoosh();
                            spawnParticles(c.mesh.position, 12, 0x06b6d4, 1.5);
                        } else if (c.type === 'repair') {
                            s.health = Math.min(100, s.health + 40);
                            soundService.playCoinChime();
                            spawnParticles(c.mesh.position, 10, 0x10b981, 1.2);
                        }
                        scene.remove(c.mesh);
                        s.collectibles.splice(i, 1);
                        continue;
                    }

                    if (c.z < -20) {
                        scene.remove(c.mesh);
                        s.collectibles.splice(i, 1);
                    }
                }

                // 5. Update Particles
                for (let i = s.particles.length - 1; i >= 0; i--) {
                    const p = s.particles[i];
                    p.life += dt;
                    if (p.life >= p.maxLife) {
                        scene.remove(p.mesh);
                        s.particles.splice(i, 1);
                    } else {
                        p.mesh.position.x += p.vx * dt;
                        p.mesh.position.y += p.vy * dt;
                        p.mesh.position.z += (p.vz - s.bikeSpeed) * dt;
                        const scale = 1 - p.life / p.maxLife;
                        p.mesh.scale.set(scale, scale, scale);
                    }
                }

                // 6. Camera Damped Follow & View Modes
                if (s.cameraShake > 0) {
                    s.cameraShake = Math.max(0, s.cameraShake - dt * 2.5);
                }
                const shakeOffsetX = (Math.random() - 0.5) * s.cameraShake * 0.4;
                const shakeOffsetY = (Math.random() - 0.5) * s.cameraShake * 0.4;

                if (s.cameraView === 'chase') {
                    // Third-person chase cam
                    const targetCamX = s.bikeX * 0.75 + shakeOffsetX;
                    const targetCamY = 2.8 + (s.isBoosting ? -0.2 : 0) + shakeOffsetY;
                    const targetCamZ = -5.8 + (s.isBoosting ? -1.0 : 0);

                    camera.position.x = THREE.MathUtils.damp(camera.position.x, targetCamX, 8, dt);
                    camera.position.y = THREE.MathUtils.damp(camera.position.y, targetCamY, 8, dt);
                    camera.position.z = THREE.MathUtils.damp(camera.position.z, targetCamZ, 8, dt);

                    _targetCamLook.set(s.bikeX * 0.5, 1.2, 18);
                    camera.lookAt(_targetCamLook);

                    // Dynamic FOV widening on high speed
                    const targetFov = 65 + (s.bikeSpeed / 42) * 12 + (s.isBoosting ? 8 : 0);
                    camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 6, dt);
                    camera.updateProjectionMatrix();
                } else if (s.cameraView === 'cockpit') {
                    // First-person handlebar cockpit cam
                    camera.position.set(s.bikeX + shakeOffsetX, 1.15 + shakeOffsetY, 0.4);
                    _targetCamLook.set(s.bikeX, 1.1, 25);
                    camera.lookAt(_targetCamLook);
                    camera.fov = 80;
                    camera.updateProjectionMatrix();
                } else {
                    // Dynamic Cinema Cam
                    const camX = Math.sin(s.stats.timeElapsed * 0.8) * 4.5 + s.bikeX * 0.3;
                    camera.position.set(camX, 2.2, -4.5);
                    camera.lookAt(s.bikeX, 1.0, 10);
                }

                // Update HUD at throttled cadence (~15fps for zero overhead)
                hudUpdateCounter++;
                if (hudUpdateCounter % 4 === 0) {
                    setHudStats({
                        speed: speedKmh,
                        score: s.stats.score,
                        distance: Math.round(s.stats.distance),
                        health: Math.round(s.health),
                        nitro: Math.round(s.nitro),
                        multiplier: s.stats.multiplier,
                        nearMissAlert: s.stats.timeElapsed - s.lastNearMissTime < 1.2 ? `NEAR MISS! x${s.stats.multiplier}` : '',
                    });
                }
            }

            renderer.render(scene, camera);
        };

        animationFrameId = requestAnimationFrame(tick);

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', handleResize);
            clearSpawns();
            soundService.stopEngine();
            renderer.dispose();
            if (container && renderer.domElement) {
                container.removeChild(renderer.domElement);
            }
        };
    }, []);

    // --- On-Screen Touch Controls (Mobile Friendly) ---
    const handleTouchLeftStart = () => { stateRef.current.keys.left = true; };
    const handleTouchLeftEnd = () => { stateRef.current.keys.left = false; };
    const handleTouchRightStart = () => { stateRef.current.keys.right = true; };
    const handleTouchRightEnd = () => { stateRef.current.keys.right = false; };
    const handleTouchBoostStart = () => {
        stateRef.current.keys.boost = true;
        if (stateRef.current.nitro > 15) {
            stateRef.current.isBoosting = true;
            soundService.playNitroWhoosh();
        }
    };
    const handleTouchBoostEnd = () => {
        stateRef.current.keys.boost = false;
        stateRef.current.isBoosting = false;
    };
    const handleTouchBrakeStart = () => { stateRef.current.keys.down = true; };
    const handleTouchBrakeEnd = () => { stateRef.current.keys.down = false; };

    return (
        <div className="fixed inset-0 z-50 bg-slate-950 overflow-hidden select-none font-sans text-white">
            {/* 3D WebGL Canvas Container - Isolated Ref */}
            <div ref={containerRef} className="absolute inset-0 w-full h-full" />

            {/* Red Impact Flash Vignette Overlay */}
            {stateRef.current.flashColor && (
                <div
                    className="absolute inset-0 pointer-events-none transition-opacity duration-150"
                    style={{
                        backgroundColor: stateRef.current.flashColor,
                        opacity: stateRef.current.hitstopRemaining > 0 ? 0.6 : 0,
                    }}
                />
            )}

            {/* =========================================================================
                TITLE SCREEN OVERLAY (Meets Game Shell & Title Screen Craft Directives)
                ========================================================================= */}
            {gameState === 'title' && (
                <div className="absolute inset-0 flex flex-col justify-between p-6 md:p-12 pointer-events-none">
                    {/* Top Bar: Brand & High Score Badge */}
                    <div className="flex items-center justify-between w-full pointer-events-auto">
                        <div className="flex items-center space-x-3">
                            <span className="text-xs uppercase tracking-widest text-orange-400 font-semibold border-b border-orange-500/40 pb-0.5">
                                Adventurer 3D Arcade
                            </span>
                        </div>
                        <div className="flex items-center space-x-3">
                            {highScore.score > 0 && (
                                <div className="text-right">
                                    <span className="text-xs text-gray-400 uppercase tracking-wider block">All-Time Best</span>
                                    <span className="text-sm font-mono font-bold text-amber-400 tabular-nums">
                                        {highScore.score.toLocaleString()} PTS · {(highScore.distance / 1000).toFixed(1)} km
                                    </span>
                                </div>
                            )}
                            <button
                                onClick={handleToggleMute}
                                className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-700 hover:border-orange-500 text-gray-300 transition-colors"
                                aria-label="Toggle Sound"
                            >
                                {isMuted ? '🔇' : '🔊'}
                            </button>
                            <button
                                onClick={onExit}
                                className="px-4 py-2 rounded-lg bg-slate-900/80 border border-slate-700 hover:border-slate-500 text-sm font-medium transition-colors"
                            >
                                Exit
                            </button>
                        </div>
                    </div>

                    {/* Bespoke Inline SVG Title Lockup over 35% Negative Space */}
                    <div className="my-auto max-w-2xl pointer-events-auto">
                        <div className="mb-4">
                            <svg className="w-full max-w-xl h-24" viewBox="0 0 620 90" fill="none">
                                <defs>
                                    <linearGradient id="titleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stopColor="#ffffff" />
                                        <stop offset="60%" stopColor="#f97316" />
                                        <stop offset="100%" stopColor="#ea580c" />
                                    </linearGradient>
                                    <linearGradient id="subGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                                        <stop offset="0%" stopColor="#ea580c" />
                                        <stop offset="100%" stopColor="#f59e0b" />
                                    </linearGradient>
                                </defs>
                                <text x="0" y="52" fontFamily="sans-serif" fontWeight="900" fontSize="54" fill="url(#titleGrad)" letterSpacing="-1">
                                    APEX MOTO
                                </text>
                                <text x="330" y="52" fontFamily="sans-serif" fontWeight="800" fontSize="24" fill="url(#subGrad)" letterSpacing="4">
                                    CANYON RUN
                                </text>
                                <rect x="0" y="68" width="580" height="3" fill="url(#subGrad)" opacity="0.8" />
                            </svg>
                        </div>

                        <p className="text-gray-300 text-sm md:text-base leading-relaxed max-w-lg mb-8">
                            High-speed 3D motorcycle highway run. Weave through dynamic traffic, trigger close-call near-miss multipliers, collect nitro canisters, and conquer the canyon leaderboard.
                        </p>

                        {/* Primary Start CTA */}
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                            <button
                                onClick={handleStartGame}
                                className="px-8 py-4 rounded-xl bg-orange-600 hover:bg-orange-500 active:scale-95 text-white font-bold text-lg shadow-xl shadow-orange-950/60 transition-all flex items-center justify-center space-x-3"
                            >
                                <span>Throttle Up & Ride</span>
                                <span className="text-xs bg-orange-700/80 px-2 py-0.5 rounded font-mono">ENTER / SPACE</span>
                            </button>
                        </div>

                        {/* Single Flat Control-Hint Line */}
                        <div className="mt-8 text-xs text-gray-400 font-mono flex flex-wrap items-center gap-x-3 gap-y-1">
                            <span>A/D or ←/→ Steer</span>
                            <span>·</span>
                            <span>W/↑ Accelerate</span>
                            <span>·</span>
                            <span>Space Nitro Boost</span>
                            <span>·</span>
                            <span>C Camera</span>
                            <span>·</span>
                            <span>Esc Pause</span>
                        </div>
                    </div>

                    {/* Bottom Feature Badges */}
                    <div className="flex items-center justify-between text-xs text-gray-500 border-t border-slate-800/80 pt-4">
                        <span>PBR Studio Lighting · 60fps WebGL Simulation · Web Audio Synth</span>
                        <span>Motorcycle Adventure Community</span>
                    </div>
                </div>
            )}

            {/* =========================================================================
                PLAYING HUD (World-Matched, Low-Occlusion: >= 85% Unobstructed Playfield)
                ========================================================================= */}
            {gameState === 'playing' && (
                <div className="absolute inset-0 pointer-events-none p-4 md:p-6 flex flex-col justify-between">
                    {/* Top Row: Speedometer + Status Clusters */}
                    <div className="flex items-start justify-between w-full">
                        {/* Speedometer Cluster (Top-Left) */}
                        <div className="bg-slate-950/85 border border-slate-800 rounded-xl p-3.5 flex items-baseline space-x-2">
                            <span className="text-3xl md:text-4xl font-mono font-black text-white tabular-nums tracking-tight">
                                {hudStats.speed}
                            </span>
                            <span className="text-xs uppercase font-bold text-orange-400">KM/H</span>
                            <div className="hidden sm:flex items-center space-x-1 ml-3 border-l border-slate-800 pl-3">
                                <span className="text-xs text-gray-400">GEAR</span>
                                <span className="text-sm font-bold text-white font-mono">
                                    {hudStats.speed > 160 ? '6' : hudStats.speed > 120 ? '5' : hudStats.speed > 80 ? '4' : hudStats.speed > 50 ? '3' : hudStats.speed > 25 ? '2' : '1'}
                                </span>
                            </div>
                        </div>

                        {/* Near Miss Combo Banner (Top-Center) */}
                        <div className="text-center">
                            {hudStats.nearMissAlert && (
                                <div className="bg-amber-500 text-slate-950 font-black px-4 py-1.5 rounded-lg text-sm md:text-base animate-bounce shadow-lg shadow-amber-500/30">
                                    {hudStats.nearMissAlert}
                                </div>
                            )}
                        </div>

                        {/* Metrics Cluster: Distance, Multiplier, Score (Top-Right) */}
                        <div className="flex items-center space-x-3">
                            <div className="bg-slate-950/85 border border-slate-800 rounded-xl p-3 text-right">
                                <div className="text-xs text-gray-400 font-mono">
                                    {(hudStats.distance / 1000).toFixed(2)} <span className="text-[10px]">KM</span>
                                </div>
                                <div className="text-lg md:text-xl font-mono font-bold text-orange-400 tabular-nums">
                                    {hudStats.score.toLocaleString()}
                                </div>
                            </div>

                            {hudStats.multiplier > 1 && (
                                <div className="bg-orange-600 text-white font-black px-2.5 py-1 rounded-lg text-sm font-mono shadow-md">
                                    x{hudStats.multiplier}
                                </div>
                            )}

                            <button
                                onClick={() => setGameState('paused')}
                                className="pointer-events-auto p-2.5 rounded-xl bg-slate-950/85 border border-slate-800 hover:border-orange-500 text-gray-300 transition-colors"
                                aria-label="Pause"
                            >
                                ⏸
                            </button>
                        </div>
                    </div>

                    {/* Bottom Perimeter: Nitro & Health Bar + Minimal Control Dock */}
                    <div className="flex flex-col space-y-4">
                        {/* Gauges */}
                        <div className="flex items-center justify-between w-full max-w-md mx-auto">
                            {/* Health */}
                            <div className="w-44 bg-slate-950/90 border border-slate-800 rounded-lg p-2">
                                <div className="flex justify-between text-[11px] font-mono text-gray-400 mb-1">
                                    <span>ARMOR</span>
                                    <span className="tabular-nums font-bold text-white">{hudStats.health}%</span>
                                </div>
                                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                    <div
                                        className={`h-full transition-all duration-150 ${
                                            hudStats.health > 40 ? 'bg-emerald-500' : 'bg-red-500'
                                        }`}
                                        style={{ width: `${hudStats.health}%` }}
                                    />
                                </div>
                            </div>

                            {/* Nitro Gauge */}
                            <div className="w-44 bg-slate-950/90 border border-slate-800 rounded-lg p-2">
                                <div className="flex justify-between text-[11px] font-mono text-gray-400 mb-1">
                                    <span>NITRO BOOST</span>
                                    <span className="tabular-nums font-bold text-cyan-400">{hudStats.nitro}%</span>
                                </div>
                                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                    <div
                                        className="h-full bg-cyan-500 transition-all duration-100"
                                        style={{ width: `${hudStats.nitro}%` }}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Collapsible / Compact Bottom Dock (<= 15% Viewport footprint) */}
                        <div className="flex items-center justify-center space-x-3 pointer-events-auto">
                            <button
                                onClick={() =>
                                    setCameraView((prev) => (prev === 'chase' ? 'cockpit' : prev === 'cockpit' ? 'cinema' : 'chase'))
                                }
                                className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-slate-600 text-xs text-gray-300 font-mono transition-colors"
                            >
                                Cam: {cameraView.toUpperCase()} [C]
                            </button>
                            <button
                                onClick={handleToggleMute}
                                className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-slate-600 text-xs text-gray-300 font-mono transition-colors"
                            >
                                Sound: {isMuted ? 'OFF [M]' : 'ON [M]'}
                            </button>
                        </div>

                        {/* Mobile Touch Controls Overlay (visible on touch devices) */}
                        <div className="flex md:hidden items-center justify-between w-full pointer-events-auto pt-2">
                            <div className="flex space-x-2">
                                <button
                                    onTouchStart={handleTouchLeftStart}
                                    onTouchEnd={handleTouchLeftEnd}
                                    className="w-16 h-16 rounded-2xl bg-slate-900/80 active:bg-orange-600/80 border border-slate-700 flex items-center justify-center text-2xl font-bold"
                                >
                                    ←
                                </button>
                                <button
                                    onTouchStart={handleTouchRightStart}
                                    onTouchEnd={handleTouchRightEnd}
                                    className="w-16 h-16 rounded-2xl bg-slate-900/80 active:bg-orange-600/80 border border-slate-700 flex items-center justify-center text-2xl font-bold"
                                >
                                    →
                                </button>
                            </div>
                            <div className="flex space-x-2">
                                <button
                                    onTouchStart={handleTouchBrakeStart}
                                    onTouchEnd={handleTouchBrakeEnd}
                                    className="w-16 h-16 rounded-2xl bg-slate-900/80 active:bg-red-600/80 border border-slate-700 flex items-center justify-center text-xs font-bold text-red-400"
                                >
                                    BRAKE
                                </button>
                                <button
                                    onTouchStart={handleTouchBoostStart}
                                    onTouchEnd={handleTouchBoostEnd}
                                    className="w-16 h-16 rounded-2xl bg-cyan-700/80 active:bg-cyan-500 border border-cyan-500 flex items-center justify-center text-xs font-bold text-white shadow-lg"
                                >
                                    NITRO
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* =========================================================================
                PAUSE MODAL
                ========================================================================= */}
            {gameState === 'paused' && (
                <div className="absolute inset-0 bg-slate-950/80 flex items-center justify-center p-4">
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-sm w-full text-center space-y-6">
                        <h2 className="text-2xl font-bold tracking-tight">Run Paused</h2>
                        <div className="space-y-2 text-sm text-gray-400">
                            <div>Score: <span className="font-mono text-white font-bold">{hudStats.score.toLocaleString()}</span></div>
                            <div>Distance: <span className="font-mono text-white font-bold">{(hudStats.distance / 1000).toFixed(2)} km</span></div>
                            <div>Speed: <span className="font-mono text-white font-bold">{hudStats.speed} km/h</span></div>
                        </div>

                        <div className="space-y-3 pt-2">
                            <button
                                onClick={() => setGameState('playing')}
                                className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-sm transition-all"
                            >
                                Resume Ride [ESC]
                            </button>
                            <button
                                onClick={handleStartGame}
                                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-gray-200 text-sm font-medium transition-all"
                            >
                                Restart Run
                            </button>
                            <button
                                onClick={() => setGameState('title')}
                                className="w-full py-2.5 rounded-xl bg-transparent hover:bg-slate-800 text-gray-400 hover:text-white text-sm font-medium transition-all"
                            >
                                Exit to Title
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* =========================================================================
                GAME OVER MODAL (Run Summary & Social Feed Integration)
                ========================================================================= */}
            {gameState === 'gameover' && (
                <div className="absolute inset-0 bg-slate-950/85 flex items-center justify-center p-4">
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 max-w-md w-full text-center space-y-6">
                        <div>
                            {isNewHighScore ? (
                                <div className="inline-block bg-amber-500/20 border border-amber-500/50 text-amber-400 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
                                    ★ New Personal Best! ★
                                </div>
                            ) : (
                                <span className="text-xs uppercase tracking-widest text-red-500 font-bold block mb-1">
                                    Run Complete
                                </span>
                            )}
                            <h2 className="text-3xl font-black text-white tracking-tight">Canyon Run Finished</h2>
                        </div>

                        {/* Run Stats Grid */}
                        <div className="grid grid-cols-2 gap-3 text-left">
                            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                                <span className="text-xs text-gray-400 block">Final Score</span>
                                <span className="text-xl font-mono font-bold text-orange-400 tabular-nums">
                                    {hudStats.score.toLocaleString()}
                                </span>
                            </div>
                            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                                <span className="text-xs text-gray-400 block">Distance Covered</span>
                                <span className="text-xl font-mono font-bold text-white tabular-nums">
                                    {(hudStats.distance / 1000).toFixed(2)} km
                                </span>
                            </div>
                            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                                <span className="text-xs text-gray-400 block">Top Speed</span>
                                <span className="text-xl font-mono font-bold text-white tabular-nums">
                                    {stateRef.current.stats.topSpeed} km/h
                                </span>
                            </div>
                            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                                <span className="text-xs text-gray-400 block">Near Misses</span>
                                <span className="text-xl font-mono font-bold text-amber-400 tabular-nums">
                                    {stateRef.current.stats.nearMisses}
                                </span>
                            </div>
                        </div>

                        {/* Action CTAs */}
                        <div className="space-y-2.5 pt-2">
                            {onShareToFeed && (
                                <button
                                    onClick={() => {
                                        onShareToFeed({
                                            distanceKm: Number((hudStats.distance / 1000).toFixed(2)),
                                            topSpeedKmH: stateRef.current.stats.topSpeed,
                                            score: hudStats.score,
                                        });
                                        onExit();
                                    }}
                                    className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-sm shadow-lg shadow-orange-950/50 transition-all flex items-center justify-center space-x-2"
                                >
                                    <span>Share Ride to Feed</span>
                                    <span>🏍️</span>
                                </button>
                            )}

                            <button
                                onClick={handleStartGame}
                                className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm transition-all"
                            >
                                Ride Again
                            </button>

                            <button
                                onClick={onExit}
                                className="w-full py-2.5 rounded-xl bg-transparent hover:bg-slate-800 text-gray-400 hover:text-white text-sm font-medium transition-all"
                            >
                                Return to Adventurer
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ApexMotoGame;
