import * as THREE from 'three';

/**
 * Creates procedural CanvasTexture for the highway asphalt.
 * Features asphalt grit, dashed yellow center line, and solid white shoulder edges.
 */
export function createHighwayTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // 1. Dark asphalt base
    ctx.fillStyle = '#1c1e24';
    ctx.fillRect(0, 0, 512, 1024);

    // 2. Procedural asphalt noise grain
    const imgData = ctx.getImageData(0, 0, 512, 1024);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
        const noise = (Math.random() - 0.5) * 22;
        data[i] = Math.max(0, Math.min(255, data[i] + noise));
        data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + noise));
        data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + noise + 2));
    }
    ctx.putImageData(imgData, 0, 0);

    // 3. Subtle road wear & tire tracks
    ctx.fillStyle = 'rgba(12, 14, 18, 0.45)';
    ctx.fillRect(90, 0, 80, 1024);
    ctx.fillRect(342, 0, 80, 1024);

    // 4. Solid white shoulder markings
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(20, 0, 10, 1024);
    ctx.fillRect(482, 0, 10, 1024);

    // 5. White lane division dashes (left lane & right lane)
    ctx.fillStyle = '#cbd5e1';
    for (let y = 0; y < 1024; y += 128) {
        ctx.fillRect(170, y + 20, 6, 68);
        ctx.fillRect(336, y + 20, 6, 68);
    }

    // 6. Double yellow center stripe
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(251, 0, 4, 1024);
    ctx.fillRect(257, 0, 4, 1024);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 16);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
}

/**
 * Creates a soft radial contact shadow disc
 */
export function createContactShadow(radiusX: number, radiusZ: number): THREE.Mesh {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createRadialGradient(64, 64, 10, 64, 64, 62);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
    grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.35)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);

    const texture = new THREE.CanvasTexture(canvas);
    const geo = new THREE.PlaneGeometry(radiusX * 2, radiusZ * 2);
    const mat = new THREE.MeshBasicMaterial({
        map: texture,
        transparent: true,
        depthWrite: false,
        opacity: 0.65,
    });

    const mesh = new THREE.Mesh(geo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.y = 0.03; // offset above ground to avoid z-fighting
    return mesh;
}

/**
 * Builds the Hero Motorcycle as a composite 11-part THREE.Group.
 * Adheres strictly to the Three.js skill: composite models, distinct PBR roughness/metalness,
 * grounded pivot, and detailed sub-elements.
 */
export function createHeroMotorcycle(primaryColor: number = 0xea580c): {
    group: THREE.Group;
    frontWheel: THREE.Group;
    rearWheel: THREE.Group;
    handlebars: THREE.Group;
    riderTorso: THREE.Group;
    brakeLight: THREE.Mesh;
    exhaustParticlesOrigin: THREE.Vector3;
} {
    const bike = new THREE.Group();

    // --- PBR Materials with strict roughness / metalness variation ---
    const carbonFrameMat = new THREE.MeshStandardMaterial({
        color: 0x18181b,
        metalness: 0.5,
        roughness: 0.5,
    });

    const bodyPaintMat = new THREE.MeshStandardMaterial({
        color: primaryColor,
        metalness: 0.3,
        roughness: 0.18,
    });

    const chromeMat = new THREE.MeshStandardMaterial({
        color: 0xf1f5f9,
        metalness: 0.95,
        roughness: 0.08,
    });

    const engineBlockMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        metalness: 0.8,
        roughness: 0.35,
    });

    const tireRubberMat = new THREE.MeshStandardMaterial({
        color: 0x0f1115,
        metalness: 0.05,
        roughness: 0.85,
    });

    const brakeRotorMat = new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.9,
        roughness: 0.2,
    });

    const windshieldMat = new THREE.MeshPhysicalMaterial({
        color: 0x0f172a,
        transmission: 0.75,
        transparent: true,
        opacity: 0.85,
        roughness: 0.1,
        ior: 1.5,
    });

    const headlightMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
    });

    const brakeLightMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
    });

    const riderSuitMat = new THREE.MeshStandardMaterial({
        color: 0x09090b,
        metalness: 0.2,
        roughness: 0.7,
    });

    const helmetVisorMat = new THREE.MeshStandardMaterial({
        color: 0xd97706,
        metalness: 0.9,
        roughness: 0.12,
    });

    // 1. Main Tubular Frame / Spine
    const frameGeo = new THREE.CylinderGeometry(0.08, 0.09, 1.6, 8);
    const frame = new THREE.Mesh(frameGeo, carbonFrameMat);
    frame.rotation.z = Math.PI / 2.3;
    frame.position.set(0, 0.75, 0.05);
    bike.add(frame);

    // 2. Sculpted Fuel Tank & Front Cowl Fairing
    const tankGeo = new THREE.BoxGeometry(0.55, 0.42, 0.9);
    const tank = new THREE.Mesh(tankGeo, bodyPaintMat);
    tank.position.set(0, 0.95, -0.15);
    bike.add(tank);

    // Front Fairing nose wedge
    const noseGeo = new THREE.ConeGeometry(0.32, 0.6, 6);
    const nose = new THREE.Mesh(noseGeo, bodyPaintMat);
    nose.rotation.x = -Math.PI / 2.2;
    nose.position.set(0, 0.92, 0.45);
    bike.add(nose);

    // Windshield
    const shieldGeo = new THREE.PlaneGeometry(0.38, 0.35);
    const shield = new THREE.Mesh(shieldGeo, windshieldMat);
    shield.rotation.x = -Math.PI / 3;
    shield.position.set(0, 1.15, 0.35);
    bike.add(shield);

    // LED Headlight projector
    const lightGeo = new THREE.SphereGeometry(0.12, 12, 8);
    const headlight = new THREE.Mesh(lightGeo, headlightMat);
    headlight.position.set(0, 0.88, 0.68);
    bike.add(headlight);

    // 3. Engine Block (V-Twin with cylinder fins)
    const engineGroup = new THREE.Group();
    const coreGeo = new THREE.BoxGeometry(0.48, 0.4, 0.55);
    const core = new THREE.Mesh(coreGeo, engineBlockMat);
    engineGroup.add(core);

    const cylGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.38, 12);
    const cyl1 = new THREE.Mesh(cylGeo, chromeMat);
    cyl1.rotation.z = Math.PI / 6;
    cyl1.position.set(0.12, 0.2, -0.05);
    engineGroup.add(cyl1);

    const cyl2 = new THREE.Mesh(cylGeo, chromeMat);
    cyl2.rotation.z = -Math.PI / 6;
    cyl2.position.set(-0.12, 0.2, 0.1);
    engineGroup.add(cyl2);

    engineGroup.position.set(0, 0.52, -0.05);
    bike.add(engineGroup);

    // 4. Exhaust System (Dual pipes with heat-tinted tips)
    const exhaustMat = new THREE.MeshStandardMaterial({
        color: 0x475569,
        metalness: 0.92,
        roughness: 0.18,
    });
    const pipeGeo = new THREE.CylinderGeometry(0.06, 0.08, 1.1, 12);
    const pipe = new THREE.Mesh(pipeGeo, exhaustMat);
    pipe.rotation.x = Math.PI / 2.1;
    pipe.position.set(0.26, 0.45, -0.65);
    bike.add(pipe);

    // 5. Rear Tail Section & Brake Light
    const tailGeo = new THREE.BoxGeometry(0.35, 0.22, 0.6);
    const tail = new THREE.Mesh(tailGeo, bodyPaintMat);
    tail.position.set(0, 0.88, -0.75);
    bike.add(tail);

    const brakeLightGeo = new THREE.BoxGeometry(0.25, 0.08, 0.06);
    const brakeLight = new THREE.Mesh(brakeLightGeo, brakeLightMat);
    brakeLight.position.set(0, 0.9, -1.06);
    bike.add(brakeLight);

    // 6. Wheels (Front & Rear)
    function buildWheel(radius: number, width: number): THREE.Group {
        const wheel = new THREE.Group();
        // Tire
        const tireGeo = new THREE.CylinderGeometry(radius, radius, width, 24);
        tireGeo.rotateZ(Math.PI / 2);
        const tire = new THREE.Mesh(tireGeo, tireRubberMat);
        wheel.add(tire);

        // Chrome Rim
        const rimGeo = new THREE.CylinderGeometry(radius * 0.72, radius * 0.72, width * 0.9, 20);
        rimGeo.rotateZ(Math.PI / 2);
        const rim = new THREE.Mesh(rimGeo, chromeMat);
        wheel.add(rim);

        // Brake rotor
        const rotorGeo = new THREE.CylinderGeometry(radius * 0.55, radius * 0.55, width * 1.05, 16);
        rotorGeo.rotateZ(Math.PI / 2);
        const rotor = new THREE.Mesh(rotorGeo, brakeRotorMat);
        wheel.add(rotor);

        return wheel;
    }

    const frontWheel = buildWheel(0.42, 0.22);
    frontWheel.position.set(0, 0.42, 1.15);
    bike.add(frontWheel);

    const rearWheel = buildWheel(0.45, 0.28);
    rearWheel.position.set(0, 0.45, -1.1);
    bike.add(rearWheel);

    // 7. Front Fork & Handlebars
    const forkGroup = new THREE.Group();
    const strutGeo = new THREE.CylinderGeometry(0.045, 0.045, 1.1, 8);
    const leftStrut = new THREE.Mesh(strutGeo, chromeMat);
    leftStrut.position.x = -0.16;
    forkGroup.add(leftStrut);

    const rightStrut = new THREE.Mesh(strutGeo, chromeMat);
    rightStrut.position.x = 0.16;
    forkGroup.add(rightStrut);

    // Handlebar bar
    const barGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.75, 8);
    barGeo.rotateZ(Math.PI / 2);
    const bar = new THREE.Mesh(barGeo, chromeMat);
    bar.position.set(0, 0.55, -0.05);
    forkGroup.add(bar);

    // Rubber Grips
    const gripGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.14, 8);
    gripGeo.rotateZ(Math.PI / 2);
    const leftGrip = new THREE.Mesh(gripGeo, tireRubberMat);
    leftGrip.position.set(-0.35, 0.55, -0.05);
    forkGroup.add(leftGrip);
    const rightGrip = new THREE.Mesh(gripGeo, tireRubberMat);
    rightGrip.position.set(0.35, 0.55, -0.05);
    forkGroup.add(rightGrip);

    // Mirrors
    const mirrorGeo = new THREE.BoxGeometry(0.1, 0.06, 0.02);
    const leftMirror = new THREE.Mesh(mirrorGeo, chromeMat);
    leftMirror.position.set(-0.4, 0.65, -0.06);
    forkGroup.add(leftMirror);
    const rightMirror = new THREE.Mesh(mirrorGeo, chromeMat);
    rightMirror.position.set(0.4, 0.65, -0.06);
    forkGroup.add(rightMirror);

    forkGroup.rotation.x = Math.PI / 8;
    forkGroup.position.set(0, 0.55, 0.95);
    bike.add(forkGroup);

    // 8. Rider (Torso, Leaning Arms, Helmet)
    const riderTorso = new THREE.Group();

    // Body
    const bodyGeo = new THREE.BoxGeometry(0.45, 0.55, 0.35);
    const torsoMesh = new THREE.Mesh(bodyGeo, riderSuitMat);
    torsoMesh.position.set(0, 0.3, 0);
    riderTorso.add(torsoMesh);

    // Arms reaching for bars
    const armGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.55, 8);
    armGeo.rotateX(Math.PI / 3);
    const leftArm = new THREE.Mesh(armGeo, riderSuitMat);
    leftArm.position.set(-0.25, 0.25, 0.25);
    riderTorso.add(leftArm);
    const rightArm = new THREE.Mesh(armGeo, riderSuitMat);
    rightArm.position.set(0.25, 0.25, 0.25);
    riderTorso.add(rightArm);

    // Helmet
    const helmetGeo = new THREE.SphereGeometry(0.22, 16, 14);
    const helmet = new THREE.Mesh(helmetGeo, bodyPaintMat);
    helmet.position.set(0, 0.68, 0.12);
    riderTorso.add(helmet);

    // Helmet Visor
    const visorGeo = new THREE.BoxGeometry(0.26, 0.1, 0.12);
    const visor = new THREE.Mesh(visorGeo, helmetVisorMat);
    visor.position.set(0, 0.68, 0.26);
    riderTorso.add(visor);

    riderTorso.position.set(0, 0.9, -0.3);
    riderTorso.rotation.x = Math.PI / 10; // forward lean
    bike.add(riderTorso);

    // 9. Contact Shadow plane beneath motorcycle
    const contactShadow = createContactShadow(0.7, 1.8);
    bike.add(contactShadow);

    return {
        group: bike,
        frontWheel,
        rearWheel,
        handlebars: forkGroup,
        riderTorso,
        brakeLight,
        exhaustParticlesOrigin: new THREE.Vector3(0.26, 0.35, -1.2),
    };
}

/**
 * Creates traffic vehicles (Cars, SUVs, Trucks, Sportbikes)
 * Built as multi-part composite groups with varied PBR materials and contact shadows.
 */
export function createTrafficVehicle(
    type: 'car' | 'suv' | 'truck' | 'sportbike',
    vehicleColor: number = 0x2563eb
): THREE.Group {
    const vehicle = new THREE.Group();

    const bodyMat = new THREE.MeshStandardMaterial({
        color: vehicleColor,
        metalness: 0.3,
        roughness: 0.25,
    });

    const glassMat = new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        metalness: 0.9,
        roughness: 0.1,
    });

    const tireMat = new THREE.MeshStandardMaterial({
        color: 0x111318,
        metalness: 0.05,
        roughness: 0.85,
    });

    const chromeMat = new THREE.MeshStandardMaterial({
        color: 0xe2e8f0,
        metalness: 0.9,
        roughness: 0.15,
    });

    const tailLightMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
    });

    const headLightMat = new THREE.MeshBasicMaterial({
        color: 0xfef08a,
    });

    if (type === 'truck') {
        // Truck Cabin & Large Cargo Container
        const cabGeo = new THREE.BoxGeometry(1.9, 1.8, 2.0);
        const cab = new THREE.Mesh(cabGeo, bodyMat);
        cab.position.set(0, 1.3, 2.2);
        vehicle.add(cab);

        // Windshield
        const winGeo = new THREE.BoxGeometry(1.7, 0.7, 0.1);
        const win = new THREE.Mesh(winGeo, glassMat);
        win.position.set(0, 1.6, 3.22);
        vehicle.add(win);

        // Huge Trailer Container
        const trailerMat = new THREE.MeshStandardMaterial({
            color: 0x64748b,
            metalness: 0.4,
            roughness: 0.4,
        });
        const trailerGeo = new THREE.BoxGeometry(2.1, 2.4, 6.2);
        const trailer = new THREE.Mesh(trailerGeo, trailerMat);
        trailer.position.set(0, 1.8, -1.8);
        vehicle.add(trailer);

        // 6 Wheels
        const wheelGeo = new THREE.CylinderGeometry(0.48, 0.48, 0.32, 16);
        wheelGeo.rotateZ(Math.PI / 2);
        [-0.95, 0.95].forEach((x) => {
            [2.2, -1.5, -3.8].forEach((z) => {
                const w = new THREE.Mesh(wheelGeo, tireMat);
                w.position.set(x, 0.48, z);
                vehicle.add(w);
            });
        });

        // Tail Lights
        const tLightGeo = new THREE.BoxGeometry(0.35, 0.15, 0.1);
        const tl1 = new THREE.Mesh(tLightGeo, tailLightMat);
        tl1.position.set(-0.85, 0.7, -4.92);
        vehicle.add(tl1);
        const tl2 = new THREE.Mesh(tLightGeo, tailLightMat);
        tl2.position.set(0.85, 0.7, -4.92);
        vehicle.add(tl2);

        // Headlights
        const hlGeo = new THREE.BoxGeometry(0.3, 0.2, 0.1);
        const hl1 = new THREE.Mesh(hlGeo, headLightMat);
        hl1.position.set(-0.75, 0.75, 3.22);
        vehicle.add(hl1);
        const hl2 = new THREE.Mesh(hlGeo, headLightMat);
        hl2.position.set(0.75, 0.75, 3.22);
        vehicle.add(hl2);

        vehicle.add(createContactShadow(1.3, 4.6));
    } else if (type === 'suv') {
        // SUV
        const lowerGeo = new THREE.BoxGeometry(1.8, 0.7, 3.8);
        const lower = new THREE.Mesh(lowerGeo, bodyMat);
        lower.position.set(0, 0.65, 0);
        vehicle.add(lower);

        const upperGeo = new THREE.BoxGeometry(1.5, 0.65, 2.4);
        const upper = new THREE.Mesh(upperGeo, glassMat);
        upper.position.set(0, 1.25, -0.2);
        vehicle.add(upper);

        // Grille & Bumper
        const bumperGeo = new THREE.BoxGeometry(1.7, 0.25, 0.2);
        const bumper = new THREE.Mesh(bumperGeo, chromeMat);
        bumper.position.set(0, 0.45, 1.95);
        vehicle.add(bumper);

        // Wheels
        const wGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.26, 16);
        wGeo.rotateZ(Math.PI / 2);
        [-0.88, 0.88].forEach((x) => {
            [-1.1, 1.1].forEach((z) => {
                const w = new THREE.Mesh(wGeo, tireMat);
                w.position.set(x, 0.38, z);
                vehicle.add(w);
            });
        });

        // Lights
        const tlGeo = new THREE.BoxGeometry(0.3, 0.12, 0.08);
        const tl1 = new THREE.Mesh(tlGeo, tailLightMat);
        tl1.position.set(-0.7, 0.85, -1.92);
        vehicle.add(tl1);
        const tl2 = new THREE.Mesh(tlGeo, tailLightMat);
        tl2.position.set(0.7, 0.85, -1.92);
        vehicle.add(tl2);

        vehicle.add(createContactShadow(1.1, 2.2));
    } else if (type === 'sportbike') {
        // Rival sportbike (compact)
        const frameGeo = new THREE.BoxGeometry(0.4, 0.5, 1.4);
        const frame = new THREE.Mesh(frameGeo, bodyMat);
        frame.position.set(0, 0.65, 0);
        vehicle.add(frame);

        const wGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.18, 16);
        wGeo.rotateZ(Math.PI / 2);
        const fw = new THREE.Mesh(wGeo, tireMat);
        fw.position.set(0, 0.36, 0.9);
        vehicle.add(fw);
        const rw = new THREE.Mesh(wGeo, tireMat);
        rw.position.set(0, 0.36, -0.9);
        vehicle.add(rw);

        const riderGeo = new THREE.BoxGeometry(0.36, 0.5, 0.4);
        const rider = new THREE.Mesh(riderGeo, glassMat);
        rider.position.set(0, 0.95, -0.1);
        vehicle.add(rider);

        const tlGeo = new THREE.BoxGeometry(0.2, 0.1, 0.05);
        const tl = new THREE.Mesh(tlGeo, tailLightMat);
        tl.position.set(0, 0.7, -0.8);
        vehicle.add(tl);

        vehicle.add(createContactShadow(0.5, 1.2));
    } else {
        // Standard Sedan / Muscle Car
        const lowerGeo = new THREE.BoxGeometry(1.7, 0.55, 3.6);
        const lower = new THREE.Mesh(lowerGeo, bodyMat);
        lower.position.set(0, 0.55, 0);
        vehicle.add(lower);

        const cabinGeo = new THREE.BoxGeometry(1.4, 0.5, 2.0);
        const cabin = new THREE.Mesh(cabinGeo, glassMat);
        cabin.position.set(0, 1.05, -0.2);
        vehicle.add(cabin);

        // 4 Wheels
        const wGeo = new THREE.CylinderGeometry(0.34, 0.34, 0.24, 16);
        wGeo.rotateZ(Math.PI / 2);
        [-0.85, 0.85].forEach((x) => {
            [-1.1, 1.1].forEach((z) => {
                const w = new THREE.Mesh(wGeo, tireMat);
                w.position.set(x, 0.34, z);
                vehicle.add(w);
            });
        });

        // Tail Lights
        const tlGeo = new THREE.BoxGeometry(0.28, 0.1, 0.06);
        const tl1 = new THREE.Mesh(tlGeo, tailLightMat);
        tl1.position.set(-0.65, 0.65, -1.82);
        vehicle.add(tl1);
        const tl2 = new THREE.Mesh(tlGeo, tailLightMat);
        tl2.position.set(0.65, 0.65, -1.82);
        vehicle.add(tl2);

        vehicle.add(createContactShadow(1.05, 2.0));
    }

    return vehicle;
}

/**
 * Creates 3D collectible items:
 * - 'boost': Glowing cyan/blue nitro crystal with energy halo
 * - 'coin': Golden adventure coin with embossed rim
 * - 'repair': Green shield toolkit
 */
export function createCollectibleMesh(type: 'boost' | 'coin' | 'repair'): THREE.Group {
    const group = new THREE.Group();

    if (type === 'boost') {
        const coreGeo = new THREE.OctahedronGeometry(0.38, 0);
        const coreMat = new THREE.MeshStandardMaterial({
            color: 0x06b6d4,
            emissive: 0x0891b2,
            emissiveIntensity: 0.8,
            metalness: 0.7,
            roughness: 0.1,
        });
        const core = new THREE.Mesh(coreGeo, coreMat);
        group.add(core);

        const ringGeo = new THREE.TorusGeometry(0.55, 0.05, 8, 24);
        const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 2;
        group.add(ring);
    } else if (type === 'repair') {
        const shieldGeo = new THREE.DodecahedronGeometry(0.36, 0);
        const shieldMat = new THREE.MeshStandardMaterial({
            color: 0x10b981,
            emissive: 0x059669,
            emissiveIntensity: 0.7,
            metalness: 0.6,
            roughness: 0.2,
        });
        const shield = new THREE.Mesh(shieldGeo, shieldMat);
        group.add(shield);

        const ringGeo = new THREE.TorusGeometry(0.52, 0.04, 8, 20);
        const ringMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        group.add(ring);
    } else {
        // Gold Coin
        const coinGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.08, 18);
        coinGeo.rotateX(Math.PI / 2);
        const coinMat = new THREE.MeshStandardMaterial({
            color: 0xf59e0b,
            emissive: 0xd97706,
            emissiveIntensity: 0.5,
            metalness: 0.95,
            roughness: 0.15,
        });
        const coin = new THREE.Mesh(coinGeo, coinMat);
        group.add(coin);
    }

    group.position.y = 0.9;
    return group;
}

/**
 * Creates roadside canyon environment (stepped rock cliffs, desert pine trees, barriers)
 */
export function createCanyonEnvironment(scene: THREE.Scene): {
    roadMesh: THREE.Mesh;
    cliffLeft: THREE.Mesh;
    cliffRight: THREE.Mesh;
    guardrailLeft: THREE.Mesh;
    guardrailRight: THREE.Mesh;
} {
    // 1. Highway Surface
    const roadGeo = new THREE.PlaneGeometry(16, 400, 1, 1);
    const roadTex = createHighwayTexture();
    const roadMat = new THREE.MeshStandardMaterial({
        map: roadTex,
        roughness: 0.8,
        metalness: 0.1,
    });
    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    roadMesh.rotation.x = -Math.PI / 2;
    roadMesh.position.set(0, 0, 0);
    roadMesh.receiveShadow = true;
    scene.add(roadMesh);

    // 2. Sandstone Canyon Cliffs Left & Right
    const cliffGeo = new THREE.BoxGeometry(40, 24, 400);
    const cliffMat = new THREE.MeshStandardMaterial({
        color: 0x9a3412, // Warm red-rock sandstone
        roughness: 0.95,
        metalness: 0.05,
    });

    const cliffLeft = new THREE.Mesh(cliffGeo, cliffMat);
    cliffLeft.position.set(-29, 10, 0);
    scene.add(cliffLeft);

    const cliffRight = new THREE.Mesh(cliffGeo, cliffMat);
    cliffRight.position.set(29, 10, 0);
    scene.add(cliffRight);

    // 3. Highway Steel Guardrails Left & Right
    const railMat = new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.85,
        roughness: 0.25,
    });
    const railGeo = new THREE.BoxGeometry(0.3, 0.6, 400);

    const guardrailLeft = new THREE.Mesh(railGeo, railMat);
    guardrailLeft.position.set(-8.1, 0.45, 0);
    scene.add(guardrailLeft);

    const guardrailRight = new THREE.Mesh(railGeo, railMat);
    guardrailRight.position.set(8.1, 0.45, 0);
    scene.add(guardrailRight);

    return {
        roadMesh,
        cliffLeft,
        cliffRight,
        guardrailLeft,
        guardrailRight,
    };
}
