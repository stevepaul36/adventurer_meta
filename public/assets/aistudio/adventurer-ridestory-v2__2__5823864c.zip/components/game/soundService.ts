/**
 * Procedural Web Audio API Sound Synthesizer for Apex Moto 3D.
 * Zero external audio files or network dependencies.
 */

class SoundService {
    private ctx: AudioContext | null = null;
    private isMuted: boolean = false;
    private engineOsc: OscillatorNode | null = null;
    private engineSubOsc: OscillatorNode | null = null;
    private engineGain: GainNode | null = null;
    private engineFilter: BiquadFilterNode | null = null;
    private isEngineRunning: boolean = false;

    constructor() {
        // AudioContext will be initialized on first user gesture
    }

    private initContext() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
            this.ctx = new AudioCtx();
        }
        if (this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    public setMuted(muted: boolean) {
        this.isMuted = muted;
        if (muted) {
            if (this.engineGain) {
                this.engineGain.gain.setValueAtTime(0, this.ctx?.currentTime || 0);
            }
        }
    }

    public getMuted(): boolean {
        return this.isMuted;
    }

    public toggleMuted(): boolean {
        this.setMuted(!this.isMuted);
        return this.isMuted;
    }

    public startEngine() {
        if (this.isEngineRunning) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;
            this.engineOsc = this.ctx.createOscillator();
            this.engineSubOsc = this.ctx.createOscillator();
            this.engineFilter = this.ctx.createBiquadFilter();
            this.engineGain = this.ctx.createGain();

            // Main motor rumble (sawtooth for mechanical grit)
            this.engineOsc.type = 'sawtooth';
            this.engineOsc.frequency.setValueAtTime(45, now);

            // Sub-bass thump (triangle)
            this.engineSubOsc.type = 'triangle';
            this.engineSubOsc.frequency.setValueAtTime(22.5, now);

            // Lowpass filter to muffle harsh harmonics
            this.engineFilter.type = 'lowpass';
            this.engineFilter.frequency.setValueAtTime(280, now);
            this.engineFilter.Q.setValueAtTime(2.5, now);

            this.engineGain.gain.setValueAtTime(this.isMuted ? 0 : 0.08, now);

            this.engineOsc.connect(this.engineFilter);
            this.engineSubOsc.connect(this.engineFilter);
            this.engineFilter.connect(this.engineGain);
            this.engineGain.connect(this.ctx.destination);

            this.engineOsc.start();
            this.engineSubOsc.start();
            this.isEngineRunning = true;
        } catch {
            // Audio context failed to start
        }
    }

    public updateEngineSpeed(speedRatio: number, isBoosting: boolean) {
        if (!this.isEngineRunning || !this.ctx || !this.engineOsc || !this.engineSubOsc || !this.engineFilter || !this.engineGain) return;
        if (this.isMuted) {
            this.engineGain.gain.setValueAtTime(0, this.ctx.currentTime);
            return;
        }

        const now = this.ctx.currentTime;
        // Pitch scales smoothly from 45Hz idle to 180Hz redline (boost up to 240Hz)
        const baseFreq = 45 + speedRatio * 110 + (isBoosting ? 60 : 0);
        this.engineOsc.frequency.setTargetAtTime(baseFreq, now, 0.05);
        this.engineSubOsc.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.05);

        // Filter cutoff opens up as speed increases
        const cutoff = 260 + speedRatio * 600 + (isBoosting ? 500 : 0);
        this.engineFilter.frequency.setTargetAtTime(cutoff, now, 0.05);

        // Gain stays balanced
        const targetVol = 0.06 + speedRatio * 0.07 + (isBoosting ? 0.05 : 0);
        this.engineGain.gain.setTargetAtTime(targetVol, now, 0.05);
    }

    public stopEngine() {
        if (!this.isEngineRunning) return;
        try {
            this.engineOsc?.stop();
            this.engineSubOsc?.stop();
            this.engineOsc?.disconnect();
            this.engineSubOsc?.disconnect();
            this.engineFilter?.disconnect();
            this.engineGain?.disconnect();
        } catch {
            // ignore
        }
        this.isEngineRunning = false;
        this.engineOsc = null;
        this.engineSubOsc = null;
        this.engineFilter = null;
        this.engineGain = null;
    }

    public playNitroWhoosh() {
        if (this.isMuted) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;
            // Generate pink/white noise buffer for rushing wind
            const bufferSize = this.ctx.sampleRate * 0.8;
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.35));
            }

            const noiseSource = this.ctx.createBufferSource();
            noiseSource.buffer = buffer;

            const bandpass = this.ctx.createBiquadFilter();
            bandpass.type = 'bandpass';
            bandpass.frequency.setValueAtTime(300, now);
            bandpass.frequency.exponentialRampToValueAtTime(2400, now + 0.3);
            bandpass.frequency.exponentialRampToValueAtTime(400, now + 0.8);
            bandpass.Q.setValueAtTime(3.0, now);

            const gain = this.ctx.createGain();
            gain.gain.setValueAtTime(0.25, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

            noiseSource.connect(bandpass);
            bandpass.connect(gain);
            gain.connect(this.ctx.destination);

            noiseSource.start(now);
            noiseSource.stop(now + 0.85);
        } catch {
            // Audio error
        }
    }

    public playNearMissChime() {
        if (this.isMuted) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;
            // Dual chime chords (E5 + B5)
            [659.25, 987.77].forEach((freq, idx) => {
                if (!this.ctx) return;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, now + idx * 0.04);
                osc.frequency.exponentialRampToValueAtTime(freq * 1.25, now + idx * 0.04 + 0.2);

                gain.gain.setValueAtTime(0.12, now + idx * 0.04);
                gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.04 + 0.35);

                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now + idx * 0.04);
                osc.stop(now + idx * 0.04 + 0.38);
            });
        } catch {
            // Audio error
        }
    }

    public playCoinChime() {
        if (this.isMuted) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;
            // Ascending high bell triad: B5 -> D#6 -> F#6
            [987.77, 1244.51, 1479.98].forEach((freq, idx) => {
                if (!this.ctx) return;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                const startTime = now + idx * 0.05;
                osc.frequency.setValueAtTime(freq, startTime);

                gain.gain.setValueAtTime(0.14, startTime);
                gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.25);

                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(startTime);
                osc.stop(startTime + 0.28);
            });
        } catch {
            // Audio error
        }
    }

    public playCrashSound() {
        if (this.isMuted) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;

            // 1. Heavy low-frequency punch
            const subOsc = this.ctx.createOscillator();
            const subGain = this.ctx.createGain();
            subOsc.type = 'triangle';
            subOsc.frequency.setValueAtTime(140, now);
            subOsc.frequency.exponentialRampToValueAtTime(28, now + 0.45);
            subGain.gain.setValueAtTime(0.35, now);
            subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
            subOsc.connect(subGain);
            subGain.connect(this.ctx.destination);
            subOsc.start(now);
            subOsc.stop(now + 0.52);

            // 2. High crunch / metal deformation noise
            const bufferSize = Math.floor(this.ctx.sampleRate * 0.4);
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / bufferSize, 1.8);
            }
            const noise = this.ctx.createBufferSource();
            noise.buffer = buffer;

            const filter = this.ctx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(1200, now);
            filter.frequency.exponentialRampToValueAtTime(200, now + 0.4);

            const noiseGain = this.ctx.createGain();
            noiseGain.gain.setValueAtTime(0.3, now);
            noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

            noise.connect(filter);
            filter.connect(noiseGain);
            noiseGain.connect(this.ctx.destination);
            noise.start(now);
            noise.stop(now + 0.42);
        } catch {
            // Audio error
        }
    }

    public playButtonHover() {
        if (this.isMuted) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(440, now);
            gain.gain.setValueAtTime(0.04, now);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.07);
        } catch {
            // ignore
        }
    }

    public playStartGameFanfare() {
        if (this.isMuted) return;
        this.initContext();
        if (!this.ctx) return;

        try {
            const now = this.ctx.currentTime;
            const notes = [440, 554.37, 659.25, 880]; // A4, C#5, E5, A5
            notes.forEach((freq, idx) => {
                if (!this.ctx) return;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'triangle';
                const startTime = now + idx * 0.09;
                osc.frequency.setValueAtTime(freq, startTime);
                gain.gain.setValueAtTime(0.12, startTime);
                gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(startTime);
                osc.stop(startTime + 0.45);
            });
        } catch {
            // ignore
        }
    }
}

export const soundService = new SoundService();
