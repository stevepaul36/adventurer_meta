
import React from 'react';
import { STREAMS } from '../constants';
import type { Stream } from '../types';

interface StreamsPanelProps {
    onStreamSelect: (stream: Stream) => void;
}

const StreamCard: React.FC<{ stream: Stream; onClick: () => void; }> = ({ stream, onClick }) => (
    <div className="group cursor-pointer" onClick={onClick}>
        <div className="relative rounded-lg overflow-hidden">
            <img src={stream.thumbnailUrl} alt={stream.title} className="w-full aspect-video object-cover transition-transform group-hover:scale-105" />
            {stream.isLive && (
                <div className="absolute top-2 left-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-md animate-pulse">
                    LIVE
                </div>
            )}
            <div className="absolute bottom-2 right-2 bg-black bg-opacity-60 text-white text-xs font-semibold px-2 py-1 rounded-md">
                {stream.isLive ? `${stream.viewers} viewers` : 'Offline'}
            </div>
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity"></div>
        </div>
        <div className="flex items-start mt-3 space-x-3">
            <img src={stream.streamer.avatarUrl} alt={stream.streamer.name} className="w-10 h-10 rounded-full" />
            <div>
                <h4 className="font-bold text-white group-hover:text-orange-500 transition-colors">{stream.title}</h4>
                <p className="text-sm text-gray-400">{stream.streamer.name}</p>
            </div>
        </div>
    </div>
);

const StreamsPanel: React.FC<StreamsPanelProps> = ({ onStreamSelect }) => {
  return (
    <div className="mb-20 md:mb-0">
      <h2 className="text-3xl font-bold mb-6 text-white">Live Streams</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {STREAMS.map(stream => (
          <StreamCard key={stream.id} stream={stream} onClick={() => onStreamSelect(stream)} />
        ))}
      </div>
    </div>
  );
};

export default StreamsPanel;
