
import React, { useState } from 'react';
import type { RideShare, Comment } from '../types';
import { HeartIcon, CommentIcon, RouteIcon, MapPinIcon, ClockIcon, ArrowUpIcon, SendIcon } from './icons';
import { CURRENT_USER } from '../constants';

interface RideShareCardProps {
    rideShare: RideShare;
    onUserSelect: (userId: string) => void;
}

const RideStat: React.FC<{ icon: React.ReactNode; label: string; value: string | number }> = ({ icon, label, value }) => (
    <div className="flex items-center space-x-2 text-gray-400">
        <div className="bg-slate-800 p-2 rounded-full">{icon}</div>
        <div>
            <p className="text-xs">{label}</p>
            <p className="font-bold text-sm text-white">{value}</p>
        </div>
    </div>
);

const RideShareCard: React.FC<RideShareCardProps> = ({ rideShare, onUserSelect }) => {
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(rideShare.likes);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [comments, setComments] = useState<Comment[]>(rideShare.comments);
  const [newComment, setNewComment] = useState('');

  const handleLikeClick = () => {
      setIsLiked(!isLiked);
      setLikeCount(prevCount => isLiked ? prevCount - 1 : prevCount + 1);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
        const newCommentObject: Comment = {
            id: `c-${Date.now()}`,
            user: CURRENT_USER,
            text: newComment.trim(),
        };
        setComments(prevComments => [...prevComments, newCommentObject]);
        setNewComment('');
    }
  };

  return (
    <div className="bg-slate-900 rounded-lg overflow-hidden shadow-lg">
      <div className="p-4">
        <button onClick={() => onUserSelect(rideShare.user.id)} className="flex items-center text-left group w-full">
            <img src={rideShare.user.avatarUrl} alt={rideShare.user.name} className="w-12 h-12 rounded-full mr-4 transition-all duration-300 group-hover:ring-2 group-hover:ring-orange-500" />
            <div className="flex-1">
                <p className="font-bold text-white transition-colors group-hover:text-orange-400">{rideShare.user.name}</p>
                <p className="text-sm text-gray-500">{rideShare.timestamp} &middot; Shared a ride</p>
            </div>
        </button>
      </div>
      <div className="relative">
        <img src={rideShare.mapImageUrl} alt={rideShare.title} className="w-full h-auto object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-4">
            <h3 className="text-2xl font-bold text-white">{rideShare.title}</h3>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4 p-4 bg-slate-800/50">
           <RideStat icon={<MapPinIcon className="w-5 h-5 text-orange-400"/>} label="Distance" value={`${rideShare.rideStats.distance} km`} />
           <RideStat icon={<ClockIcon className="w-5 h-5 text-orange-400"/>} label="Duration" value={rideShare.rideStats.duration} />
           <RideStat icon={<ArrowUpIcon className="w-5 h-5 text-orange-400"/>} label="Elevation" value={`${rideShare.rideStats.elevation} m`} />
      </div>
      <div className="flex justify-around items-center p-2 border-t border-slate-800">
        <button
            onClick={handleLikeClick}
            className={`flex items-center space-x-2 transition-colors ${isLiked ? 'text-orange-500' : 'text-gray-400 hover:text-orange-500'}`}
            aria-pressed={isLiked}
            aria-label={isLiked ? 'Unlike post' : 'Like post'}
        >
            <HeartIcon className="w-5 h-5" fill={isLiked ? 'currentColor' : 'none'}/> <span>{likeCount}</span>
        </button>
        <button
            onClick={() => setIsCommentsOpen(!isCommentsOpen)}
            className="flex items-center space-x-2 text-gray-400 hover:text-orange-500 transition-colors"
            aria-expanded={isCommentsOpen}
        >
            <CommentIcon className="w-5 h-5"/> <span>{comments.length}</span>
        </button>
        <button className="flex items-center space-x-2 text-gray-400 hover:text-orange-500 transition-colors">
            <RouteIcon className="w-5 h-5"/> <span>View Route</span>
        </button>
      </div>
      {isCommentsOpen && (
          <div className="p-4 space-y-3 border-t border-slate-800 animate-fade-in">
            {comments.map(comment => (
                <div key={comment.id} className="flex items-start space-x-3">
                    <img src={comment.user.avatarUrl} alt={comment.user.name} className="w-8 h-8 rounded-full"/>
                    <div className="bg-slate-800 rounded-lg p-2 flex-1">
                        <button onClick={() => onUserSelect(comment.user.id)} className="font-semibold text-sm text-white hover:underline">{comment.user.name}</button>
                        <p className="text-sm text-gray-300">{comment.text}</p>
                    </div>
                </div>
            ))}
             {comments.length === 0 && <p className="text-center text-sm text-gray-500 py-2">No comments yet.</p>}
             <form onSubmit={handleCommentSubmit} className="flex items-center space-x-3 pt-2">
                <img src={CURRENT_USER.avatarUrl} alt={CURRENT_USER.name} className="w-8 h-8 rounded-full"/>
                 <div className="flex-1 relative">
                    <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Add a comment..."
                        className="w-full bg-slate-800 rounded-full py-2 pl-4 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-orange-500">
                        <SendIcon className="w-5 h-5" />
                    </button>
                 </div>
             </form>
          </div>
      )}
    </div>
  );
};

export default RideShareCard;