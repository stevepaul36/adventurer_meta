
import React from 'react';
import type { ActivityType, RideStory, FeedItem, RidingGoal } from '../types';
import { JOURNEYS, RIDING_GOALS } from '../constants';
import RideFeed from './RideFeed';
import GoalsPanel from './GoalsPanel';
import SafetySosPanel from './SafetySosPanel';
import FriendsShots from './FriendsShots';
import SearchUsers from './SearchUsers';
import SafetyTipsPanel from './SafetyTipsPanel';
import { RoadIcon, BicycleIcon, FootstepsIcon, MountainIcon, CarIcon, UsersGroupIcon, MapPinIcon, GamepadIcon, CompassIcon, ShieldAlertIcon, RupeeIcon, SparklesIcon, ArchitectureIcon } from './icons';
import StreamsOverview from './StreamsOverview';
import ClubsOverview from './ClubsOverview';
import { DashboardGamificationStrip } from './gamification/DashboardGamificationStrip';
import type { SupportedLanguage } from '../services/i18nService';
import { getTranslation } from '../services/i18nService';

const activityModes: { mode: ActivityType; label: string; icon: React.FC<{className?: string}> }[] = [
    { mode: 'Motorcycling', label: 'Motorcycle', icon: RoadIcon },
    { mode: 'Cycling', label: 'Cycle', icon: BicycleIcon },
    { mode: 'Walking', label: 'Walk', icon: FootstepsIcon },
    { mode: 'Trekking/Hiking', label: 'Hike', icon: MountainIcon },
    { mode: 'Car Trips', label: 'Car', icon: CarIcon },
    { mode: 'Hybrid', label: 'Hybrid', icon: UsersGroupIcon },
];

const ActivityModeSwitcher: React.FC<{
    activeMode: ActivityType;
    onModeChange: (mode: ActivityType) => void;
}> = ({ activeMode, onModeChange }) => {

    const ModeButton: React.FC<{ mode: ActivityType, label: string, icon: React.FC<{className?: string}>}> = ({ mode, label, icon: Icon }) => {
        const isActive = activeMode === mode;
        return (
            <button
                onClick={() => onModeChange(mode)}
                className={`flex flex-col items-center justify-center space-y-2 p-3 rounded-lg w-24 transition-all duration-200 flex-shrink-0 ${
                    isActive 
                        ? 'bg-orange-600/20 border border-orange-500 scale-105' 
                        : 'bg-slate-800/50 hover:bg-slate-700'
                }`}
            >
                <Icon className={`w-8 h-8 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                <span className={`text-xs font-semibold ${isActive ? 'text-white' : 'text-gray-400'}`}>{label}</span>
            </button>
        );
    };

    return (
        <div className="mb-8">
            <h3 className="text-xl font-bold text-white mb-4">Select Activity Mode</h3>
            <div className="flex space-x-2 sm:space-x-4 overflow-x-auto py-4 scrollbar-hide pl-4">
                {activityModes.map(({ mode, label, icon }) => (
                    <ModeButton key={mode} mode={mode} label={label} icon={icon} />
                ))}
            </div>
        </div>
    );
};

interface DashboardProps {
    onShowShots: () => void;
    onShowStreams: () => void;
    onShowClubs: () => void;
    onUserSelect: (userId: string) => void;
    activityMode: ActivityType;
    setActivityMode: (mode: ActivityType) => void;
    onShowRideStory: (story: RideStory) => void;
    feedItems: FeedItem[];
    onShowGps: () => void;
    onShowGame: () => void;
    onOpenGamification: () => void;
    onOpenExpeditions?: () => void;
    onOpenRadar?: () => void;
    onOpenBudget?: () => void;
    onOpenStoryStudio?: () => void;
    onOpenArchitecture?: () => void;
    language?: SupportedLanguage;
}

const Dashboard: React.FC<DashboardProps> = ({ 
    onShowShots, 
    onShowStreams, 
    onShowClubs, 
    onUserSelect, 
    activityMode, 
    setActivityMode, 
    onShowRideStory, 
    feedItems, 
    onShowGps, 
    onShowGame, 
    onOpenGamification,
    onOpenExpeditions,
    onOpenRadar,
    onOpenBudget,
    onOpenStoryStudio,
    onOpenArchitecture,
    language: currentLang,
}) => {
    const language: SupportedLanguage = currentLang || 'en';
    // Logic for first goal preview
    const firstGoal = RIDING_GOALS[0];
    const stats = JOURNEYS.reduce(
        (acc, journey) => {
            acc.totalDistance += journey.distance;
            acc.totalElevation += journey.elevation;
            return acc;
        },
        { totalDistance: 0, totalElevation: 0, rideCount: JOURNEYS.length }
    );
    const getProgressForGoal = (goal: RidingGoal) => {
        switch (goal.type) {
            case 'distance': return stats.totalDistance;
            case 'elevation': return stats.totalElevation;
            case 'count': return stats.rideCount;
            default: return 0;
        }
    };
    const currentProgress = getProgressForGoal(firstGoal);
    const progressPercent = Math.min((currentProgress / firstGoal.target) * 100, 100);
    const unit = firstGoal.type === 'count' ? '' : 'km';

    // Get saved arcade high score
    const savedHighScore = (() => {
        try {
            const data = localStorage.getItem('adventurer_apex_high_score');
            return data ? JSON.parse(data) : null;
        } catch {
            return null;
        }
    })();

    return (
        <>
            <SearchUsers onUserSelect={onUserSelect} />
            <ActivityModeSwitcher activeMode={activityMode} onModeChange={setActivityMode} />

            {/* GAMIFICATION XP, STREAK & BOUNTY STRIP */}
            <DashboardGamificationStrip onOpenHub={onOpenGamification} />

            {/* INDIA ADVENTURE & HIGHWAY ECOSYSTEM PILLARS */}
            <div className="bg-slate-900/90 rounded-2xl p-5 mb-8 border border-slate-800 shadow-xl">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
                    <div>
                        <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider">
                            <CompassIcon className="w-4 h-4" />
                            <span>{getTranslation('explore_routes', language)}</span>
                        </div>
                        <h3 className="text-xl font-bold text-white tracking-tight mt-0.5">
                            India High-Altitude Adventure & Safety Grid
                        </h3>
                    </div>

                    {onOpenArchitecture && (
                        <button
                            onClick={onOpenArchitecture}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-white text-xs font-semibold transition-all shadow-sm"
                        >
                            <ArchitectureIcon className="w-4 h-4 text-amber-400" />
                            <span>System Blueprint</span>
                        </button>
                    )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <button
                        onClick={onOpenExpeditions}
                        className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/60 hover:bg-slate-800/40 transition-all text-left group"
                    >
                        <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-2 group-hover:scale-110 transition-transform">
                            <CompassIcon className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-white block group-hover:text-amber-400 transition-colors">
                            Himalayan Circuits
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                            Ladakh, Spiti & Ghats
                        </span>
                    </button>

                    <button
                        onClick={onOpenRadar}
                        className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-rose-500/60 hover:bg-slate-800/40 transition-all text-left group"
                    >
                        <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-2 group-hover:scale-110 transition-transform">
                            <ShieldAlertIcon className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-white block group-hover:text-rose-400 transition-colors">
                            Roadside Radar & 112
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                            Potholes, Landslides & SOS
                        </span>
                    </button>

                    <button
                        onClick={onOpenBudget}
                        className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-cyan-500/60 hover:bg-slate-800/40 transition-all text-left group"
                    >
                        <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-2 group-hover:scale-110 transition-transform">
                            <RupeeIcon className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-white block group-hover:text-cyan-400 transition-colors">
                            Trip Budget (₹ INR)
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                            Fuel, FASTag & UPI Split
                        </span>
                    </button>

                    <button
                        onClick={onOpenStoryStudio}
                        className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-fuchsia-500/60 hover:bg-slate-800/40 transition-all text-left group"
                    >
                        <div className="w-8 h-8 rounded-lg bg-fuchsia-500/10 border border-fuchsia-500/30 flex items-center justify-center text-fuchsia-400 mb-2 group-hover:scale-110 transition-transform">
                            <SparklesIcon className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-bold text-white block group-hover:text-fuchsia-400 transition-colors">
                            Helmet Live & AI Reel
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                            HUD Telemetry & Diaries
                        </span>
                    </button>
                </div>
            </div>

            {/* 3D ARCADE GAME BANNER (APEX MOTO: CANYON RUN) */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-orange-950/40 rounded-xl p-6 mb-8 border border-orange-500/30 shadow-xl relative overflow-hidden">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
                    <div className="max-w-xl">
                        <div className="flex items-center space-x-2 mb-2">
                            <span className="text-xs uppercase font-bold tracking-widest text-orange-400 bg-orange-600/20 px-2.5 py-0.5 rounded border border-orange-500/30">
                                3D Arcade Simulation
                            </span>
                            {savedHighScore && (
                                <span className="text-xs text-amber-400 font-mono">
                                    Record: {savedHighScore.score.toLocaleString()} pts
                                </span>
                            )}
                        </div>
                        <h3 className="text-2xl md:text-3xl font-black text-white tracking-tight">
                            Apex Moto: Canyon Run
                        </h3>
                        <p className="text-gray-300 text-sm mt-1.5 leading-relaxed">
                            Experience real-time 3D physics, studio PBR reflections, and high-speed canyon highway weaving. Hit close-call multipliers, collect nitro, and share your runs to the feed!
                        </p>
                        <div className="flex items-center space-x-4 mt-3 text-xs text-gray-400 font-mono">
                            <span>Three.js PBR</span>
                            <span>·</span>
                            <span>Web Audio Synth</span>
                            <span>·</span>
                            <span>60 FPS</span>
                        </div>
                    </div>
                    <div className="flex-shrink-0 w-full md:w-auto">
                        <button
                            onClick={onShowGame}
                            className="w-full md:w-auto px-7 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 active:scale-95 text-white font-bold text-base shadow-lg shadow-orange-950/60 transition-all flex items-center justify-center space-x-3"
                        >
                            <GamepadIcon className="w-5 h-5 text-white" />
                            <span>Play Apex 3D</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* NEW ADVENTURE PANEL */}
            <div className="bg-slate-800/50 rounded-lg p-6 mb-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-700">
                <div className="flex-1 w-full">
                    <h3 className="text-2xl font-bold text-white">Ready for an Adventure?</h3>
                    <p className="text-gray-400 mt-1">Track your ride, conquer your goals, and share your journey.</p>
                    <div className="mt-4">
                        <div className="flex justify-between items-baseline mb-1">
                            <div className="flex items-center space-x-2">
                                <firstGoal.icon className="w-5 h-5 text-orange-400" />
                                <h4 className="font-bold text-white">{firstGoal.name}</h4>
                            </div>
                            <span className="text-sm font-semibold text-gray-400">
                                {currentProgress.toLocaleString()}/{firstGoal.target.toLocaleString()}{unit}
                            </span>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2.5">
                            <div
                                className="bg-orange-500 h-2.5 rounded-full"
                                style={{ width: `${progressPercent}%` }}
                            ></div>
                        </div>
                    </div>
                </div>
                <div className="flex-shrink-0 w-full md:w-auto">
                    <button onClick={onShowGps} className="w-full bg-orange-600 text-white font-bold py-4 px-8 rounded-full hover:bg-orange-700 transition-colors flex items-center justify-center space-x-3 text-lg shadow-lg shadow-orange-900/50">
                        <MapPinIcon className="w-6 h-6"/>
                        <span>Start GPS Ride</span>
                    </button>
                </div>
            </div>

            <FriendsShots onShowShots={onShowShots} />
            <StreamsOverview onShowStreams={onShowStreams} />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <RideFeed onUserSelect={onUserSelect} onShowRideStory={onShowRideStory} feedItems={feedItems} />
                </div>
                <aside className="space-y-6">
                    <ClubsOverview onShowClubs={onShowClubs} />
                    <SafetyTipsPanel />
                    <GoalsPanel journeys={JOURNEYS} />
                    <SafetySosPanel />
                </aside>
            </div>
        </>
    );
};

export default Dashboard;
