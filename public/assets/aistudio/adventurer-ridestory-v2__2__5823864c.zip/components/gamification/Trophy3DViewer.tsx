import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { Trophy3DData } from './types';

interface Trophy3DViewerProps {
    trophy: Trophy3DData;
}

export const Trophy3DViewer: React.FC<Trophy3DViewerProps> = ({ trophy }) => {
    const mountRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const container = mountRef.current;
        if (!container) return;

        // Software WebGL check
        const isSoftwareGl = (() => {
            const gl = document.createElement('canvas').getContext('webgl2');
            if (!gl) return true;
            const ext = gl.getExtension('WEBGL_debug_renderer_info');
            const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
            const gpu = String(gl.getParameter(param));
            gl.getExtension('WEBGL_lose_context')?.loseContext();
            return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
        })();

        // Scene, Camera, Renderer
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x090a0f);

        const width = container.clientWidth || 360;
        const height = container.clientHeight || 320;

        const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
        camera.position.set(0, 1.8, 4.5);
        camera.lookAt(0, 0.8, 0);

        const renderer = new THREE.WebGLRenderer({
            antialias: !isSoftwareGl,
            powerPreference: 'high-performance',
        });
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.25;
        renderer.setSize(width, height);
        renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
        renderer.shadowMap.enabled = !isSoftwareGl;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;

        container.appendChild(renderer.domElement);

        // Procedural Studio Environment for metallic reflections
        const pmremGenerator = new THREE.PMREMGenerator(renderer);
        scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
        pmremGenerator.dispose();

        // Studio Lighting
        const keyLight = new THREE.DirectionalLight(0xfffbeb, 2.5);
        keyLight.position.set(5, 8, 5);
        scene.add(keyLight);

        const rimLight = new THREE.DirectionalLight(0x38bdf8, 2.0);
        rimLight.position.set(-5, 4, -4);
        scene.add(rimLight);

        const fillLight = new THREE.HemisphereLight(0xffedd5, 0x1e1b4b, 1.0);
        scene.add(fillLight);

        // Ground Podium Pedestal
        const pedestalGroup = new THREE.Group();
        const baseGeo = new THREE.CylinderGeometry(1.4, 1.6, 0.35, 32);
        const baseMat = new THREE.MeshStandardMaterial({
            color: 0x18181b,
            metalness: 0.8,
            roughness: 0.3,
        });
        const baseMesh = new THREE.Mesh(baseGeo, baseMat);
        baseMesh.position.y = 0.175;
        pedestalGroup.add(baseMesh);

        // Glowing trim ring on pedestal
        const trimGeo = new THREE.TorusGeometry(1.42, 0.035, 12, 36);
        trimGeo.rotateX(Math.PI / 2);
        const trimMat = new THREE.MeshBasicMaterial({ color: trophy.primaryColor });
        const trimMesh = new THREE.Mesh(trimGeo, trimMat);
        trimMesh.position.y = 0.35;
        pedestalGroup.add(trimMesh);

        scene.add(pedestalGroup);

        // Build 3D Trophy Model (Composite 3-8 parts)
        const trophyGroup = new THREE.Group();
        const trophyMat = new THREE.MeshStandardMaterial({
            color: trophy.unlocked ? trophy.primaryColor : 0x475569,
            metalness: trophy.unlocked ? trophy.metalness : 0.4,
            roughness: trophy.unlocked ? trophy.roughness : 0.6,
        });

        const accentMat = new THREE.MeshStandardMaterial({
            color: 0xf1f5f9,
            metalness: 0.95,
            roughness: 0.1,
        });

        if (trophy.modelType === 'piston') {
            // Engine Piston Trophy
            // Piston Crown
            const crownGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.75, 24);
            const crown = new THREE.Mesh(crownGeo, trophyMat);
            crown.position.y = 1.45;
            trophyGroup.add(crown);

            // Compression Ring Grooves
            const ringGeo = new THREE.TorusGeometry(0.56, 0.03, 8, 24);
            ringGeo.rotateX(Math.PI / 2);
            [-0.12, 0.05, 0.2].forEach((offsetY) => {
                const ring = new THREE.Mesh(ringGeo, accentMat);
                ring.position.y = 1.45 + offsetY;
                trophyGroup.add(ring);
            });

            // Wrist Pin (gudgeon pin)
            const pinGeo = new THREE.CylinderGeometry(0.14, 0.14, 1.0, 16);
            pinGeo.rotateZ(Math.PI / 2);
            const pin = new THREE.Mesh(pinGeo, accentMat);
            pin.position.y = 1.35;
            trophyGroup.add(pin);

            // Connecting Rod
            const rodGeo = new THREE.CylinderGeometry(0.12, 0.15, 0.85, 12);
            const rod = new THREE.Mesh(rodGeo, accentMat);
            rod.position.y = 0.85;
            trophyGroup.add(rod);
        } else if (trophy.modelType === 'mountain') {
            // Mountain Summit
            const peakGeo = new THREE.ConeGeometry(0.85, 1.4, 6);
            const peak = new THREE.Mesh(peakGeo, trophyMat);
            peak.position.y = 1.05;
            trophyGroup.add(peak);

            // Snowcap apex
            const snowGeo = new THREE.ConeGeometry(0.42, 0.6, 6);
            const snowMat = new THREE.MeshStandardMaterial({
                color: 0xffffff,
                metalness: 0.2,
                roughness: 0.2,
            });
            const snow = new THREE.Mesh(snowGeo, snowMat);
            snow.position.y = 1.45;
            trophyGroup.add(snow);
        } else if (trophy.modelType === 'helmet') {
            // Rider Helmet
            const domeGeo = new THREE.SphereGeometry(0.65, 24, 20);
            const dome = new THREE.Mesh(domeGeo, trophyMat);
            dome.position.y = 1.15;
            trophyGroup.add(dome);

            // Tinted visor
            const visorGeo = new THREE.CylinderGeometry(0.66, 0.66, 0.35, 18, 1, false, 0, Math.PI * 0.9);
            const visorMat = new THREE.MeshStandardMaterial({
                color: 0x0f172a,
                metalness: 0.95,
                roughness: 0.05,
            });
            const visor = new THREE.Mesh(visorGeo, visorMat);
            visor.position.set(0, 1.15, 0.02);
            trophyGroup.add(visor);
        } else {
            // Apex Cup
            // Cup Bowl
            const cupGeo = new THREE.CylinderGeometry(0.65, 0.25, 0.95, 24, 1, true);
            const cup = new THREE.Mesh(cupGeo, trophyMat);
            cup.position.y = 1.3;
            trophyGroup.add(cup);

            // Cup Base / Stem
            const stemGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.5, 16);
            const stem = new THREE.Mesh(stemGeo, accentMat);
            stem.position.y = 0.72;
            trophyGroup.add(stem);

            const footGeo = new THREE.CylinderGeometry(0.45, 0.55, 0.2, 24);
            const foot = new THREE.Mesh(footGeo, trophyMat);
            foot.position.y = 0.45;
            trophyGroup.add(foot);

            // Dual Curved Handles
            const handleGeo = new THREE.TorusGeometry(0.35, 0.06, 12, 20, Math.PI);
            handleGeo.rotateZ(-Math.PI / 2);

            const leftHandle = new THREE.Mesh(handleGeo, accentMat);
            leftHandle.position.set(-0.62, 1.35, 0);
            trophyGroup.add(leftHandle);

            const rightHandle = new THREE.Mesh(handleGeo, accentMat);
            rightHandle.rotation.y = Math.PI;
            rightHandle.position.set(0.62, 1.35, 0);
            trophyGroup.add(rightHandle);
        }

        scene.add(trophyGroup);

        // Interactive Pointer Drag Orbit Rotation
        let isDragging = false;
        let prevMouseX = 0;
        let rotationVelocity = 0.008;

        const onPointerDown = (e: MouseEvent | TouchEvent) => {
            isDragging = true;
            prevMouseX = 'touches' in e ? e.touches[0].clientX : e.clientX;
        };

        const onPointerMove = (e: MouseEvent | TouchEvent) => {
            if (!isDragging) return;
            const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
            const deltaX = clientX - prevMouseX;
            prevMouseX = clientX;
            trophyGroup.rotation.y += deltaX * 0.015;
            rotationVelocity = deltaX * 0.002;
        };

        const onPointerUp = () => {
            isDragging = false;
        };

        container.addEventListener('mousedown', onPointerDown);
        container.addEventListener('mousemove', onPointerMove);
        window.addEventListener('mouseup', onPointerUp);
        container.addEventListener('touchstart', onPointerDown);
        container.addEventListener('touchmove', onPointerMove);
        window.addEventListener('touchend', onPointerUp);

        // Animation Loop
        let animId = 0;
        const tick = () => {
            animId = requestAnimationFrame(tick);
            if (!isDragging) {
                // Natural slow showcase rotation
                trophyGroup.rotation.y += rotationVelocity;
                rotationVelocity = THREE.MathUtils.damp(rotationVelocity, 0.006, 2, 0.016);
            }
            renderer.render(scene, camera);
        };
        tick();

        return () => {
            cancelAnimationFrame(animId);
            container.removeEventListener('mousedown', onPointerDown);
            container.removeEventListener('mousemove', onPointerMove);
            window.removeEventListener('mouseup', onPointerUp);
            container.removeEventListener('touchstart', onPointerDown);
            container.removeEventListener('touchmove', onPointerMove);
            window.removeEventListener('touchend', onPointerUp);
            renderer.dispose();
            if (container && renderer.domElement) {
                container.removeChild(renderer.domElement);
            }
        };
    }, [trophy]);

    return (
        <div className="relative w-full h-80 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center select-none">
            <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
            <div className="absolute top-3 left-3 bg-slate-900/80 px-2.5 py-1 rounded-md text-[11px] font-mono text-gray-400 border border-slate-800">
                DRAG TO ROTATE 3D
            </div>
            {!trophy.unlocked && (
                <div className="absolute inset-0 bg-slate-950/70 flex flex-col items-center justify-center pointer-events-none p-4 text-center">
                    <span className="text-3xl mb-1">🔒</span>
                    <span className="text-sm font-bold text-gray-300">Trophy Locked</span>
                    <span className="text-xs text-gray-500 max-w-xs mt-1">{trophy.description}</span>
                </div>
            )}
        </div>
    );
};
