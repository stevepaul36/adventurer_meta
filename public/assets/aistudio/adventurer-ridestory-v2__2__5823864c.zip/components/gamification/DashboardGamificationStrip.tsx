import React, { useState, useEffect } from 'react';
import { gamificationService, getLevelTitle } from '../../services/gamificationService';
import type { GamificationState } from './types';
import { FlameIcon, TrophyIcon } from '../icons';

interface DashboardGamificationStripProps {
    onOpenHub: () => void;
}

export const DashboardGamificationStrip: React.FC<DashboardGamificationStripProps> = ({ onOpenHub }) => {
    const [state, setState] = useState<GamificationState>(gamificationService.getState());

    useEffect(() => {
        const unsubscribe = gamificationService.subscribe((updated) => {
            setState(updated);
        });
        return () => unsubscribe();
    }, []);

    const levelInfo = getLevelTitle(state.level);
    const xpPercent = Math.min(100, Math.round((state.currentXp / state.nextLevelXp) * 100));
    const activeQuest = state.quests.find((q) => !q.claimed) || state.quests[0];

    return (
        <div className="bg-slate-900 border border-slate-800 hover:border-orange-500/40 rounded-2xl p-4 sm:p-5 mb-8 shadow-lg transition-all">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                {/* Level & XP */}
                <div className="flex items-center space-x-3.5 flex-1 min-w-[240px]">
                    <div className="w-12 h-12 rounded-xl bg-orange-600/20 border border-orange-500/40 flex flex-col items-center justify-center font-mono">
                        <span className="text-[9px] uppercase tracking-wider text-orange-400 font-bold">LVL</span>
                        <span className="text-lg font-black text-white leading-none">{state.level}</span>
                    </div>
                    <div className="flex-1">
                        <div className="flex items-center space-x-2">
                            <span className="text-sm font-bold text-white tracking-tight">{levelInfo.title}</span>
                            <span className="text-[11px] text-gray-400 font-mono">
                                {state.currentXp.toLocaleString()} / {state.nextLevelXp.toLocaleString()} XP
                            </span>
                        </div>
                        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-1.5 max-w-xs">
                            <div
                                className="h-full bg-gradient-to-r from-orange-500 to-amber-400 transition-all duration-300"
                                style={{ width: `${xpPercent}%` }}
                            />
                        </div>
                    </div>
                </div>

                {/* Middle: Streak & Coins */}
                <div className="flex items-center space-x-4 border-y md:border-y-0 md:border-x border-slate-800 py-2 md:py-0 md:px-5 w-full md:w-auto justify-between md:justify-start">
                    <div className="flex items-center space-x-2">
                        <FlameIcon className="w-5 h-5 text-amber-500" />
                        <div>
                            <span className="text-[10px] text-gray-400 font-mono block">STREAK</span>
                            <span className="text-xs font-bold text-white font-mono">{state.streakDays} Days (1.5x)</span>
                        </div>
                    </div>

                    <div className="flex items-center space-x-2">
                        <span className="text-base">🪙</span>
                        <div>
                            <span className="text-[10px] text-gray-400 font-mono block">COINS</span>
                            <span className="text-xs font-bold text-amber-400 font-mono">{state.coins}</span>
                        </div>
                    </div>
                </div>

                {/* Right: Active Quest Callout & Hub Action */}
                <div className="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-end">
                    {activeQuest && (
                        <div className="hidden lg:block text-right">
                            <span className="text-[10px] text-gray-400 font-mono block">
                                {activeQuest.completed ? 'READY TO CLAIM' : 'DAILY BOUNTY'}
                            </span>
                            <span className="text-xs font-bold text-gray-200">
                                {activeQuest.title} ({activeQuest.current}/{activeQuest.target} {activeQuest.unit})
                            </span>
                        </div>
                    )}

                    <button
                        onClick={onOpenHub}
                        className="px-4 py-2.5 rounded-xl bg-orange-600/20 hover:bg-orange-600 text-orange-400 hover:text-white border border-orange-500/40 text-xs font-bold transition-all flex items-center space-x-2 whitespace-nowrap shadow-sm"
                    >
                        <TrophyIcon className="w-4 h-4" />
                        <span>Gamification Hub</span>
                    </button>
                </div>
            </div>
        </div>
    );
};
