import React, { useState, useEffect } from 'react';
import { gamificationService, getLevelTitle, INITIAL_TROPHIES } from '../../services/gamificationService';
import type { GamificationState, DailyQuest, RiderDuel, Trophy3DData } from './types';
import { Trophy3DViewer } from './Trophy3DViewer';
import { BADGE_SYSTEM, USERS } from '../../constants';
import { TrophyIcon, FlameIcon, RoadIcon, MountainIcon, SwordsIcon, CheckIcon, XIcon, UserPlusIcon } from '../icons';

interface GamificationHubProps {
    onClose: () => void;
    onStartGame?: () => void;
}

type TabType = 'quests' | 'trophies' | 'duels' | 'badges';

export const GamificationHub: React.FC<GamificationHubProps> = ({ onClose, onStartGame }) => {
    const [state, setState] = useState<GamificationState>(gamificationService.getState());
    const [activeTab, setActiveTab] = useState<TabType>('quests');
    const [selectedTrophy, setSelectedTrophy] = useState<Trophy3DData>(INITIAL_TROPHIES[0]);
    const [showNewDuelModal, setShowNewDuelModal] = useState(false);
    const [newDuelOpponent, setNewDuelOpponent] = useState('u4');
    const [newDuelType, setNewDuelType] = useState<'distance' | 'elevation' | 'rides'>('distance');
    const [newDuelTarget, setNewDuelTarget] = useState(50);
    const [levelUpInfo, setLevelUpInfo] = useState<{ level: number; title: string } | null>(null);
    const [claimFeedback, setClaimFeedback] = useState<string | null>(null);

    useEffect(() => {
        const unsubscribe = gamificationService.subscribe((updated) => {
            setState(updated);
        });
        return () => unsubscribe();
    }, []);

    const levelInfo = getLevelTitle(state.level);
    const xpPercent = Math.min(100, Math.round((state.currentXp / state.nextLevelXp) * 100));

    const handleClaimQuest = (questId: string) => {
        const quest = state.quests.find((q) => q.id === questId);
        if (quest) {
            const success = gamificationService.claimQuest(questId);
            if (success) {
                setClaimFeedback(`Claimed +${quest.xpReward} XP & +${quest.coinsReward} Coins!`);
                setTimeout(() => setClaimFeedback(null), 3000);

                const pendingLvl = gamificationService.getPendingLevelUp();
                if (pendingLvl) {
                    setLevelUpInfo(pendingLvl);
                }
            }
        }
    };

    const handleClaimDuel = (duelId: string) => {
        const duel = state.duels.find((d) => d.id === duelId);
        if (duel) {
            const success = gamificationService.claimDuelVictory(duelId);
            if (success) {
                setClaimFeedback(`Victory Claimed! +${duel.rewardXp} XP & +50 Coins!`);
                setTimeout(() => setClaimFeedback(null), 3000);

                const pendingLvl = gamificationService.getPendingLevelUp();
                if (pendingLvl) {
                    setLevelUpInfo(pendingLvl);
                }
            }
        }
    };

    const handleCreateDuel = () => {
        const title = `${newDuelType === 'distance' ? 'Highway Blitz' : newDuelType === 'elevation' ? 'Peak Climb' : 'Ride Count Challenge'}`;
        gamificationService.createDuel(newDuelOpponent, title, newDuelType, newDuelTarget);
        setShowNewDuelModal(false);
        setClaimFeedback(`Challenge sent to ${USERS[newDuelOpponent]?.name || 'Friend'}!`);
        setTimeout(() => setClaimFeedback(null), 3000);
    };

    return (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in font-sans">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden relative">
                {/* Header Strip with XP Progress & Quick Metrics */}
                <div className="p-6 bg-gradient-to-r from-slate-900 via-slate-850 to-orange-950/40 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6 relative">
                    <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 rounded-2xl bg-orange-600/20 border-2 border-orange-500/50 flex flex-col items-center justify-center text-orange-400 font-mono">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-400/80">LEVEL</span>
                            <span className="text-2xl font-black text-white leading-none">{state.level}</span>
                        </div>
                        <div>
                            <div className="flex items-center space-x-2">
                                <h2 className="text-xl font-black text-white tracking-tight">{levelInfo.title}</h2>
                                <span className="text-xs text-orange-400 font-mono font-semibold bg-orange-500/10 border border-orange-500/30 px-2 py-0.5 rounded">
                                    Top 5% Rider
                                </span>
                            </div>
                            {/* XP Progress Bar */}
                            <div className="mt-2 w-56 sm:w-72">
                                <div className="flex justify-between text-xs text-gray-400 font-mono mb-1">
                                    <span>{state.currentXp.toLocaleString()} XP</span>
                                    <span>{state.nextLevelXp.toLocaleString()} XP</span>
                                </div>
                                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                                    <div
                                        className="h-full bg-gradient-to-r from-orange-500 to-amber-400 transition-all duration-300"
                                        style={{ width: `${xpPercent}%` }}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Streak & Coins Badges */}
                    <div className="flex items-center space-x-3">
                        <div className="bg-slate-800/80 border border-slate-700/80 px-3.5 py-2 rounded-xl flex items-center space-x-2">
                            <FlameIcon className="w-5 h-5 text-amber-500 animate-pulse" />
                            <div>
                                <span className="text-[10px] text-gray-400 block font-mono">DAILY STREAK</span>
                                <span className="text-sm font-bold text-white font-mono">{state.streakDays} Days (1.5x)</span>
                            </div>
                        </div>

                        <div className="bg-slate-800/80 border border-slate-700/80 px-3.5 py-2 rounded-xl flex items-center space-x-2">
                            <span className="text-lg">🪙</span>
                            <div>
                                <span className="text-[10px] text-gray-400 block font-mono">COINS</span>
                                <span className="text-sm font-bold text-amber-400 font-mono">{state.coins}</span>
                            </div>
                        </div>

                        <button
                            onClick={onClose}
                            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-gray-400 hover:text-white transition-colors"
                            aria-label="Close Gamification Hub"
                        >
                            <XIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>

                {/* Toast Notification */}
                {claimFeedback && (
                    <div className="bg-emerald-600 text-white px-4 py-2 text-center text-sm font-bold animate-slide-up flex items-center justify-center space-x-2 shadow-md">
                        <CheckIcon className="w-4 h-4 text-white" />
                        <span>{claimFeedback}</span>
                    </div>
                )}

                {/* Tab Navigation (Segmented Buttons) */}
                <div className="flex border-b border-slate-800 bg-slate-900/60 p-2 gap-2 overflow-x-auto scrollbar-hide">
                    {[
                        { id: 'quests', label: 'Daily Bounties', icon: '🎯' },
                        { id: 'trophies', label: '3D Trophy Room', icon: '🏆' },
                        { id: 'duels', label: 'Rider Duels', icon: '⚔️' },
                        { id: 'badges', label: 'Adventure Passport', icon: '🎖️' },
                    ].map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as TabType)}
                            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-2 whitespace-nowrap ${
                                activeTab === tab.id
                                    ? 'bg-orange-600 text-white shadow-lg shadow-orange-950/40'
                                    : 'text-gray-400 hover:text-gray-200 hover:bg-slate-800/60'
                            }`}
                        >
                            <span>{tab.icon}</span>
                            <span>{tab.label}</span>
                        </button>
                    ))}
                </div>

                {/* Tab Content Body */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {/* TAB 1: DAILY BOUNTIES & QUESTS */}
                    {activeTab === 'quests' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h3 className="text-lg font-bold text-white">Daily Adventure Bounties</h3>
                                    <p className="text-xs text-gray-400 mt-0.5">
                                        Reset every 24 hours. Complete to earn XP and level up your rider status!
                                    </p>
                                </div>
                                <span className="text-xs font-mono text-orange-400 bg-orange-500/10 border border-orange-500/20 px-2.5 py-1 rounded-lg">
                                    Resets in 6h 18m
                                </span>
                            </div>

                            {/* Quest Cards Grid */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {state.quests.map((q) => {
                                    const progress = Math.min(100, Math.round((q.current / q.target) * 100));
                                    return (
                                        <div
                                            key={q.id}
                                            className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                                                q.claimed
                                                    ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                                                    : q.completed
                                                    ? 'bg-slate-850 border-orange-500/50 shadow-lg shadow-orange-950/20'
                                                    : 'bg-slate-850/70 border-slate-800'
                                            }`}
                                        >
                                            <div>
                                                <div className="flex items-center justify-between mb-3">
                                                    <span className="text-2xl">{q.icon}</span>
                                                    <div className="flex items-center space-x-1.5 text-xs font-mono font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded">
                                                        <span>+{q.xpReward} XP</span>
                                                        <span>·</span>
                                                        <span>+{q.coinsReward} 🪙</span>
                                                    </div>
                                                </div>
                                                <h4 className="font-bold text-white text-base">{q.title}</h4>
                                                <p className="text-xs text-gray-400 mt-1 leading-relaxed">{q.description}</p>
                                            </div>

                                            <div className="mt-5 space-y-3">
                                                <div>
                                                    <div className="flex justify-between text-xs font-mono text-gray-400 mb-1">
                                                        <span>Progress</span>
                                                        <span className="text-white font-bold">
                                                            {q.current} / {q.target} {q.unit}
                                                        </span>
                                                    </div>
                                                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                                        <div
                                                            className={`h-full transition-all duration-300 ${
                                                                q.completed ? 'bg-emerald-500' : 'bg-orange-500'
                                                            }`}
                                                            style={{ width: `${progress}%` }}
                                                        />
                                                    </div>
                                                </div>

                                                {q.claimed ? (
                                                    <div className="w-full py-2 rounded-xl bg-slate-800/80 text-gray-500 font-bold text-xs text-center">
                                                        Claimed ✓
                                                    </div>
                                                ) : q.completed ? (
                                                    <button
                                                        onClick={() => handleClaimQuest(q.id)}
                                                        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg transition-all"
                                                    >
                                                        Claim Reward
                                                    </button>
                                                ) : (
                                                    <div className="w-full py-2 rounded-xl bg-slate-800 text-gray-400 font-medium text-xs text-center font-mono">
                                                        In Progress ({progress}%)
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            {/* 7-Day Streak Roadmap */}
                            <div className="p-5 rounded-2xl bg-slate-850/80 border border-slate-800">
                                <h4 className="font-bold text-white text-sm mb-3 flex items-center space-x-2">
                                    <FlameIcon className="w-4 h-4 text-orange-500" />
                                    <span>7-Day Adventure Streak Roadmap</span>
                                </h4>
                                <div className="grid grid-cols-7 gap-2">
                                    {[1, 2, 3, 4, 5, 6, 7].map((day) => {
                                        const isPast = day <= state.streakDays;
                                        const isToday = day === state.streakDays;
                                        return (
                                            <div
                                                key={day}
                                                className={`p-3 rounded-xl border text-center flex flex-col items-center justify-center ${
                                                    isToday
                                                        ? 'bg-orange-600/20 border-orange-500 text-white font-bold'
                                                        : isPast
                                                        ? 'bg-slate-800 border-slate-700 text-gray-300'
                                                        : 'bg-slate-900/50 border-slate-800 text-gray-600'
                                                }`}
                                            >
                                                <span className="text-[10px] font-mono uppercase block text-gray-400">Day {day}</span>
                                                <span className="text-sm mt-1">{isPast ? '🔥' : '🔒'}</span>
                                                <span className="text-[10px] font-mono mt-1 text-amber-400 font-bold">
                                                    +{day * 50} XP
                                                </span>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* TAB 2: 3D TROPHY ROOM (Three.js Showcase) */}
                    {activeTab === 'trophies' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h3 className="text-lg font-bold text-white">Interactive 3D Trophy Showcase</h3>
                                    <p className="text-xs text-gray-400 mt-0.5">
                                        Drag to rotate and inspect your unlocked physical 3D trophies in studio PBR lighting.
                                    </p>
                                </div>
                                <span className="text-xs font-mono text-gray-400">
                                    Unlocked: {INITIAL_TROPHIES.filter((t) => t.unlocked).length} / {INITIAL_TROPHIES.length}
                                </span>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                                {/* Left 3D Viewport (7 Cols) */}
                                <div className="md:col-span-7">
                                    <Trophy3DViewer trophy={selectedTrophy} />
                                </div>

                                {/* Right Trophy Selector & Lore (5 Cols) */}
                                <div className="md:col-span-5 space-y-3">
                                    <div className="p-4 rounded-2xl bg-slate-850 border border-slate-800 space-y-2">
                                        <div className="flex items-center justify-between">
                                            <span className="text-xs uppercase font-mono font-bold text-orange-400">
                                                {selectedTrophy.tier.toUpperCase()} TIER
                                            </span>
                                            <span className="text-xs text-gray-500 font-mono">{selectedTrophy.category}</span>
                                        </div>
                                        <h4 className="text-xl font-bold text-white">{selectedTrophy.name}</h4>
                                        <p className="text-xs text-gray-300 leading-relaxed">{selectedTrophy.description}</p>
                                        {selectedTrophy.unlocked && (
                                            <div className="text-[11px] font-mono text-emerald-400 pt-2 border-t border-slate-800">
                                                Unlocked: {selectedTrophy.unlockedAt}
                                            </div>
                                        )}
                                    </div>

                                    {/* Thumbnail list to switch trophies */}
                                    <div className="space-y-2">
                                        <span className="text-xs text-gray-400 font-mono uppercase block">Select Trophy:</span>
                                        {INITIAL_TROPHIES.map((t) => (
                                            <button
                                                key={t.id}
                                                onClick={() => setSelectedTrophy(t)}
                                                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                                                    selectedTrophy.id === t.id
                                                        ? 'bg-orange-600/20 border-orange-500 text-white'
                                                        : 'bg-slate-850/60 border-slate-800 text-gray-400 hover:text-white hover:bg-slate-800'
                                                }`}
                                            >
                                                <div className="flex items-center space-x-3">
                                                    <span className="text-xl">{t.unlocked ? '🏆' : '🔒'}</span>
                                                    <div>
                                                        <span className="text-xs font-bold block text-white">{t.name}</span>
                                                        <span className="text-[10px] text-gray-400 font-mono">{t.tier.toUpperCase()} · {t.category}</span>
                                                    </div>
                                                </div>
                                                <span className="text-xs font-mono">{selectedTrophy.id === t.id ? '▶' : ''}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* TAB 3: RIDER DUELS (Head to Head) */}
                    {activeTab === 'duels' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h3 className="text-lg font-bold text-white">Active Rider Duels</h3>
                                    <p className="text-xs text-gray-400 mt-0.5">
                                        Compete head-to-head against friends. Winner takes bonus XP and bragging rights!
                                    </p>
                                </div>
                                <button
                                    onClick={() => setShowNewDuelModal(true)}
                                    className="px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center space-x-2 transition-all shadow-lg"
                                >
                                    <SwordsIcon className="w-4 h-4 text-white" />
                                    <span>New Duel</span>
                                </button>
                            </div>

                            {/* Duel Cards */}
                            <div className="space-y-4">
                                {state.duels.map((d) => {
                                    const userPct = Math.min(100, Math.round((d.userScore / d.target) * 100));
                                    const oppPct = Math.min(100, Math.round((d.opponentScore / d.target) * 100));
                                    return (
                                        <div key={d.id} className="p-5 rounded-2xl bg-slate-850 border border-slate-800 space-y-4">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <span className="text-xs uppercase font-mono font-bold text-orange-400">
                                                        {d.type.toUpperCase()} DUEL · +{d.rewardXp} XP REWARD
                                                    </span>
                                                    <h4 className="text-base font-bold text-white mt-0.5">{d.title}</h4>
                                                </div>
                                                <span className={`text-xs font-mono px-2.5 py-1 rounded-lg ${
                                                    d.status === 'won' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-gray-400'
                                                }`}>
                                                    {d.status === 'won' ? 'VICTORY!' : `Time Left: ${d.timeLeft}`}
                                                </span>
                                            </div>

                                            {/* Head-to-Head Comparison Bars */}
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                                                {/* Player */}
                                                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                                                    <div className="flex justify-between text-xs font-mono mb-1">
                                                        <span className="font-bold text-orange-400">You</span>
                                                        <span className="text-white font-bold">{d.userScore} / {d.target} {d.unit}</span>
                                                    </div>
                                                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                                        <div className="h-full bg-orange-500" style={{ width: `${userPct}%` }} />
                                                    </div>
                                                </div>

                                                {/* Opponent */}
                                                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                                                    <div className="flex justify-between text-xs font-mono mb-1">
                                                        <span className="font-bold text-gray-300">{d.opponent.name}</span>
                                                        <span className="text-gray-400 font-bold">{d.opponentScore} / {d.target} {d.unit}</span>
                                                    </div>
                                                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                                        <div className="h-full bg-blue-500" style={{ width: `${oppPct}%` }} />
                                                    </div>
                                                </div>
                                            </div>

                                            {d.status === 'won' && (
                                                <button
                                                    onClick={() => handleClaimDuel(d.id)}
                                                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg"
                                                >
                                                    Claim Duel Bounty (+{d.rewardXp} XP)
                                                </button>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}

                    {/* TAB 4: ADVENTURE PASSPORT (Badges Catalogue) */}
                    {activeTab === 'badges' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h3 className="text-lg font-bold text-white">Adventure Passport & Badges</h3>
                                    <p className="text-xs text-gray-400 mt-0.5">
                                        Log real rides or 3D runs to unlock higher tier badges from Bronze to Platinum.
                                    </p>
                                </div>
                                <span className="text-xs font-mono text-amber-400">
                                    {state.unlockedBadgeIds.length} / {BADGE_SYSTEM.length} Unlocked
                                </span>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                                {BADGE_SYSTEM.slice(0, 16).map((b) => {
                                    const isUnlocked = state.unlockedBadgeIds.includes(b.id);
                                    const tierColor =
                                        b.tier === 'Platinum'
                                            ? 'text-cyan-400 border-cyan-500/30'
                                            : b.tier === 'Gold'
                                            ? 'text-amber-400 border-amber-500/30'
                                            : b.tier === 'Silver'
                                            ? 'text-slate-300 border-slate-400/30'
                                            : 'text-amber-700 border-amber-700/30';
                                    return (
                                        <div
                                            key={b.id}
                                            className={`p-4 rounded-2xl border text-center flex flex-col items-center justify-between transition-all ${
                                                isUnlocked
                                                    ? 'bg-slate-850 border-slate-700/80'
                                                    : 'bg-slate-900/40 border-slate-800 opacity-50'
                                            }`}
                                        >
                                            <div className="my-2">
                                                <b.icon className={`w-10 h-10 mx-auto ${isUnlocked ? tierColor.split(' ')[0] : 'text-gray-600'}`} />
                                            </div>
                                            <div>
                                                <h5 className="font-bold text-xs text-white leading-tight">{b.name}</h5>
                                                <span className={`text-[10px] font-mono font-bold block mt-0.5 ${tierColor.split(' ')[0]}`}>
                                                    {b.tier}
                                                </span>
                                                <p className="text-[11px] text-gray-400 mt-1 line-clamp-2">{b.description}</p>
                                            </div>
                                            <div className="mt-3 text-[10px] font-mono">
                                                {isUnlocked ? (
                                                    <span className="text-emerald-400">UNLOCKED ✓</span>
                                                ) : (
                                                    <span className="text-gray-500">LOCKED 🔒</span>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* NEW DUEL MODAL */}
            {showNewDuelModal && (
                <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-sm w-full space-y-4">
                        <div className="flex justify-between items-center">
                            <h3 className="font-bold text-white text-lg">Challenge a Friend</h3>
                            <button onClick={() => setShowNewDuelModal(false)} className="text-gray-400 hover:text-white">
                                <XIcon className="w-5 h-5" />
                            </button>
                        </div>

                        <div>
                            <label className="text-xs font-mono text-gray-400 block mb-1">Select Opponent</label>
                            <select
                                value={newDuelOpponent}
                                onChange={(e) => setNewDuelOpponent(e.target.value)}
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                            >
                                <option value="u4">Vance Velocity</option>
                                <option value="u2">Mia Torque</option>
                                <option value="u3">Clutch Cargo</option>
                                <option value="u5">Harley Quinn</option>
                            </select>
                        </div>

                        <div>
                            <label className="text-xs font-mono text-gray-400 block mb-1">Competition Goal</label>
                            <div className="grid grid-cols-3 gap-2">
                                {[
                                    { id: 'distance', label: 'Distance' },
                                    { id: 'elevation', label: 'Elevation' },
                                    { id: 'rides', label: 'Rides' },
                                ].map((t) => (
                                    <button
                                        key={t.id}
                                        type="button"
                                        onClick={() => setNewDuelType(t.id as any)}
                                        className={`py-2 rounded-lg text-xs font-bold border ${
                                            newDuelType === t.id
                                                ? 'bg-orange-600 border-orange-500 text-white'
                                                : 'bg-slate-800 border-slate-700 text-gray-300'
                                        }`}
                                    >
                                        {t.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="text-xs font-mono text-gray-400 block mb-1">
                                Target ({newDuelType === 'distance' ? 'km' : newDuelType === 'elevation' ? 'meters' : 'rides'})
                            </label>
                            <input
                                type="number"
                                value={newDuelTarget}
                                onChange={(e) => setNewDuelTarget(Number(e.target.value))}
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:border-orange-500"
                            />
                        </div>

                        <button
                            onClick={handleCreateDuel}
                            className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-sm shadow-lg shadow-orange-950/50"
                        >
                            Send Duel Challenge
                        </button>
                    </div>
                </div>
            )}

            {/* LEVEL UP MODAL */}
            {levelUpInfo && (
                <div className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4 animate-fade-in">
                    <div className="bg-gradient-to-b from-slate-900 to-orange-950/60 border-2 border-orange-500 rounded-3xl p-8 max-w-sm w-full text-center space-y-5 shadow-2xl">
                        <div className="w-20 h-20 mx-auto rounded-full bg-orange-600/30 border-2 border-orange-400 flex items-center justify-center text-3xl animate-bounce">
                            ⚡
                        </div>
                        <div>
                            <span className="text-xs uppercase font-mono tracking-widest text-amber-400 font-bold block mb-1">
                                ★ LEVEL UP ACHIEVED! ★
                            </span>
                            <h3 className="text-4xl font-black text-white">Level {levelUpInfo.level}</h3>
                            <p className="text-base font-bold text-orange-400 mt-1">{levelUpInfo.title}</p>
                        </div>
                        <p className="text-xs text-gray-300 leading-relaxed">
                            You've unlocked higher status across Adventurer leaderboards, bonus multiplier perks, and new title prestige!
                        </p>
                        <button
                            onClick={() => setLevelUpInfo(null)}
                            className="w-full py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-sm shadow-xl"
                        >
                            Continue Riding
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
