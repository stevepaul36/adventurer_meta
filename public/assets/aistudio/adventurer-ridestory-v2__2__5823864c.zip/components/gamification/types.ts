export interface DailyQuest {
    id: string;
    title: string;
    description: string;
    target: number;
    current: number;
    unit: string;
    xpReward: number;
    coinsReward: number;
    icon: string;
    completed: boolean;
    claimed: boolean;
    category: 'ride' | 'arcade' | 'social';
}

export interface RiderDuel {
    id: string;
    opponent: {
        id: string;
        name: string;
        avatarUrl: string;
    };
    title: string;
    type: 'distance' | 'elevation' | 'rides';
    userScore: number;
    opponentScore: number;
    target: number;
    unit: string;
    timeLeft: string;
    status: 'active' | 'won' | 'lost';
    rewardXp: number;
}

export interface Trophy3DData {
    id: string;
    name: string;
    tier: 'gold' | 'silver' | 'bronze' | 'diamond';
    category: string;
    unlocked: boolean;
    unlockedAt?: string;
    description: string;
    modelType: 'cup' | 'piston' | 'mountain' | 'helmet';
    primaryColor: number;
    metalness: number;
    roughness: number;
}

export interface GamificationState {
    level: number;
    currentXp: number;
    nextLevelXp: number;
    coins: number;
    streakDays: number;
    lastActiveDate: string;
    quests: DailyQuest[];
    duels: RiderDuel[];
    unlockedTrophyIds: string[];
    unlockedBadgeIds: string[];
}
