import React, { useState } from 'react';
import { LEADERBOARD_DISTANCE, LEADERBOARD_ELEVATION, LEADERBOARD_RIDES, CURRENT_USER, COMMUNITY_CHALLENGES } from '../constants';
import type { LeaderboardEntry, CommunityChallenge } from '../types';
import { TrophyIcon, RoadIcon, MountainIcon, UsersIcon } from './icons';

interface LeaderboardsPanelProps {
    onUserSelect: (userId: string) => void;
}

type LeaderboardCategory = 'distance' | 'elevation' | 'rides' | 'challenges';

const LeaderboardList: React.FC<{ entries: LeaderboardEntry[]; unit: string; onUserSelect: (userId: string) => void; }> = ({ entries, unit, onUserSelect }) => (
    <div className="space-y-2 animate-fade-in">
        {entries.map(entry => (
            <div 
                key={entry.user.id} 
                className={`flex items-center p-3 rounded-lg ${entry.user.id === CURRENT_USER.id ? 'bg-orange-900/50 border border-orange-700' : 'bg-slate-800'}`}
            >
                <div className="w-8 text-center text-lg font-bold text-gray-400">{entry.rank}</div>
                <button onClick={() => onUserSelect(entry.user.id)} className="flex items-center text-left group flex-1 mx-3">
                    <img src={entry.user.avatarUrl} alt={entry.user.name} className="w-12 h-12 rounded-full mr-4 group-hover:ring-2 group-hover:ring-orange-500 transition-ring" />
                    <div>
                        <p className="font-bold text-white group-hover:text-orange-400 transition-colors">{entry.user.name}</p>
                        {entry.user.id === CURRENT_USER.id && <p className="text-xs text-orange-400">You</p>}
                    </div>
                </button>
                <div className="text-right">
                    <p className="text-lg font-bold text-white">{entry.value.toLocaleString()}</p>
                    <p className="text-sm text-gray-500">{unit}</p>
                </div>
            </div>
        ))}
    </div>
);

const ChallengeCard: React.FC<{ challenge: CommunityChallenge }> = ({ challenge }) => {
    const progress = Math.min((challenge.userProgress / challenge.goal) * 100, 100);
    const unit = challenge.type === 'rides' ? '' : challenge.type === 'distance' ? ' km' : ' m';

    return (
        <div className="bg-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-start space-x-3">
                <div className="bg-slate-900 p-3 rounded-lg">
                    <challenge.icon className="w-8 h-8 text-orange-400" />
                </div>
                <div className="flex-1">
                    <h4 className="font-bold text-white">{challenge.title}</h4>
                    <p className="text-xs text-gray-400">{challenge.timeframe} Challenge &middot; {challenge.participants.toLocaleString()} participants</p>
                </div>
            </div>
            <p className="text-sm text-gray-300">{challenge.description}</p>
            <div>
                <div className="flex justify-between items-baseline mb-1">
                    <span className="text-sm font-semibold text-white">Your Progress</span>
                    <span className="text-xs font-semibold text-gray-400">
                        {challenge.userProgress.toLocaleString()}{unit} / {challenge.goal.toLocaleString()}{unit}
                    </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2.5">
                    <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
            </div>
        </div>
    );
};


const LeaderboardsPanel: React.FC<LeaderboardsPanelProps> = ({ onUserSelect }) => {
    const [activeCategory, setActiveCategory] = useState<LeaderboardCategory>('distance');

    const categories = [
        { id: 'distance', label: 'Distance', icon: RoadIcon, data: LEADERBOARD_DISTANCE, unit: 'km' },
        { id: 'elevation', label: 'Elevation', icon: MountainIcon, data: LEADERBOARD_ELEVATION, unit: 'm' },
        { id: 'rides', label: 'Rides', icon: TrophyIcon, data: LEADERBOARD_RIDES, unit: 'rides' },
        { id: 'challenges', label: 'Challenges', icon: UsersIcon, data: COMMUNITY_CHALLENGES, unit: '' },
    ];

    const activeData = categories.find(c => c.id === activeCategory);

    const TabButton: React.FC<{ category: typeof categories[0] }> = ({ category }) => (
        <button
            onClick={() => setActiveCategory(category.id as LeaderboardCategory)}
            className={`flex-1 flex items-center justify-center space-x-2 py-3 text-sm font-semibold transition-colors ${
                activeCategory === category.id 
                ? 'text-orange-500 border-b-2 border-orange-500' 
                : 'text-gray-400 hover:text-white border-b-2 border-transparent'
            }`}
        >
            <category.icon className="w-5 h-5" />
            <span>{category.label}</span>
        </button>
    );

    return (
        <div className="bg-slate-900 rounded-lg overflow-hidden mb-20 md:mb-0">
            <div className="p-4 border-b border-slate-800">
                <h2 className="text-2xl font-bold text-white">Leaderboards & Challenges</h2>
                <p className="text-gray-400 text-sm">See how you stack up and join community challenges.</p>
            </div>
            
            <div className="flex border-b border-slate-800">
                {categories.map(cat => <TabButton key={cat.id} category={cat} />)}
            </div>

            <div className="p-4">
                {activeData && activeCategory !== 'challenges' && (
                    <LeaderboardList entries={activeData.data as LeaderboardEntry[]} unit={activeData.unit} onUserSelect={onUserSelect} />
                )}
                {activeData && activeCategory === 'challenges' && (
                     <div className="space-y-4 animate-fade-in">
                        {(activeData.data as CommunityChallenge[]).map(challenge => (
                            <ChallengeCard key={challenge.id} challenge={challenge} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default LeaderboardsPanel;