import React, { useState } from 'react';
import { generateRoute } from '../services/aiService';
import type { AI_Route, ActivityType } from '../types';
import { BackIcon, MapPinIcon, ClockIcon, RouteIcon, SparklesIcon } from './icons';

interface JourneyPlannerProps {
  onBack: () => void;
  activityMode: ActivityType;
}

const RouteCard: React.FC<{ route: AI_Route }> = ({ route }) => (
    <div className="bg-slate-900 rounded-lg overflow-hidden shadow-lg animate-fade-in w-full">
        <div className="p-6">
            <h3 className="text-3xl font-bold text-white mb-2">{route.title}</h3>
            <p className="text-gray-400 mb-6">{route.description}</p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center space-x-3">
                    <MapPinIcon className="w-8 h-8 text-orange-400"/>
                    <div>
                        <p className="text-sm text-gray-400">Distance</p>
                        <p className="text-xl font-bold text-white">{route.distance}</p>
                    </div>
                </div>
                <div className="flex items-center space-x-3">
                    <ClockIcon className="w-8 h-8 text-orange-400"/>
                    <div>
                        <p className="text-sm text-gray-400">Duration</p>
                        <p className="text-xl font-bold text-white">{route.duration}</p>
                    </div>
                </div>
            </div>

            <div>
                <h4 className="text-xl font-bold text-white mb-3 flex items-center">
                    <RouteIcon className="w-6 h-6 mr-2 text-orange-400"/>
                    Waypoints
                </h4>
                <ul className="space-y-3">
                    {route.waypoints.map((waypoint, index) => (
                        <li key={index} className="flex items-start">
                            <span className="bg-orange-500 text-slate-900 rounded-full w-6 h-6 text-sm font-bold flex items-center justify-center mr-3 mt-1 flex-shrink-0">{index + 1}</span>
                            <span className="text-gray-300">{waypoint}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
        <div className="p-4 bg-slate-800/50">
             <button
                onClick={() => alert('This journey has been logged to your profile!')}
                className="w-full bg-orange-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-orange-700 transition-colors"
             >
                Log this Journey
            </button>
        </div>
    </div>
);


const JourneyPlanner: React.FC<JourneyPlannerProps> = ({ onBack, activityMode }) => {
    const [prompt, setPrompt] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [route, setRoute] = useState<AI_Route | null>(null);
    const [difficulty, setDifficulty] = useState<'Easy' | 'Moderate' | 'Hard'>('Moderate');

    const placeholders: Record<string, string> = {
        Motorcycling: "e.g., A scenic 3-hour loop through the mountains near Denver with twisty roads and a stop for coffee.",
        Cycling: "e.g., A 50km coastal ride with minimal hills, suitable for a road bike.",
        Walking: "e.g., A gentle 1-hour walk through a city park with historical landmarks.",
        'Trekking/Hiking': "e.g., A challenging 5-hour hike to a summit with great views.",
        'Car Trips': "e.g., A full-day scenic drive along the coast with multiple photo stops.",
        'Hybrid': "e.g., A trip involving a 1-hour drive to a national park, followed by a 3-hour hike.",
    };

    const placeholder = placeholders[activityMode] || placeholders.Motorcycling;

    type Difficulty = 'Easy' | 'Moderate' | 'Hard';
    const difficulties: Difficulty[] = ['Easy', 'Moderate', 'Hard'];
    
    const handleGenerateRoute = async () => {
        if (!prompt.trim()) {
          setError("Please describe the journey you want to plan.");
          return;
        }
        setIsLoading(true);
        setError(null);
        setRoute(null);
        try {
          const generatedRoute = await generateRoute(prompt, activityMode, difficulty);
          setRoute(generatedRoute);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
          setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col">
            <header className="flex items-center p-4 border-b border-slate-800 flex-shrink-0">
                <button onClick={onBack} className="text-white p-2 rounded-full hover:bg-slate-800 transition-colors">
                    <BackIcon className="w-6 h-6"/>
                </button>
                <h2 className="text-xl font-bold text-white ml-4">AI Journey Planner</h2>
            </header>
            
            <div className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center">
                {!route && (
                    <div className="w-full max-w-2xl space-y-4 animate-fade-in">
                        <h3 className="text-2xl font-bold text-center text-white">Describe Your Perfect <span className="text-orange-400">{activityMode}</span> Trip</h3>
                        <p className="text-center text-gray-400">Tell the AI what you're looking for. Be as specific as you like!</p> 
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder={placeholder}
                            className="w-full h-40 bg-slate-900 border border-slate-700 rounded-lg p-4 focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                            disabled={isLoading}
                        />
                        <div className="flex justify-center space-x-2 bg-slate-900 p-2 rounded-full border border-slate-700">
                            {difficulties.map(d => (
                                <button
                                    key={d}
                                    onClick={() => setDifficulty(d)}
                                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors w-full ${
                                        difficulty === d
                                            ? 'bg-orange-600 text-white'
                                            : 'bg-transparent text-gray-300 hover:bg-slate-800'
                                    }`}
                                >
                                    {d}
                                </button>
                            ))}
                        </div>
                        <button
                            onClick={handleGenerateRoute}
                            disabled={isLoading}
                            className="w-full bg-orange-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2 disabled:bg-slate-700"
                        >
                            <SparklesIcon className="w-5 h-5"/>
                            <span>{isLoading ? 'Generating...' : 'Generate Route'}</span>
                        </button>
                    </div>
                )}
                
                {isLoading && (
                    <div className="text-center p-8">
                        <p className="text-lg text-orange-400">Crafting your journey...</p>
                        <p className="text-gray-400">This can take a moment.</p>
                    </div>
                )}

                {error && (
                    <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg w-full max-w-2xl text-center">
                        <p className="font-bold">Oops! Something went wrong.</p>
                        <p>{error}</p>
                    </div>
                )}

                {route && (
                    <div className="w-full max-w-2xl">
                         <RouteCard route={route} />
                         <button
                            onClick={() => { setRoute(null); setPrompt('') }}
                            className="mt-4 w-full text-gray-400 hover:text-white transition-colors py-2"
                         >
                            Plan another journey
                         </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default JourneyPlanner;