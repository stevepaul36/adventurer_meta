import React, { useState, useMemo } from 'react';
import PostCard from './PostCard';
import RideShareCard from './RideShareCard';
import RideStoryCard from './RideStoryCard';
import type { RideStory, FeedItem } from '../types';

type FilterType = 'all' | 'posts' | 'rides' | 'stories';

interface RideFeedProps {
    onUserSelect: (userId: string) => void;
    onShowRideStory: (story: RideStory) => void;
    feedItems: FeedItem[];
}

const RideFeed: React.FC<RideFeedProps> = ({ onUserSelect, onShowRideStory, feedItems }) => {
    const [activeFilter, setActiveFilter] = useState<FilterType>('all');

    const filteredItems = useMemo(() => {
        if (activeFilter === 'posts') {
            return feedItems.filter(item => item.type === 'post');
        }
        if (activeFilter === 'rides') {
            return feedItems.filter(item => item.type === 'ride_share');
        }
        if (activeFilter === 'stories') {
            return feedItems.filter(item => item.type === 'ride_story');
        }
        return feedItems;
    }, [activeFilter, feedItems]);

    const FilterButton: React.FC<{ filter: FilterType; label: string }> = ({ filter, label }) => (
        <button
            onClick={() => setActiveFilter(filter)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeFilter === filter
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-800 text-gray-300 hover:bg-slate-700'
            }`}
        >
            {label}
        </button>
    );

    return (
        <div>
            <div className="bg-slate-900/80 backdrop-blur-sm rounded-lg p-3 sticky top-16 z-20 border-b border-slate-800 mb-6">
                <div className="flex items-center space-x-2">
                    <h3 className="text-xl font-bold text-white mr-auto">Ride Feed</h3>
                    <FilterButton filter="all" label="All" />
                    <FilterButton filter="posts" label="Posts" />
                    <FilterButton filter="rides" label="Rides" />
                    <FilterButton filter="stories" label="Stories" />
                </div>
            </div>

            <div className="space-y-6">
                {filteredItems.length > 0 ? filteredItems.map(item => {
                    switch (item.type) {
                        case 'post':
                            return <PostCard key={item.data.id} post={item.data} onUserSelect={onUserSelect} />;
                        case 'ride_share':
                            return <RideShareCard key={item.data.id} rideShare={item.data} onUserSelect={onUserSelect} />;
                        case 'ride_story':
                            return <RideStoryCard key={item.data.id} story={item.data} onUserSelect={onUserSelect} onShowRideStory={onShowRideStory} />;
                        default:
                            return null;
                    }
                }) : (
                    <div className="text-center py-12 bg-slate-900/50 rounded-lg">
                        <p className="font-semibold text-gray-400">Your feed is quiet.</p>
                        <p className="text-sm text-gray-500 mt-1">Posts from you and your friends will appear here. Try adding some friends to see more content!</p>
                    </div>
                 )}
            </div>
        </div>
    );
};

export default RideFeed;