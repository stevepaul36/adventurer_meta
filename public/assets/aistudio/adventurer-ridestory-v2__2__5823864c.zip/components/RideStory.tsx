import React, { useState, useRef, useEffect } from 'react';
import type { RideStory, StoryPost } from '../types';
import { BackIcon, RouteIcon } from './icons';

const StoryPostItem: React.FC<{ post: StoryPost; isVisible: boolean }> = ({ post, isVisible }) => {
    // FIX: Check if post is a RideShare to correctly access `title` or `caption` properties, avoiding type errors.
    const isRideShare = 'mapImageUrl' in post;
    const imageUrl = isRideShare ? post.mapImageUrl : post.imageUrl;
    const textContent = isRideShare ? post.title : post.caption;

    return (
        <div className={`p-4 rounded-lg transition-all duration-300 ${isVisible ? 'bg-slate-800/80 scale-[1.01]' : 'bg-slate-800/40'}`}>
            {imageUrl && <img src={imageUrl} alt={textContent || 'Ride Story Image'} className="w-full h-48 object-cover rounded-lg mb-3" />}
            <p className="text-sm text-gray-300">{textContent}</p>
            <p className="text-xs text-gray-500 mt-2">{post.timestamp}</p>
        </div>
    );
};

const InteractiveMap: React.FC<{ story: RideStory; activePostId: string | null; onMarkerClick: (postId: string) => void; }> = ({ story, activePostId, onMarkerClick }) => {
    return (
        <div className="w-full h-full bg-slate-800 rounded-lg overflow-hidden relative">
            <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="none">
                {/* Placeholder for a map background image */}
                <image href="https://picsum.photos/seed/mapbg/800/800" width="100" height="100" />
                
                {/* Route Path */}
                <path d={story.routePath} fill="none" stroke="rgba(249, 115, 22, 0.6)" strokeWidth="1.5" strokeDasharray="2 1" />

                {/* Markers for each post */}
                {story.storyPosts.map(post => (
                    <g key={post.id} onClick={() => onMarkerClick(post.id)} className="cursor-pointer group">
                        <circle
                            cx={post.mapPosition.x}
                            cy={post.mapPosition.y}
                            r={activePostId === post.id ? 3 : 2}
                            fill="white"
                            stroke="rgba(234, 88, 12, 1)"
                            strokeWidth="0.5"
                            className="transition-all duration-300"
                        />
                         <circle
                            cx={post.mapPosition.x}
                            cy={post.mapPosition.y}
                            r="4"
                            fill="transparent"
                            className={`transition-opacity duration-300 ${activePostId === post.id ? 'opacity-30 animate-pulse fill-orange-500' : 'opacity-0'}`}
                        />
                    </g>
                ))}
            </svg>
        </div>
    );
};

interface RideStoryProps {
    story: RideStory;
    onBack: () => void;
}

const RideStory: React.FC<RideStoryProps> = ({ story, onBack }) => {
    const [activePostId, setActivePostId] = useState<string | null>(story.storyPosts[0]?.id || null);
    const postRefs = useRef<(HTMLDivElement | null)[]>([]);

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        setActivePostId(entry.target.id);
                    }
                });
            },
            { rootMargin: '-50% 0px -50% 0px', threshold: 0 }
        );

        postRefs.current.forEach(ref => {
            if (ref) observer.observe(ref);
        });

        return () => {
            postRefs.current.forEach(ref => {
                if (ref) observer.unobserve(ref);
            });
        };
    }, [story.storyPosts]);

    const handleMarkerClick = (postId: string) => {
        const postElement = document.getElementById(postId);
        postElement?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    };

    return (
        <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col md:flex-row animate-fade-in">
            <button onClick={onBack} className="absolute top-4 left-4 bg-black/50 hover:bg-black/75 text-white p-2 rounded-full transition-colors z-20">
                <BackIcon className="w-6 h-6" />
            </button>

            {/* Left Panel: Map */}
            <div className="w-full md:w-3/5 h-1/3 md:h-full p-4">
                <InteractiveMap story={story} activePostId={activePostId} onMarkerClick={handleMarkerClick} />
            </div>

            {/* Right Panel: Story Feed */}
            <div className="w-full md:w-2/5 h-2/3 md:h-full bg-slate-900 flex flex-col">
                <div className="p-4 border-b border-slate-800">
                    <h2 className="text-2xl font-bold text-white">{story.title}</h2>
                    <p className="text-sm text-gray-400 mt-1">{story.description}</p>
                    <div className="flex items-center space-x-2 mt-3">
                        <img src={story.user.avatarUrl} alt={story.user.name} className="w-8 h-8 rounded-full" />
                        <span className="font-semibold text-gray-300">{story.user.name}</span>
                    </div>
                </div>
                <div className="flex-1 p-4 overflow-y-auto space-y-6 scroll-smooth">
                    {story.storyPosts.map((post, index) => (
                        <div
                            key={post.id}
                            id={post.id}
                            // FIX: Ensure ref callback returns void by wrapping assignment in a block.
                            ref={el => { postRefs.current[index] = el; }}
                        >
                            <StoryPostItem post={post} isVisible={activePostId === post.id} />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default RideStory;