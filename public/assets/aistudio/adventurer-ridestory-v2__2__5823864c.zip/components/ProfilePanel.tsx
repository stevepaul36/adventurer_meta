import React, { useState, useEffect, useMemo } from 'react';
import { PROFILES, USER_UNLOCKED_BADGES, BADGE_SYSTEM, CURRENT_USER, POSTS, RIDE_SHARES, USERS } from '../constants';
import type { Journey, SavedRide, Badge, BadgeTier, FeedItem, Post, RideShare, ActivityType, FriendRequest, User } from '../types';
import PostCard from './PostCard';
import RideShareCard from './RideShareCard';
import { BackIcon, MessageIcon, RoadIcon, UsersIcon, UserPlusIcon, TrophyIcon, SwordsIcon, XIcon, ClockIcon } from './icons';
import { gamificationService } from '../services/gamificationService';

const StatCard: React.FC<{ icon: React.ReactNode; value: string | number; label: string }> = ({ icon, value, label }) => (
    <div className="bg-slate-800/50 rounded-lg p-4 flex items-center space-x-4">
        <div className="bg-slate-700 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-2xl font-bold text-white">{value}</p>
            <p className="text-sm text-gray-400">{label}</p>
        </div>
    </div>
);

const TIER_COLORS: Record<BadgeTier, string> = {
    Bronze: 'text-yellow-600',
    Silver: 'text-gray-400',
    Gold: 'text-yellow-400',
    Platinum: 'text-cyan-400',
};

const BadgeCard: React.FC<{ badge: Badge }> = ({ badge }) => (
    <div className="bg-slate-800 rounded-lg p-4 flex flex-col items-center text-center group" title={badge.description}>
        <badge.icon className={`w-12 h-12 mb-2 ${TIER_COLORS[badge.tier]} transition-transform group-hover:scale-110`} />
        <p className="font-bold text-sm text-white">{badge.name}</p>
        <p className={`text-xs font-semibold ${TIER_COLORS[badge.tier]} opacity-80`}>{badge.tier}</p>
    </div>
);

const DuelModal: React.FC<{ opponent: User; onBack: () => void; isFriend: boolean }> = ({ opponent, onBack, isFriend }) => {
    type DuelType = 'distance' | 'elevation' | 'rides';
    type DuelDuration = '3 days' | '7 days';

    const [duelType, setDuelType] = useState<DuelType>('distance');
    const [duration, setDuration] = useState<DuelDuration>('3 days');
    const [note, setNote] = useState('');

    const duelOptions = {
        distance: { icon: RoadIcon, label: 'Distance' },
        elevation: { icon: TrophyIcon, label: 'Elevation' },
        rides: { icon: UsersIcon, label: 'Rides' },
    };

    const [sentStatus, setSentStatus] = useState<string | null>(null);

    const handleSendChallenge = () => {
        gamificationService.createDuel(
            opponent.id,
            `${duelType === 'distance' ? 'Highway Blitz' : duelType === 'elevation' ? 'Peak Climb' : 'Ride Count Challenge'} vs ${opponent.name}`,
            duelType,
            duelType === 'distance' ? 50 : duelType === 'elevation' ? 1200 : 5
        );
        setSentStatus(`Duel challenge successfully sent to ${opponent.name}!`);
        setTimeout(() => {
            onBack();
        }, 1200);
    };

    const OptionButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
        <button type="button" onClick={onClick} className={`w-full text-center px-4 py-3 rounded-lg border-2 transition-colors ${active ? 'bg-orange-600 border-orange-500 text-white' : 'bg-slate-800 border-slate-700 text-gray-300 hover:border-orange-600'}`}>
            {children}
        </button>
    );

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in" onClick={onBack}>
            <div className="bg-slate-900 rounded-lg p-6 m-4 max-w-md w-full shadow-lg border border-slate-800" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-white">Challenge {opponent.name}</h2>
                    <button type="button" onClick={onBack} className="p-1 rounded-full hover:bg-slate-700"><XIcon className="w-6 h-6 text-gray-400" /></button>
                </div>
                
                {!isFriend && (
                    <div className="mb-6 bg-slate-800/50 p-3 rounded-lg border border-slate-700">
                        <p className="text-sm text-gray-400 mb-2">You are challenging someone who is not your friend. This will also send them a friend request.</p>
                        <textarea
                            value={note}
                            onChange={(e) => setNote(e.target.value)}
                            placeholder="Add a friendly note... (optional)"
                            className="w-full h-20 bg-slate-800 border border-slate-600 rounded-md p-2 text-sm focus:outline-none focus:ring-1 focus:ring-orange-500 resize-none"
                        />
                    </div>
                )}
                
                <div className="mb-6">
                    <h3 className="font-semibold text-gray-300 mb-2">Competition Type</h3>
                    <div className="grid grid-cols-3 gap-2">
                        {Object.entries(duelOptions).map(([key, { icon: Icon, label }]) => (
                            <OptionButton key={key} active={duelType === key} onClick={() => setDuelType(key as DuelType)}>
                                <div className="flex flex-col items-center">
                                    <Icon className="w-6 h-6 mb-1" />
                                    <span className="text-sm font-medium">{label}</span>
                                </div>
                            </OptionButton>
                        ))}
                    </div>
                </div>

                <div className="mb-8">
                    <h3 className="font-semibold text-gray-300 mb-2">Duration</h3>
                    <div className="grid grid-cols-2 gap-2">
                        <OptionButton active={duration === '3 days'} onClick={() => setDuration('3 days')}>
                            <div className="flex items-center justify-center space-x-2"><ClockIcon className="w-5 h-5" /><span>3 Days</span></div>
                        </OptionButton>
                        <OptionButton active={duration === '7 days'} onClick={() => setDuration('7 days')}>
                             <div className="flex items-center justify-center space-x-2"><ClockIcon className="w-5 h-5" /><span>7 Days</span></div>
                        </OptionButton>
                    </div>
                </div>

                {sentStatus && (
                    <div className="p-3 bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 rounded-lg text-xs font-bold text-center mb-3">
                        {sentStatus}
                    </div>
                )}

                <button onClick={handleSendChallenge} className="w-full bg-orange-600 text-white font-bold py-3 px-6 rounded-full hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2">
                    <SwordsIcon className="w-5 h-5" />
                    <span>Send Challenge</span>
                </button>
            </div>
        </div>
    );
};


interface ProfilePanelProps {
    profileId?: string;
    onBack?: () => void;
    onUserSelect?: (userId: string) => void;
    friends: string[];
    friendRequests: FriendRequest[];
    sentRequests: string[];
    onAddFriend: (userId: string) => void;
    onAcceptRequest: (userId: string) => void;
}

const ProfilePanel: React.FC<ProfilePanelProps> = ({ profileId, onBack, onUserSelect = () => {}, friends, friendRequests, sentRequests, onAddFriend, onAcceptRequest }) => {
    const profile = PROFILES[profileId || CURRENT_USER.id];

    const [activityFilter, setActivityFilter] = useState<'all' | 'posts' | 'rides'>('all');
    const [activitySort, setActivitySort] = useState<'recent' | 'liked'>('recent');
    const [activeBadgeTab, setActiveBadgeTab] = useState<ActivityType>('Motorcycling');
    const [showDuelModal, setShowDuelModal] = useState(false);


    if (!profile) {
        return <div className="text-center p-8">User profile not found.</div>;
    }

    const isCurrentUser = profile.user.id === CURRENT_USER.id;
    const [savedRidesCount, setSavedRidesCount] = useState<number>(0);

    const friendshipStatus = useMemo(() => {
        if (friends.includes(profile.user.id)) return 'FRIENDS';
        if (friendRequests.some(req => req.from.id === profile.user.id)) return 'REQUEST_RECEIVED';
        if (sentRequests.includes(profile.user.id)) return 'REQUEST_SENT';
        return 'NONE';
    }, [friends, friendRequests, sentRequests, profile.user.id]);

    useEffect(() => {
        if (isCurrentUser) {
            try {
                const ridesJSON = localStorage.getItem('adventurer_rides');
                if (ridesJSON) {
                    const rides: SavedRide[] = JSON.parse(ridesJSON);
                    setSavedRidesCount(rides.length);
                }
            } catch (error) {
                console.error("Failed to load rides for stats:", error);
            }
        }
    }, [isCurrentUser]);

    const userActivity = useMemo(() => {
        const allUserActivity: FeedItem[] = [
            ...POSTS.filter(p => p.user.id === profile.user.id).map(p => ({ type: 'post' as const, data: p as Post })),
            ...RIDE_SHARES.filter(rs => rs.user.id === profile.user.id).map(rs => ({ type: 'ride_share' as const, data: rs as RideShare }))
        ];

        const filtered = allUserActivity.filter(item => {
            if (activityFilter === 'posts') return item.type === 'post';
            if (activityFilter === 'rides') return item.type === 'ride_share';
            return true;
        });

        filtered.sort((a, b) => {
            if (activitySort === 'liked') {
                const likesA = 'likes' in a.data ? a.data.likes : 0;
                const likesB = 'likes' in b.data ? b.data.likes : 0;
                return likesB - likesA;
            }
            return b.data.date.getTime() - a.data.date.getTime();
        });

        return filtered;
    }, [profile.user.id, activityFilter, activitySort]);

    const userUnlockedBadgeIds = new Set(USER_UNLOCKED_BADGES[profile.user.id] || []);
    const unlockedBadgesForTab = BADGE_SYSTEM.filter(badge => 
        badge.activityType === activeBadgeTab && userUnlockedBadgeIds.has(badge.id)
    );

    const badgeCategories: { type: ActivityType; label: string }[] = [
        { type: 'Motorcycling', label: 'Motorcycle' },
        { type: 'Cycling', label: 'Cycling' },
        { type: 'Walking', label: 'Walking' },
        { type: 'Trekking/Hiking', label: 'Hiking' },
        { type: 'Car Trips', label: 'Car' },
        { type: 'Hybrid', label: 'Hybrid' },
    ];
    
    const FilterButton: React.FC<{ filter: 'all' | 'posts' | 'rides'; label: string }> = ({ filter, label }) => (
        <button
            onClick={() => setActivityFilter(filter)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activityFilter === filter
                    ? 'bg-orange-600 text-white'
                    : 'bg-transparent text-gray-300 hover:bg-slate-700'
            }`}
        >
            {label}
        </button>
    );
    
    const renderFriendButton = () => {
        switch (friendshipStatus) {
            case 'FRIENDS':
                return <button className="font-bold py-2 px-6 rounded-full bg-slate-700 text-white w-40" disabled>Friends</button>;
            case 'REQUEST_RECEIVED':
                return <button onClick={() => onAcceptRequest(profile.user.id)} className="font-bold py-2 px-6 rounded-full bg-green-600 hover:bg-green-500 text-white w-40">Accept Request</button>;
            case 'REQUEST_SENT':
                 return <button className="font-bold py-2 px-6 rounded-full bg-slate-700 text-white w-40" disabled>Request Sent</button>;
            case 'NONE':
            default:
                return <button onClick={() => onAddFriend(profile.user.id)} className="font-bold py-2 px-6 rounded-full bg-orange-600 hover:bg-orange-500 text-white w-40">Add Friend</button>;
        }
    };

    const content = (
        <>
            <div className="bg-slate-900 rounded-lg overflow-hidden mb-20 md:mb-0">
                {onBack && (
                    <header className="absolute top-0 left-0 right-0 z-10 p-4 bg-gradient-to-b from-black/50 to-transparent">
                         <button onClick={onBack} className="text-white p-2 rounded-full bg-black/30 hover:bg-black/50 transition-colors">
                            <BackIcon className="w-6 h-6"/>
                        </button>
                    </header>
                )}
                <div className="h-48 bg-cover bg-center" style={{backgroundImage: `url(https://picsum.photos/seed/${profile.user.id}/1000/300)`}}></div>
                <div className="p-4">
                    <div className="flex items-end justify-between -mt-16">
                        <img src={profile.user.avatarUrl} alt={profile.user.name} className="w-32 h-32 rounded-full border-4 border-slate-900" />
                         <div className="flex items-center space-x-2">
                            {isCurrentUser ? (
                                <button className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-2 px-4 rounded-full transition-colors">Edit Profile</button>
                            ) : (
                                <>
                                    <button className="bg-slate-700 hover:bg-slate-600 p-3 rounded-full text-white transition-colors" title="Send a Message">
                                        <MessageIcon className="w-5 h-5" />
                                    </button>
                                    <button onClick={() => setShowDuelModal(true)} className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-2 px-4 rounded-full transition-colors flex items-center space-x-2">
                                        <SwordsIcon className="w-5 h-5" />
                                        <span>Challenge</span>
                                    </button>
                                    {renderFriendButton()}
                                </>
                            )}
                        </div>
                    </div>
                     <div className="mt-4">
                        <h2 className="text-3xl font-bold text-white">{profile.user.name}</h2>
                        <p className="text-gray-300 mt-2">{profile.bio}</p>
                     </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border-y border-slate-800">
                    <StatCard 
                        icon={<RoadIcon className="w-6 h-6 text-orange-400"/>} 
                        value={isCurrentUser ? savedRidesCount : profile.stats.rides} 
                        label="Rides" 
                    />
                    <StatCard 
                        icon={<UsersIcon className="w-6 h-6 text-blue-400"/>} 
                        value={profile.stats.friends.toLocaleString()}
                        label="Friends"
                    />
                </div>
                
                <div className="p-4 border-b border-slate-800">
                    <h3 className="text-xl font-bold text-white mb-3">Badges</h3>
                    <div className="flex space-x-1 border-b border-slate-700 mb-4 overflow-x-auto">
                        {badgeCategories.map(cat => (
                            <button
                                key={cat.type}
                                onClick={() => setActiveBadgeTab(cat.type)}
                                className={`px-3 py-2 text-sm font-medium transition-colors flex-shrink-0 ${
                                    activeBadgeTab === cat.type
                                        ? 'border-b-2 border-orange-500 text-white'
                                        : 'text-gray-400 hover:text-white border-b-2 border-transparent'
                                }`}
                            >
                                {cat.label}
                            </button>
                        ))}
                    </div>
    
                    <div className="space-y-4">
                        {['Platinum', 'Gold', 'Silver', 'Bronze'].map(tier => {
                            const tierBadges = unlockedBadgesForTab.filter(b => b.tier === tier);
                            if (tierBadges.length === 0) return null;
    
                            return (
                                <div key={tier}>
                                    <h4 className={`font-bold text-lg ${TIER_COLORS[tier as BadgeTier]}`}>{tier}</h4>
                                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-2">
                                        {tierBadges.map(badge => (
                                            <BadgeCard key={badge.id} badge={badge} />
                                        ))}
                                    </div>
                                </div>
                            );
                        })}
    
                        {unlockedBadgesForTab.length === 0 && (
                            <div className="text-center py-8 bg-slate-800/50 rounded-lg">
                                <TrophyIcon className="w-12 h-12 mx-auto text-gray-600 mb-2" />
                                <p className="text-gray-400 font-semibold">The trophy case is empty!</p>
                                 <p className="text-sm text-gray-500 mt-1">
                                    {isCurrentUser ? "Time to get out there and earn some!" : `${profile.user.name} hasn't unlocked badges here yet.`}
                                </p>
                            </div>
                        )}
                    </div>
                </div>
                
                <div className="p-4">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 gap-4">
                         <div className="flex space-x-1 bg-slate-800 p-1 rounded-full">
                            <FilterButton filter="all" label="All" />
                            <FilterButton filter="posts" label="Posts" />
                            <FilterButton filter="rides" label="Rides" />
                        </div>
                        <div className="relative">
                            <select
                                value={activitySort}
                                onChange={(e) => setActivitySort(e.target.value as 'recent' | 'liked')}
                                className="bg-slate-800 border border-slate-700 rounded-full py-2 pl-4 pr-10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none w-full sm:w-auto"
                            >
                                <option value="recent">Most Recent</option>
                                <option value="liked">Most Liked</option>
                            </select>
                            <svg className="w-5 h-5 text-gray-400 absolute top-1/2 right-3 -translate-y-1/2 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                        </div>
                    </div>
    
                    <div className="space-y-6">
                        {userActivity.length > 0 ? (
                            userActivity.map(item => {
                                if (item.type === 'post') {
                                    return <PostCard key={`activity-${item.data.id}`} post={item.data} onUserSelect={onUserSelect} />;
                                }
                                if (item.type === 'ride_share') {
                                    return <RideShareCard key={`activity-${item.data.id}`} rideShare={item.data} onUserSelect={onUserSelect} />;
                                }
                                return null;
                            })
                        ) : (
                            <div className="text-center py-10">
                                <p className="text-gray-500">No activity to show.</p>
                                <p className="text-sm text-gray-600">
                                    {isCurrentUser ? "Share a post or a ride to get started!" : `${profile.user.name} hasn't posted yet.`}
                                </p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {showDuelModal && <DuelModal opponent={profile.user} onBack={() => setShowDuelModal(false)} isFriend={friendshipStatus === 'FRIENDS'} />}
        </>
    );
    
    if (onBack) {
        return (
            <div className="fixed inset-0 bg-slate-950 z-50 overflow-y-auto animate-fade-in">
                {content}
            </div>
        );
    }
    
    return content;
};

export default ProfilePanel;