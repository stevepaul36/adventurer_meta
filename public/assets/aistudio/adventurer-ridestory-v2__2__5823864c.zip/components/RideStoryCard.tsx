import React from 'react';
import type { RideStory } from '../types';
import { RouteIcon } from './icons';

interface RideStoryCardProps {
    story: RideStory;
    onUserSelect: (userId: string) => void;
    onShowRideStory: (story: RideStory) => void;
}

const RideStoryCard: React.FC<RideStoryCardProps> = ({ story, onUserSelect, onShowRideStory }) => {
    return (
        <div className="bg-slate-900 rounded-lg overflow-hidden shadow-lg">
            <div className="p-4">
                <button onClick={() => onUserSelect(story.user.id)} className="flex items-center text-left group w-full">
                    <img src={story.user.avatarUrl} alt={story.user.name} className="w-12 h-12 rounded-full mr-4 transition-all duration-300 group-hover:ring-2 group-hover:ring-orange-500" />
                    <div className="flex-1">
                        <p className="font-bold text-white transition-colors group-hover:text-orange-400">{story.user.name}</p>
                        <p className="text-sm text-gray-500">{story.date.toLocaleDateString()} &middot; Shared a Ride Story</p>
                    </div>
                </button>
            </div>
            <div className="relative cursor-pointer group" onClick={() => onShowRideStory(story)}>
                <img src={story.coverImageUrl} alt={story.title} className="w-full h-auto object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-4 text-white">
                    <h3 className="text-3xl font-bold">{story.title}</h3>
                    <p className="text-gray-300 mt-1 text-sm">{story.description}</p>
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/50 rounded-full p-4 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center">
                    <RouteIcon className="w-8 h-8 text-white" />
                    <span className="text-white font-bold text-sm mt-1">View Story</span>
                </div>
            </div>
        </div>
    );
};

export default RideStoryCard;