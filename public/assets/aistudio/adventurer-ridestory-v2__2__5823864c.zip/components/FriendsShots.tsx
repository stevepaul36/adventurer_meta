import React from 'react';
import { SHOTS } from '../constants';

interface FriendsShotsProps {
    onShowShots: () => void;
}

const FriendsShots: React.FC<FriendsShotsProps> = ({ onShowShots }) => {
    return (
        <div className="mb-6">
            <h3 className="text-xl font-bold text-white mb-4">Journey Shorts</h3>
            <div className="flex space-x-4 overflow-x-auto pb-2 scrollbar-hide">
                {SHOTS.map(shot => (
                    <div 
                        key={shot.id} 
                        onClick={onShowShots} 
                        className="relative w-32 h-56 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer group shadow-lg"
                    >
                        <img 
                            src={shot.videoUrl} 
                            alt={shot.caption} 
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                        <div className="absolute bottom-0 left-0 right-0 p-2 text-white">
                            <p className="text-sm font-semibold truncate group-hover:text-orange-300 transition-colors">{shot.user.name}</p>
                            <p className="text-xs text-gray-300 truncate">{shot.caption}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default FriendsShots;