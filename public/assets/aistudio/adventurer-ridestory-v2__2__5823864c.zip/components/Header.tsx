import React from 'react';
import { FlameIcon, NotificationIcon, RouteIcon } from './icons';
import { CURRENT_USER } from '../constants';

type View = 'home' | 'streams' | 'messages' | 'notifications' | 'profile';

interface HeaderProps {
    activeView: View;
    setActiveView: (view: View) => void;
    onPlanJourneyClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ activeView, setActiveView, onPlanJourneyClick }) => {
    
    const NavLink: React.FC<{ view: View; label: string }> = ({ view, label }) => (
        <button 
            onClick={() => setActiveView(view)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeView === view 
                ? 'bg-orange-600 text-white shadow-md' 
                : 'text-gray-400 hover:bg-slate-800 hover:text-white'
            }`}
        >
            {label}
        </button>
    );

    return (
        <header className="bg-slate-900/80 backdrop-blur-sm sticky top-0 z-30 border-b border-slate-800">
            <div className="container mx-auto px-4 h-20 flex items-center justify-between">
                {/* Mobile Title (remains centered) */}
                <div className="flex-1 flex justify-center md:hidden">
                    <div className="flex items-center space-x-2">
                        <FlameIcon className="w-8 h-8 text-orange-500"/>
                        <h1 className="text-2xl font-bold text-white tracking-tight">MotoConnect</h1>
                    </div>
                </div>
                
                {/* Desktop Layout */}
                <div className="hidden md:flex items-center justify-between w-full">
                    {/* Left: Logo & Title */}
                    <div className="flex items-center space-x-3">
                        <FlameIcon className="w-9 h-9 text-orange-500"/>
                        <h1 className="text-2xl font-bold text-white tracking-tight">MotoConnect</h1>
                    </div>

                    {/* Center: Navigation */}
                    <nav className="flex items-center space-x-2">
                        <NavLink view="home" label="Home" />
                        <NavLink view="streams" label="Streams" />
                        <NavLink view="messages" label="Messages" />
                    </nav>

                    {/* Right: Actions & Profile */}
                    <div className="flex items-center space-x-4">
                        <button 
                            onClick={onPlanJourneyClick} 
                            className="bg-slate-800 text-orange-400 px-4 py-2 rounded-full flex items-center space-x-2 hover:bg-orange-600 hover:text-white transition-colors" 
                            title="AI Journey Planner"
                        >
                            <RouteIcon className="w-5 h-5"/>
                            <span className="text-sm font-medium">Plan Journey</span>
                        </button>
                        <button 
                            onClick={() => setActiveView('notifications')} 
                            className="p-2 rounded-full text-gray-400 hover:bg-slate-800 hover:text-white transition-colors relative"
                            title="Notifications"
                        >
                            <NotificationIcon className="w-6 h-6"/>
                            <span className="absolute top-1 right-1 block h-2 w-2 rounded-full bg-red-500 ring-1 ring-slate-900"></span>
                        </button>
                         <button 
                            onClick={() => setActiveView('profile')} 
                            className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
                            title="Profile"
                        >
                            <img src={CURRENT_USER.avatarUrl} alt="Profile" className="w-10 h-10 rounded-full border-2 border-slate-700 hover:border-orange-500 transition-colors"/>
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;