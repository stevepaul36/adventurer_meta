import React from 'react';
import { CLUBS, USER_CLUBS } from '../constants';
import { UsersIcon } from './icons';

interface ClubsOverviewProps {
    onShowClubs: () => void;
}

const GoalProgress: React.FC<{ goal: typeof CLUBS[0]['goals'][0] }> = ({ goal }) => {
    const progress = Math.min((goal.current / goal.target) * 100, 100);
    return (
        <div>
            <div className="flex justify-between items-baseline mb-1">
                <p className="text-xs text-gray-400 truncate">{goal.name}</p>
                <span className="text-xs font-semibold text-gray-400">
                    {Math.round(progress)}%
                </span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-1.5">
                <div
                    className="bg-orange-500 h-1.5 rounded-full"
                    style={{ width: `${progress}%` }}
                ></div>
            </div>
        </div>
    );
};

const ClubsOverview: React.FC<ClubsOverviewProps> = ({ onShowClubs }) => {
    const myClubs = CLUBS.filter(club => USER_CLUBS.includes(club.id));

    if (myClubs.length === 0) {
        return null;
    }

    return (
        <div className="bg-slate-900 rounded-lg p-4 shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-white">My Clubs</h3>
                 <button onClick={onShowClubs} className="text-sm font-semibold text-orange-400 hover:text-orange-300">
                    View All
                </button>
            </div>
            <div className="space-y-4">
                {myClubs.slice(0, 2).map(club => ( // Show max 2 clubs for a brief overview
                    <div key={club.id} onClick={onShowClubs} className="bg-slate-800/50 p-3 rounded-lg cursor-pointer hover:bg-slate-700 transition-colors">
                        <div className="flex items-center space-x-3 mb-2">
                             <img src={club.badgeUrl} alt={`${club.name} badge`} className="w-10 h-10 rounded-lg" />
                             <div className="flex-1">
                                <h4 className="font-bold text-white">{club.name}</h4>
                                <p className="text-xs text-gray-400 flex items-center">
                                    <UsersIcon className="w-3 h-3 mr-1"/>
                                    {club.memberCount} members
                                </p>
                             </div>
                        </div>
                        {club.goals.length > 0 && (
                            <GoalProgress goal={club.goals[0]} />
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ClubsOverview;
