import React from 'react';
import ShotCard from './ShotCard';
import { SHOTS } from '../constants';
import { BackIcon } from './icons';

interface ShotsPanelProps {
    onBack: () => void;
    onUserSelect: (userId: string) => void;
}


const ShotsPanel: React.FC<ShotsPanelProps> = ({ onBack, onUserSelect }) => {
  return (
    <div className="fixed inset-0 bg-black z-50">
        <div className="relative h-full w-full max-w-md mx-auto snap-y snap-mandatory overflow-y-scroll scrollbar-hide">
            {SHOTS.map(shot => (
                <div key={shot.id} className="h-full w-full snap-start flex-shrink-0">
                    <ShotCard shot={shot} onUserSelect={onUserSelect} />
                </div>
            ))}
        </div>
        <button onClick={onBack} className="absolute top-4 left-4 bg-black bg-opacity-50 hover:bg-opacity-75 text-white p-2 rounded-full transition-colors z-10">
            <BackIcon className="w-6 h-6"/>
        </button>
    </div>
  );
};

export default ShotsPanel;