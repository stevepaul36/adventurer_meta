import type { User, Post, Stream, Shot, Conversation, Notification, Profile, Activity, Journey, Achievement, RidingGoal, RideShare, FeedItem, LeaderboardEntry, Badge, BadgeTier, ActivityType, Club, ClubGoal, ClubAchievement, ClubMember, ClubChatMessage, RideStory, StoryPost, FriendRequest, CommunityChallenge, ClubChallenge } from './types';
import { TrophyIcon, RoadIcon, MountainIcon, ClockIcon, MapPinIcon, RouteIcon, CalendarIcon, FlameIcon, FootstepsIcon, CarIcon, UsersGroupIcon, LeafIcon, UsersIcon } from './components/icons';

export const USERS: Record<string, User> = {
  u1: { id: 'u1', name: 'Alex Rider', avatarUrl: 'https://i.pravatar.cc/150?u=u1' },
  u2: { id: 'u2', name: 'Mia Torque', avatarUrl: 'https://i.pravatar.cc/150?u=u2' },
  u3: { id: 'u3', name: 'Clutch Cargo', avatarUrl: 'https://i.pravatar.cc/150?u=u3' },
  u4: { id: 'u4', name: 'Vance Velocity', avatarUrl: 'https://i.pravatar.cc/150?u=u4' },
  u5: { id: 'u5', name: 'Harley Quinn', avatarUrl: 'https://i.pravatar.cc/150?u=u5' },
};

export const CURRENT_USER = USERS.u1;

export const FRIEND_REQUESTS: FriendRequest[] = [
    { id: 'fr1', from: USERS.u4, timestamp: '2 hours ago' },
];

export const POSTS: Post[] = [
  {
    id: 'p1',
    user: USERS.u2,
    timestamp: '2 hours ago',
    date: new Date(Date.now() - 2 * 60 * 60 * 1000),
    caption: 'Incredible morning ride through the mountain pass. The views were breathtaking!',
    imageUrl: 'https://picsum.photos/seed/p1/600/400',
    rideStats: { distance: 125, duration: '3h 15m', elevation: 1200 },
    likes: 128,
    comments: [
      { id: 'c1', user: USERS.u3, text: 'Wow, that looks amazing!' },
      { id: 'c2', user: USERS.u4, text: 'I need to do this route. Can you share the GPX?' },
    ],
  },
  {
    id: 'p_alex2',
    user: USERS.u1,
    timestamp: '1 day ago',
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    caption: 'Quick stop for a photo op during the golden hour.',
    imageUrl: 'https://picsum.photos/seed/p_alex2/600/400',
    likes: 310,
    comments: [],
  },
  {
    id: 'p2',
    user: USERS.u4,
    timestamp: '2 days ago',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    caption: 'Coastal cruising with the crew. Nothing beats the smell of the ocean and the sound of a V-twin.',
    imageUrl: 'https://picsum.photos/seed/p2/600/400',
    likes: 256,
    comments: [
      { id: 'c3', user: USERS.u1, text: 'Epic shot!' },
    ],
  },
  {
    id: 'p3',
    user: USERS.u3,
    timestamp: '3 days ago',
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    caption: 'Great track day! Pushing the limits and shaving off seconds. The bike felt amazing.',
    imageUrl: 'https://picsum.photos/seed/p3/600/400',
    likes: 310,
    comments: [
        { id: 'c4', user: USERS.u5, text: 'Awesome! Looked fast out there.' },
    ],
  },
  {
    id: 'p_alex1',
    user: USERS.u1,
    timestamp: '5 days ago',
    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    caption: 'Had a fantastic solo trip through the forest trails. The tranquility was just what I needed. Highly recommend!',
    imageUrl: 'https://picsum.photos/seed/p_alex1/600/400',
    rideStats: { distance: 85, duration: '2h 45m', elevation: 800 },
    likes: 152,
    comments: [
      { id: 'c_alex1', user: USERS.u2, text: 'Looks peaceful! Glad you enjoyed it.' },
    ],
  },
];

export const RIDE_SHARES: RideShare[] = [
  {
    id: 'rs1',
    user: USERS.u5,
    timestamp: '4 hours ago',
    date: new Date(Date.now() - 4 * 60 * 60 * 1000),
    title: 'Twisted Sisters Loop',
    mapImageUrl: 'https://picsum.photos/seed/rs1/600/300',
    rideStats: { distance: 350, duration: '6h 45m', elevation: 1500 },
    likes: 450,
    comments: [
      { id: 'rsc1', user: USERS.u1, text: 'That ride is legendary! Hope you had fun.' },
      { id: 'rsc2', user: USERS.u2, text: 'The best roads in Texas, hands down.' },
    ],
  },
  {
    id: 'rs_alex1',
    user: USERS.u1,
    timestamp: '4 days ago',
    date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    title: 'Weekend Escape to the Lake',
    mapImageUrl: 'https://picsum.photos/seed/rs_alex1/600/300',
    rideStats: { distance: 180, duration: '4h 20m', elevation: 600 },
    likes: 225,
    comments: [
        { id: 'rsc3', user: USERS.u4, text: 'Looks like a perfect getaway.' },
    ],
  },
];

export const RIDE_STORIES: RideStory[] = [
    {
        id: 'story1',
        user: USERS.u1,
        title: 'My Weekend Forest Escape',
        description: 'A collection of moments from my recent solo trip to the lake and through the forest trails. A much-needed break!',
        coverImageUrl: 'https://picsum.photos/seed/story1_cover/600/400',
        date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), // Date of the latest post in story
        storyPosts: [
            { 
                ...RIDE_SHARES.find(rs => rs.id === 'rs_alex1')!,
                mapPosition: { x: 20, y: 80 },
            },
            {
                ...POSTS.find(p => p.id === 'p_alex1')!,
                mapPosition: { x: 55, y: 50 },
            },
            {
                ...POSTS.find(p => p.id === 'p_alex2')!,
                mapPosition: { x: 85, y: 25 },
            },
        ],
        // An SVG path string for the map route
        routePath: "M 20 80 C 30 70, 45 60, 55 50 C 65 40, 75 30, 85 25",
    },
];


// Combine posts and ride shares into a single feed, and sort by date for accurate chronology
export const FEED_ITEMS: FeedItem[] = [
    ...POSTS.map(p => ({ type: 'post' as const, data: p })),
    ...RIDE_SHARES.map(rs => ({ type: 'ride_share' as const, data: rs })),
    ...RIDE_STORIES.map(story => ({ type: 'ride_story' as const, data: story })),
].sort((a, b) => b.data.date.getTime() - a.data.date.getTime());


export const STREAMS: Stream[] = [
  { id: 's1', title: 'Live from the Twisted Sisters', thumbnailUrl: 'https://picsum.photos/seed/s1/400/225', streamer: USERS.u5, isLive: true, viewers: 1845 },
  { id: 's2', title: 'Track Day at COTA', thumbnailUrl: 'https://picsum.photos/seed/s2/400/225', streamer: USERS.u3, isLive: true, viewers: 980 },
  { id: 's3', title: 'Custom Build Final Reveal', thumbnailUrl: 'https://picsum.photos/seed/s3/400/225', streamer: USERS.u2, isLive: false, viewers: 0 },
];

export const SHOTS: Shot[] = [
    { 
        id: 'sh1', 
        user: USERS.u2, 
        videoUrl: 'https://picsum.photos/seed/sh1/400/700', 
        caption: 'Quick fly-by!', 
        likes: 12500, 
        comments: [
            { id: 'shc1', user: USERS.u1, text: 'So fast!' },
            { id: 'shc2', user: USERS.u3, text: 'Nice one!' },
        ], 
        shares: 129 
    },
    { 
        id: 'sh2', 
        user: USERS.u3, 
        videoUrl: 'https://picsum.photos/seed/sh2/400/700', 
        caption: 'Wheelie Wednesday!', 
        likes: 23100, 
        comments: [
            { id: 'shc3', user: USERS.u5, text: 'Teaching me next?' },
        ], 
        shares: 451 
    },
    { 
        id: 'sh3', 
        user: USERS.u4, 
        videoUrl: 'https://picsum.photos/seed/sh3/400/700', 
        caption: 'Morning warm-up sounds', 
        likes: 8900, 
        comments: [], 
        shares: 78 
    },
];

export const CONVERSATIONS: Conversation[] = [
    { id: 'cv1', participant: USERS.u2, lastMessage: { id: 'm1', sender: USERS.u2, text: "Hey, are we still on for the ride this weekend?", timestamp: "10:30", isRead: false } },
    { id: 'cv2', participant: USERS.u3, lastMessage: { id: 'm2', sender: CURRENT_USER, text: "Yeah, I'll send you the route details.", timestamp: "09:15", isRead: true } },
    { id: 'cv3', participant: USERS.u4, lastMessage: { id: 'm3', sender: USERS.u4, text: "Check out this new helmet!", timestamp: "Yesterday", isRead: true } },
];

export const NOTIFICATIONS: Notification[] = [
    { id: 'n1', type: 'like', user: USERS.u2, timestamp: '15 minutes ago', post: { imageUrl: 'https://picsum.photos/seed/p1/100/100' } },
    { id: 'n2', type: 'comment', user: USERS.u4, timestamp: '1 hour ago', post: { imageUrl: 'https://picsum.photos/seed/p1/100/100' } },
    { id: 'n3', type: 'follow', user: USERS.u5, timestamp: '3 hours ago' },
    { id: 'n4', type: 'event', user: USERS.u1, timestamp: '1 day ago', event: { title: 'Annual Charity Ride', date: 'in 2 days' } },
];

export const PROFILES: Record<string, Profile> = {
  'u1': { // This is CURRENT_USER
    id: 'prof1',
    user: USERS.u1,
    bio: 'Just a rider enjoying the open road. Capturing moments one mile at a time.',
    stats: { rides: 42, friends: 2 },
    friends: ['u2', 'u3'],
  },
  'u2': {
    id: 'prof2',
    user: USERS.u2,
    bio: 'Pushing the limits on two wheels. Custom builds and track days are my jam.',
    stats: { rides: 89, friends: 1 },
    friends: ['u1'],
  },
  'u3': {
    id: 'prof3',
    user: USERS.u3,
    bio: 'Track day enthusiast. If it has two wheels, I\'ll race it.',
    stats: { rides: 150, friends: 1 },
    friends: ['u1'],
  },
  'u4': {
    id: 'prof4',
    user: USERS.u4,
    bio: 'Coastal roads and chrome. Living the cruiser life.',
    stats: { rides: 15, friends: 0 },
    friends: [],
  },
  'u5': {
    id: 'prof5',
    user: USERS.u5,
    bio: 'Twisty roads are my therapy.',
    stats: { rides: 67, friends: 0 },
    friends: [],
  }
};

export const ACTIVITIES: Activity[] = [
  { id: 'a1', type: 'ride', timestamp: '2 hours ago', title: 'Mountain Pass Ascent', details: '125 km ride', imageUrl: 'https://picsum.photos/seed/p1/200/200' },
  { id: 'a2', type: 'post', timestamp: 'Yesterday', title: 'Posted a photo', details: 'Coastal cruising with the crew.', imageUrl: 'https://picsum.photos/seed/p2/200/200' },
];

// Mock data for user's logged journeys
export const JOURNEYS: Journey[] = [
    { id: 'j1', title: 'Morning Mountain Loop', distance: 125, duration: '3h 15m', elevation: 1200 },
    { id: 'j2', title: 'Coastal Cruise', distance: 210, duration: '5h 30m', elevation: 250 },
    { id: 'j3', title: 'Forest Trail Ride', distance: 85, duration: '2h 45m', elevation: 800 },
    { id: 'j4', title: 'City to Summit', distance: 305, duration: '6h 10m', elevation: 2500 },
    { id: 'j5', title: 'Quick Canyon Blast', distance: 60, duration: '1h 20m', elevation: 400 },
];

export const ALL_USER_JOURNEYS: Record<string, Journey[]> = {
    'u1': JOURNEYS, // from existing constant for current user
    'u2': [ // Mia Torque
        { id: 'j6', title: 'Speed Demon Run', distance: 180, duration: '4h 0m', elevation: 500 },
        { id: 'j7', title: 'Lakefront Loop', distance: 95, duration: '2h 15m', elevation: 150 },
        { id: 'j8', title: 'Highway Star', distance: 450, duration: '7h 30m', elevation: 300 },
    ],
    'u3': [ // Clutch Cargo
        { id: 'j9', title: 'Tech Park Sprint', distance: 50, duration: '1h 5m', elevation: 50 },
        { id: 'j10', title: 'Cross-Town Express', distance: 75, duration: '2h 0m', elevation: 100 },
    ],
    'u4': [ // Vance Velocity
        { id: 'j11', title: 'Pacific Coast Highway', distance: 650, duration: '10h 0m', elevation: 1800 },
        { id: 'j12', title: 'Desert Dash', distance: 320, duration: '5h 45m', elevation: 400 },
    ],
    'u5': [ // Harley Quinn
        { id: 'j13', title: 'Twisted Sisters', distance: 350, duration: '6h 45m', elevation: 1500 },
        { id: 'j14', title: 'Urban Explorer', distance: 45, duration: '1h 30m', elevation: 80 },
        { id: 'j15', title: 'Hill Country Ride', distance: 280, duration: '5h 0m', elevation: 1100 },
        { id: 'j16', 'title': 'Night Rider', distance: 110, duration: '2h 20m', elevation: 200 },
    ],
};

// Master list of all possible achievements
export const ACHIEVEMENTS: Achievement[] = [
    { id: 'a_dist_100', name: 'Century Rider', description: 'Ride for over 100km in a single journey.', icon: TrophyIcon },
    { id: 'a_dist_250', name: 'Endurance Pro', description: 'Complete a single journey longer than 250km.', icon: TrophyIcon },
    { id: 'a_elev_1000', name: 'Mountain Goat', description: 'Gain over 1000m of elevation in a single ride.', icon: MountainIcon },
    { id: 'a_elev_2000', name: 'Peak Bagger', description: 'Conquer over 2000m of elevation in one go.', icon: MountainIcon },
    { id: 'a_total_500', name: 'Road Warrior', description: 'Accumulate a total of 500km across all rides.', icon: RoadIcon },
    { id: 'a_first_ride', name: 'Journey Begins', description: 'Log your first ride.', icon: RoadIcon },
];

export const BADGE_SYSTEM: Badge[] = [
    // Motorcycling
    { id: 'moto_long_haul_bronze', activityType: 'Motorcycling', name: 'Long Haul Legend', tier: 'Bronze', description: 'Complete a 100 km ride', icon: RoadIcon },
    { id: 'moto_long_haul_silver', activityType: 'Motorcycling', name: 'Long Haul Legend', tier: 'Silver', description: 'Complete a 250 km ride', icon: RoadIcon },
    { id: 'moto_long_haul_gold', activityType: 'Motorcycling', name: 'Long Haul Legend', tier: 'Gold', description: 'Complete a 500 km ride', icon: RoadIcon },
    { id: 'moto_long_haul_platinum', activityType: 'Motorcycling', name: 'Long Haul Legend', tier: 'Platinum', description: 'Complete a 1,000 km ride', icon: RoadIcon },
    { id: 'moto_mountain_master_bronze', activityType: 'Motorcycling', name: 'Mountain Master', tier: 'Bronze', description: 'Gain 1,000 m elevation', icon: MountainIcon },
    { id: 'moto_mountain_master_silver', activityType: 'Motorcycling', name: 'Mountain Master', tier: 'Silver', description: 'Gain 2,000 m elevation', icon: MountainIcon },
    { id: 'moto_mountain_master_gold', activityType: 'Motorcycling', name: 'Mountain Master', tier: 'Gold', description: 'Gain 3,500 m elevation', icon: MountainIcon },
    { id: 'moto_mountain_master_platinum', activityType: 'Motorcycling', name: 'Mountain Master', tier: 'Platinum', description: 'Gain 5,000 m elevation', icon: MountainIcon },
    { id: 'moto_iron_butt_bronze', activityType: 'Motorcycling', name: 'Iron Butt Initiate', tier: 'Bronze', description: 'Ride on 5 days in a month', icon: CalendarIcon },
    { id: 'moto_iron_butt_silver', activityType: 'Motorcycling', name: 'Iron Butt Initiate', tier: 'Silver', description: 'Ride on 10 days in a month', icon: CalendarIcon },
    { id: 'moto_iron_butt_gold', activityType: 'Motorcycling', name: 'Iron Butt Initiate', tier: 'Gold', description: 'Ride on 20 days in a month', icon: CalendarIcon },
    { id: 'moto_iron_butt_platinum', activityType: 'Motorcycling', name: 'Iron Butt Initiate', tier: 'Platinum', description: 'Ride every day for a month', icon: CalendarIcon },
    // Cycling
    { id: 'cycle_endurance_bronze', activityType: 'Cycling', name: 'Endurance Cyclist', tier: 'Bronze', description: 'Complete a 50 km ride', icon: RoadIcon },
    { id: 'cycle_endurance_silver', activityType: 'Cycling', name: 'Endurance Cyclist', tier: 'Silver', description: 'Complete a 100 km ride', icon: RoadIcon },
    { id: 'cycle_endurance_gold', activityType: 'Cycling', name: 'Endurance Cyclist', tier: 'Gold', description: 'Complete a 161 km ride', icon: RoadIcon },
    { id: 'cycle_endurance_platinum', activityType: 'Cycling', name: 'Endurance Cyclist', tier: 'Platinum', description: 'Complete a 200 km ride', icon: RoadIcon },
    { id: 'cycle_hill_conqueror_bronze', activityType: 'Cycling', name: 'Hill Conqueror', tier: 'Bronze', description: 'Gain 500 m elevation', icon: MountainIcon },
    { id: 'cycle_hill_conqueror_silver', activityType: 'Cycling', name: 'Hill Conqueror', tier: 'Silver', description: 'Gain 1,000 m elevation', icon: MountainIcon },
    { id: 'cycle_hill_conqueror_gold', activityType: 'Cycling', name: 'Hill Conqueror', tier: 'Gold', description: 'Gain 2,000 m elevation', icon: MountainIcon },
    { id: 'cycle_hill_conqueror_platinum', activityType: 'Cycling', name: 'Hill Conqueror', tier: 'Platinum', description: 'Gain 3,000 m elevation', icon: MountainIcon },
    { id: 'cycle_velocity_bronze', activityType: 'Cycling', name: 'Velocity Virtuoso', tier: 'Bronze', description: 'Avg 25 km/h for 1 hr', icon: FlameIcon },
    { id: 'cycle_velocity_silver', activityType: 'Cycling', name: 'Velocity Virtuoso', tier: 'Silver', description: 'Avg 30 km/h for 1 hr', icon: FlameIcon },
    { id: 'cycle_velocity_gold', activityType: 'Cycling', name: 'Velocity Virtuoso', tier: 'Gold', description: 'Avg 35 km/h for 1 hr', icon: FlameIcon },
    { id: 'cycle_velocity_platinum', activityType: 'Cycling', name: 'Velocity Virtuoso', tier: 'Platinum', description: 'Avg 40 km/h for 1 hr', icon: FlameIcon },
    // Walking
    { id: 'walk_step_champ_bronze', activityType: 'Walking', name: 'Step Champion', tier: 'Bronze', description: '10,000 steps in a day', icon: FootstepsIcon },
    { id: 'walk_step_champ_silver', activityType: 'Walking', name: 'Step Champion', tier: 'Silver', description: '15,000 steps in a day', icon: FootstepsIcon },
    { id: 'walk_step_champ_gold', activityType: 'Walking', name: 'Step Champion', tier: 'Gold', description: '20,000 steps in a day', icon: FootstepsIcon },
    { id: 'walk_step_champ_platinum', activityType: 'Walking', name: 'Step Champion', tier: 'Platinum', description: '25,000 steps in a day', icon: FootstepsIcon },
    // Car Trips
    { id: 'car_cruiser_bronze', activityType: 'Car Trips', name: 'Cross-Country Cruiser', tier: 'Bronze', description: 'Complete a 500 km trip', icon: CarIcon },
    { id: 'car_cruiser_silver', activityType: 'Car Trips', name: 'Cross-Country Cruiser', tier: 'Silver', description: 'Complete a 1,000 km trip', icon: CarIcon },
    { id: 'car_cruiser_gold', activityType: 'Car Trips', name: 'Cross-Country Cruiser', tier: 'Gold', description: 'Complete a 2,500 km trip', icon: CarIcon },
    { id: 'car_cruiser_platinum', activityType: 'Car Trips', name: 'Cross-Country Cruiser', tier: 'Platinum', description: 'Complete a 5,000 km trip', icon: CarIcon },
    { id: 'car_collector_bronze', activityType: 'Car Trips', name: 'State Collector', tier: 'Bronze', description: 'Visit 3 states/provinces', icon: MapPinIcon },
    { id: 'car_collector_silver', activityType: 'Car Trips', name: 'State Collector', tier: 'Silver', description: 'Visit 5 states/provinces', icon: MapPinIcon },
    { id: 'car_collector_gold', activityType: 'Car Trips', name: 'State Collector', tier: 'Gold', description: 'Visit 10 states/provinces', icon: MapPinIcon },
    { id: 'car_collector_platinum', activityType: 'Car Trips', name: 'State Collector', tier: 'Platinum', description: 'Visit 15 states/provinces', icon: MapPinIcon },
    // Hybrid
    { id: 'hybrid_warrior_bronze', activityType: 'Hybrid', name: 'Weekly Warrior', tier: 'Bronze', description: '2 different activities in a week', icon: UsersGroupIcon },
    { id: 'hybrid_warrior_silver', activityType: 'Hybrid', name: 'Weekly Warrior', tier: 'Silver', description: '3 different activities in a week', icon: UsersGroupIcon },
    { id: 'hybrid_warrior_gold', activityType: 'Hybrid', name: 'Weekly Warrior', tier: 'Gold', description: '4 different activities in a week', icon: UsersGroupIcon },
    { id: 'hybrid_warrior_platinum', activityType: 'Hybrid', name: 'Weekly Warrior', tier: 'Platinum', description: 'All 5 activities in a week', icon: UsersGroupIcon },
    { id: 'hybrid_eco_bronze', activityType: 'Hybrid', name: 'Eco-Explorer', tier: 'Bronze', description: 'Motorized & non-motorized trip in a day', icon: LeafIcon },
    { id: 'hybrid_eco_silver', activityType: 'Hybrid', name: 'Eco-Explorer', tier: 'Silver', description: 'Achieve Eco-Explorer Bronze 5 times', icon: LeafIcon },
    { id: 'hybrid_eco_gold', activityType: 'Hybrid', name: 'Eco-Explorer', tier: 'Gold', description: 'Achieve Eco-Explorer Bronze 10 times', icon: LeafIcon },
    { id: 'hybrid_eco_platinum', activityType: 'Hybrid', name: 'Eco-Explorer', tier: 'Platinum', description: 'Achieve Eco-Explorer Bronze 25 times', icon: LeafIcon },
];

export const USER_UNLOCKED_BADGES: Record<string, string[]> = {
    'u1': [ // Alex Rider (Current User)
        'moto_long_haul_bronze',
        'moto_long_haul_silver',
        'moto_mountain_master_bronze',
        'moto_mountain_master_silver',
        'cycle_endurance_bronze',
        'walk_step_champ_bronze',
        'walk_step_champ_silver',
        'hybrid_warrior_bronze',
    ],
    'u2': [ // Mia Torque
        'moto_long_haul_bronze',
        'moto_long_haul_silver',
        'moto_long_haul_gold',
        'moto_mountain_master_bronze',
        'moto_mountain_master_silver',
        'cycle_endurance_bronze',
        'cycle_endurance_silver',
        'cycle_velocity_bronze',
    ],
    'u4': [ // Vance Velocity
        'moto_long_haul_bronze',
        'car_cruiser_bronze',
        'car_cruiser_silver',
        'car_collector_bronze',
    ],
    // u3 and u5 have fewer for variety
    'u3': ['moto_long_haul_bronze'],
    'u5': ['moto_long_haul_bronze', 'moto_long_haul_silver', 'moto_long_haul_gold'],
};

// Master list of riding goals
export const RIDING_GOALS: RidingGoal[] = [
    { id: 'g_dist_1000', name: 'Monthly Distance', type: 'distance', target: 1000, icon: RoadIcon },
    { id: 'g_elev_5000', name: 'Elevation Challenge', type: 'elevation', target: 5000, icon: MountainIcon },
    { id: 'g_rides_10', name: 'Ride Consistency', type: 'count', target: 10, icon: TrophyIcon },
];


// --- Leaderboard Generation ---
const calculateLeaderboards = () => {
    const userIds = Object.keys(USERS);
    const stats = userIds.map(userId => {
        const user = USERS[userId];
        const userJourneys = ALL_USER_JOURNEYS[user.id] || [];
        const totalDistance = userJourneys.reduce((sum, j) => sum + j.distance, 0);
        const totalElevation = userJourneys.reduce((sum, j) => sum + j.elevation, 0);
        const totalRides = userJourneys.length;
        return { user, totalDistance, totalElevation, totalRides };
    });

    const createRankedList = (
        stats: any[], 
        key: 'totalDistance' | 'totalElevation' | 'totalRides'
    ): LeaderboardEntry[] => {
        return stats
            .filter(s => s[key] > 0)
            .sort((a, b) => b[key] - a[key])
            .map((s, index) => ({
                user: s.user,
                rank: index + 1,
                value: s[key]
            }));
    };

    return {
        distance: createRankedList(stats, 'totalDistance'),
        elevation: createRankedList(stats, 'totalElevation'),
        rides: createRankedList(stats, 'totalRides'),
    };
};

const leaderboards = calculateLeaderboards();

export const LEADERBOARD_DISTANCE = leaderboards.distance;
export const LEADERBOARD_ELEVATION = leaderboards.elevation;
export const LEADERBOARD_RIDES = leaderboards.rides;


// --- Club System Data ---

export const CLUB_GOALS: Record<string, ClubGoal[]> = {
    'club1': [
        { id: 'cg1', name: 'Ride 5,000 km Together', description: 'Collective distance challenge for the month.', type: 'distance', target: 5000, current: 3150, icon: RoadIcon },
        { id: 'cg2', name: 'Climb 10,000m', description: 'Total elevation gain for the club.', type: 'elevation', target: 10000, current: 4500, icon: MountainIcon },
        { id: 'cg3', name: '50 Group Rides', description: 'Complete 50 rides as a club.', type: 'rides', target: 50, current: 15, icon: UsersIcon },
    ],
    'club2': [
        { id: 'cg4', name: 'Weekly 100km Walk', description: 'Walk a total of 100km this week.', type: 'distance', target: 100, current: 88, icon: FootstepsIcon },
    ]
};

export const CLUB_ACHIEVEMENTS: Record<string, ClubAchievement[]> = {
    'club1': [
        { id: 'ca1', name: 'Founding Members', description: 'Be part of the club from day one.', isUnlocked: true, icon: TrophyIcon },
        { id: 'ca2', name: 'First 1,000km', description: 'The club collectively rode its first 1,000 kilometers.', isUnlocked: true, icon: RoadIcon },
        { id: 'ca3', name: 'Mountain Conquerors', description: 'The club collectively climbed over 5,000m.', isUnlocked: false, icon: MountainIcon },
    ],
    'club2': [
         { id: 'ca4', name: 'Trail Blazers', description: 'First club event completed.', isUnlocked: true, icon: MapPinIcon },
    ]
};

export const CLUBS: Club[] = [
    {
        id: 'club1',
        name: 'Asphalt Adventurers',
        badgeUrl: 'https://picsum.photos/seed/club1/100/100',
        description: 'A club for passionate motorcycle riders who love exploring new roads and long journeys.',
        memberCount: 25,
        isPrivate: false,
        members: [
            { user: USERS.u1, role: 'Admin' },
            { user: USERS.u2, role: 'Member' },
            { user: USERS.u4, role: 'Member' },
            { user: USERS.u5, role: 'Member' },
        ],
        goals: CLUB_GOALS['club1'],
        achievements: CLUB_ACHIEVEMENTS['club1'],
        chat: [
            { id: 'cc1', user: USERS.u2, text: 'Who is up for a ride this weekend?', timestamp: '2h ago' },
            { id: 'cc2', user: USERS.u4, text: 'I am! Where are we thinking of going?', timestamp: '1h ago' },
            { id: 'cc3', user: USERS.u1, text: 'Let\'s plan something with the AI planner!', timestamp: '30m ago' },
        ]
    },
    {
        id: 'club2',
        name: 'City Trekkers',
        badgeUrl: 'https://picsum.photos/seed/club2/100/100',
        description: 'Exploring the city on foot. Join us for morning walks and urban adventures.',
        memberCount: 12,
        isPrivate: true,
        members: [
            { user: USERS.u3, role: 'Admin' },
            { user: USERS.u1, role: 'Member' },
        ],
        goals: CLUB_GOALS['club2'],
        achievements: CLUB_ACHIEVEMENTS['club2'],
        chat: [
            { id: 'cc4', user: USERS.u3, text: 'Saturday morning walk at 7 AM, meet at the central park entrance.', timestamp: 'Yesterday' }
        ]
    },
    {
        id: 'club3',
        name: 'Velocity Vipers',
        badgeUrl: 'https://picsum.photos/seed/club3/100/100',
        description: 'A club for those who chase the horizon and love speed.',
        memberCount: 32,
        isPrivate: false,
        members: [], // Simplified for mock data
        goals: [],
        achievements: [],
        chat: []
    },
];

export const USER_CLUBS: string[] = ['club1', 'club2'];

// --- Club Leaderboard Generation ---
type ClubLeaderboardData = { distance: LeaderboardEntry[], elevation: LeaderboardEntry[], rides: LeaderboardEntry[] };

const generateClubLeaderboard = (members: ClubMember[]): ClubLeaderboardData => {
    if (!members || members.length === 0) {
        return { distance: [], elevation: [], rides: [] };
    }
    const stats = members.map(member => {
        const user = member.user;
        const userJourneys = ALL_USER_JOURNEYS[user.id] || [];
        const totalDistance = userJourneys.reduce((sum, j) => sum + j.distance, 0);
        const totalElevation = userJourneys.reduce((sum, j) => sum + j.elevation, 0);
        const totalRides = userJourneys.length;
        return { user, totalDistance, totalElevation, totalRides };
    });

    const createRankedList = (
        stats: any[],
        key: 'totalDistance' | 'totalElevation' | 'totalRides'
    ): LeaderboardEntry[] => {
        return stats
            .filter(s => s[key] > 0)
            .sort((a, b) => b[key] - a[key])
            .map((s, index) => ({
                user: s.user,
                rank: index + 1,
                value: s[key]
            }));
    };

    return {
        distance: createRankedList(stats, 'totalDistance'),
        elevation: createRankedList(stats, 'totalElevation'),
        rides: createRankedList(stats, 'totalRides'),
    };
};

export const CLUB_LEADERBOARDS: Record<string, ClubLeaderboardData> = Object.values(CLUBS).reduce((acc, club) => {
    acc[club.id] = generateClubLeaderboard(club.members);
    return acc;
}, {} as Record<string, ClubLeaderboardData>);


// --- Challenges Data ---
export const COMMUNITY_CHALLENGES: CommunityChallenge[] = [
    {
        id: 'challenge1',
        title: 'Weekly Century',
        description: 'Ride a total of 100 km this week to earn bragging rights and progress towards your goals.',
        type: 'distance',
        goal: 100,
        userProgress: 72, // Mock progress for current user
        participants: 1254,
        timeframe: 'Weekly',
        icon: RoadIcon,
    },
    {
        id: 'challenge2',
        title: 'Monthly Mountain',
        description: 'Climb a total of 5,000 meters in elevation this month. Conquer the peaks!',
        type: 'elevation',
        goal: 5000,
        userProgress: 2890,
        participants: 843,
        timeframe: 'Monthly',
        icon: MountainIcon,
    },
    {
        id: 'challenge3',
        title: 'Frequent Rider',
        description: 'Complete 5 separate rides this week. Consistency is key!',
        type: 'rides',
        goal: 5,
        userProgress: 3,
        participants: 2301,
        timeframe: 'Weekly',
        icon: TrophyIcon,
    },
];

export const CLUB_CHALLENGES: ClubChallenge[] = [
    {
        id: 'cc1',
        title: 'Clash of the Titans: Distance Duel',
        description: 'Who can rack up the most mileage this week? Asphalt Adventurers vs. Velocity Vipers!',
        type: 'distance',
        goal: 10000, // 10,000 km goal
        competingClubs: [
            { clubId: 'club1', progress: 4500 }, // Asphalt Adventurers
            { clubId: 'club3', progress: 4250 }, // Velocity Vipers
        ],
        startDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // Started 3 days ago
        endDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000), // Ends in 4 days
    },
    {
        id: 'cc2',
        title: 'King of the Hill',
        description: 'A month-long battle to see which club can conquer the most elevation.',
        type: 'elevation',
        goal: 25000, // 25,000 m goal
        competingClubs: [
            { clubId: 'club1', progress: 26500 }, // Asphalt Adventurers
            { clubId: 'club2', progress: 18200 }, // City Trekkers
        ],
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Started a month ago
        endDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // Ended yesterday
        winnerClubId: 'club1',
    }
];