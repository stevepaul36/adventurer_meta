import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const API_TARGET = process.env.RIDESTORY_API || 'http://127.0.0.1:8787';

export default defineConfig(() => {
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
        // The RideStory server (server/index.mjs) owns model keys and FFmpeg rendering.
        proxy: {
          '/api': { target: API_TARGET, changeOrigin: true, timeout: 0, proxyTimeout: 0 },
        },
      },
      plugins: [react()],
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        }
      }
    };
});
