// Client for the RideStory server (server/index.mjs). Every call degrades gracefully:
// the Studio keeps working on-device when the server, model key or FFmpeg is missing.

import type { Moment } from './videoAnalysis';
import { formatTime } from './videoAnalysis';

export interface ServerHealth {
  online: boolean;
  ai: { configured: boolean; provider?: string; textModel?: string; visionModel?: string };
  ffmpeg: boolean;
}

export interface StoryCopy {
  caption: string;
  diary: string;
  hashtags: string[];
  chapters: { time: number; title: string }[];
  narration: string;
  source: 'ai' | 'template';
  model?: string;
}

const API = '/api';

export async function getServerHealth(): Promise<ServerHealth> {
  try {
    const res = await fetch(`${API}/health`, { signal: AbortSignal.timeout(4000) });
    if (!res.ok) throw new Error(String(res.status));
    const data = await res.json();
    return { online: true, ai: data.ai ?? { configured: false }, ffmpeg: Boolean(data.ffmpeg) };
  } catch {
    return { online: false, ai: { configured: false }, ffmpeg: false };
  }
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Server returned ${res.status}`);
  return data as T;
}

/** Ask the vision model to label and score each candidate moment from its keyframe. */
export async function labelMomentsWithAI(moments: Moment[], location: string): Promise<Moment[]> {
  const withImages = moments.filter(m => m.thumbnail).slice(0, 16);
  const { labels } = await postJson<{ labels: { id: string; label: string; description: string; score: number; tags: string[]; privacy: { faces: boolean; plates: boolean } }[] }>(
    '/story/moments',
    { location, moments: withImages.map(m => ({ id: m.id, time: m.peak, image: m.thumbnail })) },
  );
  const byId = new Map(labels.map(l => [l.id, l]));
  return moments.map(m => {
    const l = byId.get(m.id);
    if (!l) return m;
    return {
      ...m,
      label: l.label || m.label,
      description: l.description || m.description,
      tags: Array.from(new Set([...(l.tags || []), ...m.tags.filter(t => t === 'bookmarked')])),
      score: 0.55 * m.score + 0.45 * (l.score / 10),
      privacy: l.privacy,
      aiLabeled: true,
    };
  });
}

/** Re-pick which moments are in the reel after scores change, keeping the target length. */
export function reselect(moments: Moment[], targetSeconds: number): Moment[] {
  const ranked = [...moments].sort((a, b) => b.score - a.score);
  const chosen = new Set<string>();
  let total = 0;
  for (const m of ranked) {
    if (total >= targetSeconds - 0.5) break;
    if (chosen.size > 0 && m.score < 0.32) break;
    chosen.add(m.id);
    total += m.end - m.start;
  }
  return moments.map(m => ({ ...m, selected: chosen.has(m.id) }));
}

export async function writeStoryWithAI(input: {
  title: string; location: string; language: string; moments: Moment[]; sourceDuration: number; reelDuration: number;
}): Promise<StoryCopy> {
  const data = await postJson<Omit<StoryCopy, 'source'>>('/story/write', {
    title: input.title,
    location: input.location,
    language: input.language,
    moments: input.moments.map(m => ({ time: m.peak, label: m.label, description: m.aiLabeled ? m.description : '' })),
    stats: { sourceDuration: input.sourceDuration, reelDuration: input.reelDuration },
  });
  return { ...data, source: 'ai' };
}

/** Offline copy built only from what the analysis actually found (no invented facts). */
export function templateStory(input: {
  title: string; location: string; moments: Moment[]; sourceDuration: number; reelDuration: number;
}): StoryCopy {
  const place = input.location.trim() || 'the open road';
  const title = input.title.trim() || 'A ride to remember';
  const labels = input.moments.map(m => m.label.toLowerCase());
  const highlights = Array.from(new Set(labels)).slice(0, 3);
  const list = highlights.length > 1 ? `${highlights.slice(0, -1).join(', ')} and ${highlights.at(-1)}` : highlights[0] || 'the road ahead';
  const tagWords = place.split(/[ ,]+/).filter(Boolean).slice(0, 2).map(w => `#${w.replace(/[^\p{L}\p{N}]/gu, '')}`);
  return {
    caption: `${title} — ${formatTime(input.sourceDuration)} of riding through ${place}, cut to ${formatTime(input.reelDuration)}. Featuring ${list}.`,
    diary:
      `${title}.\n\nThis ride through ${place} produced ${formatTime(input.sourceDuration)} of footage. ` +
      `RideStory picked ${input.moments.length} moments worth keeping — ${list} — and stitched them into a ${formatTime(input.reelDuration)} reel.\n\n` +
      `Add your own notes here: who you rode with, where you stopped for chai, and what you'd tell the next rider on this route.`,
    hashtags: ['#RideStory', '#AdventureRiding', '#RideSafe', ...tagWords].filter(t => t.length > 1),
    chapters: input.moments.map(m => ({ time: m.peak, title: m.label })),
    narration: `${title}. ${place}. ${input.moments.map(m => m.label).join('. ')}.`,
    source: 'template',
  };
}

/** Upload the source video and have FFmpeg render a 1080p MP4. */
export async function renderOnServer(input: {
  file: Blob; segments: { start: number; end: number; label: string }[]; title: string; location: string; aspect: 'landscape' | 'vertical';
  onUploadProgress?: (fraction: number) => void;
}): Promise<Blob> {
  const plan = btoa(unescape(encodeURIComponent(JSON.stringify({
    segments: input.segments, title: input.title, location: input.location, aspect: input.aspect,
  }))));
  // XHR (not fetch) so we can report upload progress for multi-GB ride files.
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${API}/render`);
    xhr.responseType = 'blob';
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.setRequestHeader('X-Render-Plan', plan);
    xhr.upload.onprogress = e => { if (e.lengthComputable) input.onUploadProgress?.(e.loaded / e.total); };
    xhr.onload = async () => {
      if (xhr.status === 200) return resolve(xhr.response as Blob);
      let message = `Render failed (${xhr.status})`;
      try { message = JSON.parse(await (xhr.response as Blob).text()).error || message; } catch { /* keep default */ }
      reject(new Error(message));
    };
    xhr.onerror = () => reject(new Error('Could not reach the RideStory server'));
    xhr.send(input.file);
  });
}
