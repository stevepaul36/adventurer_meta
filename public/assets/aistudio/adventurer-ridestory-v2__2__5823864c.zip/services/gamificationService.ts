import { soundService } from '../components/game/soundService';
import type { GamificationState, DailyQuest, RiderDuel, Trophy3DData } from '../components/gamification/types';
import { USERS } from '../constants';

const STORAGE_KEY = 'adventurer_gamification_state_v1';

export const LEVEL_TITLES: { minLevel: number; title: string; color: string }[] = [
    { minLevel: 1, title: 'Novice Cruiser', color: 'text-gray-400' },
    { minLevel: 5, title: 'Canyon Scout', color: 'text-blue-400' },
    { minLevel: 10, title: 'Highway Phantom', color: 'text-purple-400' },
    { minLevel: 15, title: 'Apex Pathfinder', color: 'text-orange-400' },
    { minLevel: 25, title: 'Mountain Conqueror', color: 'text-amber-400' },
    { minLevel: 40, title: 'Legendary Adventurer', color: 'text-cyan-400' },
];

export function getLevelTitle(level: number): { title: string; color: string } {
    for (let i = LEVEL_TITLES.length - 1; i >= 0; i--) {
        if (level >= LEVEL_TITLES[i].minLevel) {
            return LEVEL_TITLES[i];
        }
    }
    return LEVEL_TITLES[0];
}

export function calculateNextLevelXp(level: number): number {
    return Math.round(500 + level * 250);
}

export const INITIAL_TROPHIES: Trophy3DData[] = [
    {
        id: 'tr_century',
        name: 'Iron Piston of Endurance',
        tier: 'gold',
        category: 'Distance',
        unlocked: true,
        unlockedAt: 'Yesterday',
        description: 'Conquered over 100 km in a single journey.',
        modelType: 'piston',
        primaryColor: 0xf59e0b,
        metalness: 0.95,
        roughness: 0.15,
    },
    {
        id: 'tr_apex_cup',
        name: 'Apex Champion Cup',
        tier: 'diamond',
        category: 'Arcade & Speed',
        unlocked: true,
        unlockedAt: 'Today',
        description: 'Exceeded 150 km/h and chained 3 near-misses.',
        modelType: 'cup',
        primaryColor: 0x38bdf8,
        metalness: 0.9,
        roughness: 0.1,
    },
    {
        id: 'tr_mountain',
        name: 'Cloud Piercer Summit',
        tier: 'silver',
        category: 'Elevation',
        unlocked: true,
        unlockedAt: '3 days ago',
        description: 'Gained over 2,000 meters in altitude climbs.',
        modelType: 'mountain',
        primaryColor: 0xcbd5e1,
        metalness: 0.85,
        roughness: 0.25,
    },
    {
        id: 'tr_helmet',
        name: 'Titan Visor of Safety',
        tier: 'bronze',
        category: 'Community',
        unlocked: false,
        description: 'Complete 10 group rides and maintain zero incidents.',
        modelType: 'helmet',
        primaryColor: 0xd97706,
        metalness: 0.7,
        roughness: 0.35,
    },
];

const DEFAULT_STATE: GamificationState = {
    level: 14,
    currentXp: 1850,
    nextLevelXp: calculateNextLevelXp(14),
    coins: 340,
    streakDays: 5,
    lastActiveDate: new Date().toISOString().split('T')[0],
    quests: [
        {
            id: 'q1',
            title: 'Dawn Canyon Blast',
            description: 'Log or simulate 15 km on your bike or GPS tracker.',
            target: 15,
            current: 12,
            unit: 'km',
            xpReward: 150,
            coinsReward: 25,
            icon: '🛣️',
            completed: false,
            claimed: false,
            category: 'ride',
        },
        {
            id: 'q2',
            title: 'Apex Speedster',
            description: 'Clock over 100 km/h in GPS Ride or Apex 3D Arcade.',
            target: 100,
            current: 100,
            unit: 'km/h',
            xpReward: 180,
            coinsReward: 30,
            icon: '⚡',
            completed: true,
            claimed: false,
            category: 'arcade',
        },
        {
            id: 'q3',
            title: 'Community Pulse',
            description: 'Share a ride run, create a post, or cheer on a friend.',
            target: 1,
            current: 1,
            unit: 'action',
            xpReward: 100,
            coinsReward: 20,
            icon: '🤝',
            completed: true,
            claimed: false,
            category: 'social',
        },
    ],
    duels: [
        {
            id: 'd1',
            opponent: USERS.u4, // Vance Velocity
            title: 'Pacific Highway 50k Clash',
            type: 'distance',
            userScore: 36,
            opponentScore: 32,
            target: 50,
            unit: 'km',
            timeLeft: '1d 14h',
            status: 'active',
            rewardXp: 350,
        },
        {
            id: 'd2',
            opponent: USERS.u2, // Mia Torque
            title: 'Peak Climber Showdown',
            type: 'elevation',
            userScore: 1200,
            opponentScore: 950,
            target: 1000,
            unit: 'm',
            timeLeft: 'Finished',
            status: 'won',
            rewardXp: 280,
        },
    ],
    unlockedTrophyIds: ['tr_century', 'tr_apex_cup', 'tr_mountain'],
    unlockedBadgeIds: [
        'moto_long_haul_bronze',
        'moto_long_haul_silver',
        'moto_mountain_master_bronze',
        'moto_mountain_master_silver',
        'cycle_endurance_bronze',
        'walk_step_champ_bronze',
        'walk_step_champ_silver',
        'hybrid_warrior_bronze',
    ],
};

class GamificationService {
    private state: GamificationState;
    private listeners: Set<(state: GamificationState) => void> = new Set();
    private pendingLevelUp: { level: number; title: string } | null = null;

    constructor() {
        this.state = this.loadState();
    }

    private loadState(): GamificationState {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                return { ...DEFAULT_STATE, ...parsed };
            }
        } catch {
            // ignore
        }
        return DEFAULT_STATE;
    }

    private saveState() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
        } catch {
            // ignore
        }
        this.notify();
    }

    private notify() {
        this.listeners.forEach((fn) => fn({ ...this.state }));
    }

    public subscribe(fn: (state: GamificationState) => void): () => void {
        this.listeners.add(fn);
        fn({ ...this.state });
        return () => this.listeners.delete(fn);
    }

    public getState(): GamificationState {
        return { ...this.state };
    }

    public getPendingLevelUp() {
        const val = this.pendingLevelUp;
        this.pendingLevelUp = null;
        return val;
    }

    /**
     * Awards XP, checks for Level Ups, and plays celebratory feedback.
     */
    public awardXp(amount: number, reason: string): { leveledUp: boolean; newLevel: number } {
        let leveledUp = false;
        let newXp = this.state.currentXp + amount;
        let currentLvl = this.state.level;
        let nextReq = this.state.nextLevelXp;

        while (newXp >= nextReq) {
            newXp -= nextReq;
            currentLvl += 1;
            nextReq = calculateNextLevelXp(currentLvl);
            leveledUp = true;
        }

        this.state.currentXp = newXp;
        this.state.level = currentLvl;
        this.state.nextLevelXp = nextReq;

        if (leveledUp) {
            const info = getLevelTitle(currentLvl);
            this.pendingLevelUp = { level: currentLvl, title: info.title };
            soundService.playStartGameFanfare();
        } else {
            soundService.playCoinChime();
        }

        this.saveState();
        return { leveledUp, newLevel: currentLvl };
    }

    /**
     * Awards Adventure Coins
     */
    public awardCoins(amount: number) {
        this.state.coins += amount;
        soundService.playCoinChime();
        this.saveState();
    }

    /**
     * Claims a completed Daily Quest reward
     */
    public claimQuest(questId: string): boolean {
        const q = this.state.quests.find((item) => item.id === questId);
        if (!q || !q.completed || q.claimed) return false;

        q.claimed = true;
        this.awardXp(q.xpReward, `Completed quest: ${q.title}`);
        this.awardCoins(q.coinsReward);
        this.saveState();
        return true;
    }

    /**
     * Claim Duel Victory
     */
    public claimDuelVictory(duelId: string): boolean {
        const d = this.state.duels.find((item) => item.id === duelId);
        if (!d || d.status !== 'won') return false;

        this.awardXp(d.rewardXp, `Won duel: ${d.title}`);
        this.awardCoins(50);
        // Remove or archive duel
        this.state.duels = this.state.duels.filter((item) => item.id !== duelId);
        this.saveState();
        return true;
    }

    /**
     * Create a new challenge duel with a friend
     */
    public createDuel(opponentId: string, title: string, type: 'distance' | 'elevation' | 'rides', target: number): RiderDuel {
        const opponent = USERS[opponentId] || USERS.u2;
        const newDuel: RiderDuel = {
            id: `duel-${Date.now()}`,
            opponent,
            title,
            type,
            userScore: 0,
            opponentScore: Math.round(target * 0.2),
            target,
            unit: type === 'distance' ? 'km' : type === 'elevation' ? 'm' : 'rides',
            timeLeft: '3 days',
            status: 'active',
            rewardXp: Math.round(target * 8),
        };

        this.state.duels = [newDuel, ...this.state.duels];
        this.saveState();
        return newDuel;
    }

    /**
     * Updates quest and duel progress when a ride or run completes
     */
    public recordActivityProgress(stats: { distanceKm: number; speedKmH: number; elevationM?: number }) {
        let changed = false;

        this.state.quests.forEach((q) => {
            if (q.category === 'ride' && !q.completed) {
                q.current = Math.min(q.target, q.current + stats.distanceKm);
                if (q.current >= q.target) {
                    q.completed = true;
                }
                changed = true;
            } else if (q.category === 'arcade' && !q.completed && stats.speedKmH >= q.target) {
                q.current = stats.speedKmH;
                q.completed = true;
                changed = true;
            }
        });

        // Update active duels
        this.state.duels.forEach((d) => {
            if (d.status === 'active') {
                if (d.type === 'distance') {
                    d.userScore = Math.min(d.target, d.userScore + stats.distanceKm);
                    if (d.userScore >= d.target && d.userScore > d.opponentScore) {
                        d.status = 'won';
                    }
                    changed = true;
                } else if (d.type === 'elevation' && stats.elevationM) {
                    d.userScore = Math.min(d.target, d.userScore + stats.elevationM);
                    if (d.userScore >= d.target && d.userScore > d.opponentScore) {
                        d.status = 'won';
                    }
                    changed = true;
                }
            }
        });

        // Award base activity XP
        const earnedXp = Math.round(stats.distanceKm * 15 + (stats.elevationM ? stats.elevationM * 0.1 : 0));
        if (earnedXp > 0) {
            this.awardXp(earnedXp, 'Logged journey ride');
        }

        if (changed) {
            this.saveState();
        }
    }
}

export const gamificationService = new GamificationService();
