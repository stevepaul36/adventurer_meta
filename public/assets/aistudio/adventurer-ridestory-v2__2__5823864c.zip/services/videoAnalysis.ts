// On-device ride-footage analysis for RideStory AI.
//
// Samples frames from the source video (nothing is uploaded), measures what makes a
// ride clip worth watching — visual change/motion, colourfulness, sharpness, open sky,
// greenery, golden-hour warmth — detects scene changes, penalises dark/idle footage,
// and picks the best non-overlapping windows to fill a target reel length.
// An optional vision-model pass (server) can then re-label and re-rank the moments.

export interface FrameSample {
  time: number;
  brightness: number;   // 0..1 mean luma
  colorfulness: number; // 0..1 (Hasler–Süsstrunk, normalised)
  sharpness: number;    // 0..1 mean |Laplacian|
  change: number;       // 0..1 mean |Δluma| vs previous sample
  warmth: number;       // -1..1 (R − B)
  sky: number;          // 0..1 share of bright/blue pixels in the top third
  green: number;        // 0..1 share of green-dominant pixels
  score: number;        // 0..1 combined, smoothed
}

export interface Moment {
  id: string;
  start: number;
  end: number;
  peak: number;
  score: number;          // 0..1 local score (blended with AI score when available)
  tags: string[];
  label: string;
  description: string;
  thumbnail?: string;     // JPEG data URL
  selected: boolean;
  aiLabeled?: boolean;
  privacy?: { faces: boolean; plates: boolean };
}

export interface AnalysisResult {
  duration: number;
  width: number;
  height: number;
  samples: FrameSample[];
  sceneCuts: number[];
  moments: Moment[];
  targetSeconds: number;
  sampleInterval: number;
}

export interface AnalyzeOptions {
  targetSeconds: number;
  bookmarks?: number[];
  onProgress?: (fraction: number, stage: string) => void;
  signal?: AbortSignal;
}

const W = 96;

// ---------------------------------------------------------------------------
// Video helpers (shared with the renderer)
// ---------------------------------------------------------------------------

/** Load a video element and resolve once metadata (including a finite duration) is known. */
export async function loadVideo(src: string, opts: { muted?: boolean } = {}): Promise<HTMLVideoElement> {
  const video = document.createElement('video');
  video.preload = 'auto';
  video.muted = opts.muted ?? true;
  video.playsInline = true;
  video.crossOrigin = 'anonymous';
  video.src = src;
  await new Promise<void>((resolve, reject) => {
    const onErr = () => reject(new Error('This video format cannot be decoded by your browser. Try an MP4 (H.264) or WebM file.'));
    video.addEventListener('loadedmetadata', () => resolve(), { once: true });
    video.addEventListener('error', onErr, { once: true });
  });
  await ensureFiniteDuration(video);
  return video;
}

/** MediaRecorder WebM files often report duration = Infinity until the end is seeked. */
export async function ensureFiniteDuration(video: HTMLVideoElement): Promise<number> {
  if (Number.isFinite(video.duration) && video.duration > 0) return video.duration;
  await new Promise<void>(resolve => {
    const done = () => {
      if (Number.isFinite(video.duration)) {
        video.removeEventListener('durationchange', done);
        video.removeEventListener('timeupdate', done);
        resolve();
      }
    };
    video.addEventListener('durationchange', done);
    video.addEventListener('timeupdate', done);
    video.currentTime = 1e101;
    window.setTimeout(resolve, 8000);
  });
  video.currentTime = 0;
  return Number.isFinite(video.duration) ? video.duration : 0;
}

export function seek(video: HTMLVideoElement, time: number, timeoutMs = 6000): Promise<void> {
  return new Promise(resolve => {
    if (Math.abs(video.currentTime - time) < 0.001 && video.readyState >= 2) return resolve();
    const timer = window.setTimeout(finish, timeoutMs);
    function finish() {
      window.clearTimeout(timer);
      video.removeEventListener('seeked', finish);
      resolve();
    }
    video.addEventListener('seeked', finish);
    video.currentTime = time;
  });
}

export function captureThumbnail(video: HTMLVideoElement, width = 384, quality = 0.78): string {
  const h = Math.round((width * (video.videoHeight || 9)) / (video.videoWidth || 16));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = h;
  canvas.getContext('2d')!.drawImage(video, 0, 0, width, h);
  return canvas.toDataURL('image/jpeg', quality);
}

// ---------------------------------------------------------------------------
// Frame metrics
// ---------------------------------------------------------------------------

function measure(data: Uint8ClampedArray, w: number, h: number, prevLuma: Float32Array | null) {
  const n = w * h;
  const luma = new Float32Array(n);
  let sumL = 0, sumR = 0, sumB = 0;
  let sumRg = 0, sumYb = 0, sumRg2 = 0, sumYb2 = 0;
  let skyCount = 0, greenCount = 0;
  const topRows = Math.floor(h / 3);

  for (let i = 0, p = 0; i < n; i++, p += 4) {
    const r = data[p], g = data[p + 1], b = data[p + 2];
    const l = 0.299 * r + 0.587 * g + 0.114 * b;
    luma[i] = l;
    sumL += l; sumR += r; sumB += b;
    const rg = r - g;
    const yb = 0.5 * (r + g) - b;
    sumRg += rg; sumYb += yb; sumRg2 += rg * rg; sumYb2 += yb * yb;
    if (g > r * 1.08 && g > b * 1.05 && g > 50) greenCount++;
    if (i < topRows * w && ((b > r * 1.05 && b > 110) || l > 200)) skyCount++;
  }

  const meanRg = sumRg / n, meanYb = sumYb / n;
  const stdRg = Math.sqrt(Math.max(0, sumRg2 / n - meanRg * meanRg));
  const stdYb = Math.sqrt(Math.max(0, sumYb2 / n - meanYb * meanYb));
  const colorfulness = Math.min(1, (Math.hypot(stdRg, stdYb) + 0.3 * Math.hypot(meanRg, meanYb)) / 110);

  let lap = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      lap += Math.abs(4 * luma[i] - luma[i - 1] - luma[i + 1] - luma[i - w] - luma[i + w]);
    }
  }
  const sharpness = Math.min(1, lap / ((w - 2) * (h - 2)) / 40);

  let change = 0;
  if (prevLuma && prevLuma.length === n) {
    let d = 0;
    for (let i = 0; i < n; i++) d += Math.abs(luma[i] - prevLuma[i]);
    change = Math.min(1, d / n / 255 * 2.2);
  }

  return {
    luma,
    brightness: sumL / n / 255,
    colorfulness,
    sharpness,
    change,
    warmth: (sumR - sumB) / n / 255,
    sky: topRows ? skyCount / (topRows * w) : 0,
    green: greenCount / n,
  };
}

function percentileRanks(values: number[]): number[] {
  const order = values.map((v, i) => [v, i] as const).sort((a, b) => a[0] - b[0]);
  const ranks = new Array(values.length).fill(0);
  order.forEach(([, idx], k) => { ranks[idx] = values.length > 1 ? k / (values.length - 1) : 0.5; });
  return ranks;
}

function tagsFor(s: FrameSample, isCut: boolean, changeRank: number, bookmarked: boolean): string[] {
  const tags: string[] = [];
  if (bookmarked) tags.push('bookmarked');
  if (s.warmth > 0.1 && s.brightness > 0.25 && s.brightness < 0.8) tags.push('golden hour');
  if (s.green > 0.3) tags.push('green valley');
  if (s.sky > 0.45) tags.push('open sky');
  if (changeRank > 0.8 && s.sharpness > 0.25) tags.push('action');
  if (isCut) tags.push('new scene');
  if (s.colorfulness > 0.55) tags.push('vivid');
  if (s.brightness < 0.16) tags.push('low light');
  return tags;
}

function labelFor(tags: string[]): string {
  if (tags.includes('bookmarked')) return 'Rider-marked moment';
  if (tags.includes('golden hour') && tags.includes('open sky')) return 'Golden-hour skyline';
  if (tags.includes('golden hour')) return 'Golden-hour stretch';
  if (tags.includes('green valley') && tags.includes('open sky')) return 'Open valley vista';
  if (tags.includes('green valley')) return 'Green valley run';
  if (tags.includes('open sky')) return 'Big-sky horizon';
  if (tags.includes('action')) return 'Action burst';
  if (tags.includes('new scene')) return 'New stretch of road';
  if (tags.includes('vivid')) return 'Colourful roadside';
  return 'On the move';
}

const fmt = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

// ---------------------------------------------------------------------------
// Main analysis
// ---------------------------------------------------------------------------

export async function analyzeVideo(src: string, options: AnalyzeOptions): Promise<AnalysisResult> {
  const { targetSeconds, bookmarks = [], onProgress, signal } = options;
  const video = await loadVideo(src);
  const duration = video.duration;
  if (!duration) throw new Error('Could not read the video duration.');

  const h = Math.max(16, Math.round((W * (video.videoHeight || 9)) / (video.videoWidth || 16)));
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!;

  const sampleInterval = Math.min(10, Math.max(0.5, duration / 320));
  const count = Math.max(2, Math.floor(duration / sampleInterval));
  const raw: Omit<FrameSample, 'score'>[] = [];
  let prev: Float32Array | null = null;

  for (let k = 0; k < count; k++) {
    if (signal?.aborted) throw new DOMException('Analysis cancelled', 'AbortError');
    const t = Math.min(duration - 0.05, (k + 0.5) * sampleInterval);
    await seek(video, t);
    ctx.drawImage(video, 0, 0, W, h);
    const m = measure(ctx.getImageData(0, 0, W, h).data, W, h, prev);
    prev = m.luma;
    raw.push({ time: t, brightness: m.brightness, colorfulness: m.colorfulness, sharpness: m.sharpness, change: m.change, warmth: m.warmth, sky: m.sky, green: m.green });
    if (k % 4 === 0) onProgress?.((k / count) * 0.8, `Scanning footage · ${fmt(t)} / ${fmt(duration)}`);
  }
  if (raw.length > 1) raw[0].change = raw[1].change;

  // --- Scene cuts: change spikes well above the local median.
  const changes = raw.map(s => s.change);
  const sorted = [...changes].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)] || 0;
  const p90 = sorted[Math.floor(sorted.length * 0.9)] || 0;
  const cutThreshold = Math.max(0.18, median * 3, p90);
  const sceneCuts = raw.filter(s => s.change >= cutThreshold).map(s => s.time);

  // --- Score
  const colorRank = percentileRanks(raw.map(s => s.colorfulness));
  const changeRank = percentileRanks(changes);
  const sharpRank = percentileRanks(raw.map(s => s.sharpness));
  const nearBookmark = (t: number) => bookmarks.some(b => Math.abs(b - t) <= Math.max(4, sampleInterval * 1.5));

  const scored = raw.map((s, i) => {
    let score =
      0.28 * colorRank[i] +
      0.24 * changeRank[i] +
      0.16 * sharpRank[i] +
      0.12 * Math.min(1, Math.max(s.sky, s.green) * 1.6) +
      0.10 * (s.warmth > 0.1 && s.brightness > 0.25 && s.brightness < 0.8 ? 1 : 0) +
      0.10 * Math.min(1, s.brightness * 2);
    if (s.brightness < 0.12) score -= 0.35;               // too dark to watch
    if (changeRank[i] < 0.12) score -= 0.08;               // idle / parked
    if (changeRank[i] > 0.9 && sharpRank[i] < 0.2) score -= 0.12; // shaky blur
    if (nearBookmark(s.time)) score += 0.5;                // rider pressed "mark moment"
    return score;
  });
  const smooth = scored.map((_, i) => {
    const a = scored[Math.max(0, i - 1)], b = scored[i], c = scored[Math.min(scored.length - 1, i + 1)];
    return Math.max(0, Math.min(1, 0.25 * a + 0.5 * b + 0.25 * c));
  });
  const samples: FrameSample[] = raw.map((s, i) => ({ ...s, score: smooth[i] }));

  // --- Choose windows
  onProgress?.(0.82, 'Choosing the best moments');
  const target = Math.min(targetSeconds, duration);
  const clipCount = duration <= target ? 1 : Math.max(3, Math.min(20, Math.round(target / 8)));
  const clipLen = duration <= target ? duration : Math.max(3, Math.min(15, target / clipCount));
  const minGap = Math.max(clipLen * 0.5, duration / (clipCount * 4));
  const order = samples.map((s, i) => i).sort((a, b) => samples[b].score - samples[a].score);
  const windows: { start: number; end: number; peakIdx: number }[] = [];

  for (const idx of order) {
    if (windows.length >= clipCount + 4) break;
    const t = samples[idx].time;
    let start = Math.max(0, Math.min(duration - clipLen, t - clipLen / 2));
    // Start on a scene change when one falls early in the window (cleaner cuts).
    const cut = sceneCuts.find(c => c > start && c < start + clipLen / 3);
    if (cut !== undefined) start = Math.min(cut + 0.1, duration - clipLen);
    const end = Math.min(duration, start + clipLen);
    const clash = windows.some(w => start < w.end + minGap && end > w.start - minGap);
    if (!clash) windows.push({ start, end, peakIdx: idx });
  }

  let total = 0;
  const moments: Moment[] = windows.map((w, rank) => {
    const peak = samples[w.peakIdx];
    const isCut = sceneCuts.some(c => c >= w.start && c <= w.end);
    const tags = tagsFor(peak, isCut, changeRank[w.peakIdx], nearBookmark(peak.time));
    // Don't pad the reel with dull footage: weak windows stay as alternates.
    const selected = total < target - 0.5 && rank < clipCount && (rank === 0 || peak.score >= 0.32);
    if (selected) total += w.end - w.start;
    return {
      id: `m${Math.round(w.start * 10)}`,
      start: round1(w.start),
      end: round1(w.end),
      peak: round1(peak.time),
      score: peak.score,
      tags,
      label: labelFor(tags),
      description: `Score ${(peak.score * 100).toFixed(0)} · colour ${(peak.colorfulness * 100).toFixed(0)} · motion ${(peak.change * 100).toFixed(0)} · sharpness ${(peak.sharpness * 100).toFixed(0)}`,
      selected,
    };
  });
  moments.sort((a, b) => a.start - b.start);

  // --- Keyframes
  for (let i = 0; i < moments.length; i++) {
    if (signal?.aborted) throw new DOMException('Analysis cancelled', 'AbortError');
    await seek(video, moments[i].peak);
    moments[i].thumbnail = captureThumbnail(video);
    onProgress?.(0.85 + (0.15 * (i + 1)) / moments.length, 'Capturing keyframes');
  }

  const result: AnalysisResult = { duration, width: video.videoWidth, height: video.videoHeight, samples, sceneCuts, moments, targetSeconds: target, sampleInterval };
  video.removeAttribute('src');
  video.load();
  return result;
}

const round1 = (n: number) => Math.round(n * 10) / 10;

export function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds)) return '0:00';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}
