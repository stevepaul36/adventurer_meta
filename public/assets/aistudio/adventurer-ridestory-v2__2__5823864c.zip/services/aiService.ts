import type { AI_Route, RideAnalysisStats, ActivityType } from '../types';

// Model credentials live on the RideStory server (server/index.mjs), never in the browser.
// The server forwards these requests to Meta Model API (or another OpenAI-compatible host).
// If the server or key is missing, every feature below falls back to curated content.
const AI_PROXY_URL =
    (import.meta as ImportMeta & { env?: Record<string, string> }).env?.VITE_AI_PROXY_URL || '/api/ai';

interface GeneratePayload {
    system?: string;
    prompt: string;
    json?: boolean;
    schema?: Record<string, unknown>;
}

async function generateContent(payload: GeneratePayload): Promise<{ text?: string }> {
    const response = await fetch(AI_PROXY_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error(`AI proxy returned ${response.status}`);
    const data = await response.json();
    if (typeof data.text !== 'string') throw new Error('AI proxy response must include a text field');
    return { text: data.text };
}

const schema = {
    title: 'string — a catchy title for the route',
    description: 'string — a brief, engaging summary highlighting key features',
    distance: 'string — estimated total distance, e.g. "150 km"',
    duration: 'string — estimated total duration, e.g. "approx. 4 hours"',
    waypoints: 'string[] — ordered key waypoints, stops or points of interest',
};

const FALLBACK_SAFETY_TIPS: Record<string, string[]> = {
    General: [
        "Always look where you want the bike to go, not at what you are trying to avoid; your body naturally follows your eyes.",
        "Scan 12 seconds ahead through intersections and never ride in a vehicle's blind spot.",
        "Check your cold tire pressures before every trip; your tires are your only contact patch with the road.",
        "Dress for the slide, not for the ride: quality armor, abrasion-resistant gear, and boots make all the difference.",
    ],
    Highway: [
        "Ride in the dominant wheel track of your lane to maximize visibility and avoid center-lane oil slicks.",
        "Anticipate sudden crosswinds and turbulent wind buffeting when passing high-profile trucks.",
    ],
    Night: [
        "Reduce your speed so your total stopping distance never exceeds the reach of your headlights.",
        "Look for reflective wildlife eyes along shoulders during dawn, dusk, and wooded passes.",
    ],
    Rain: [
        "Smooth out every brake and throttle input—painted lane markings and steel manhole covers turn as slick as ice when wet.",
    ],
    Canyon: [
        "Set your corner entry speed before leaning in, and roll smoothly onto the throttle through the apex.",
        "Beware of gravel and debris washed into turn apexes after seasonal storms.",
    ],
};

export const generateRoute = async (prompt: string, activityMode: ActivityType, difficulty: string): Promise<AI_Route> => {
    try {
        const systemInstruction = `You are an expert route planner for ${activityMode}. Your task is to create an exciting and practical journey based on the user's request. You must respond with a JSON object that adheres to the provided schema.`;
        const userPrompt = `${prompt} The route should be suitable for ${activityMode} and have a difficulty level of ${difficulty}.`;

        const response = await generateContent({ system: systemInstruction, prompt: userPrompt, json: true, schema });
        
        const jsonText = response.text ? response.text.trim() : "";
        if (!jsonText) {
             throw new Error("Received an empty response from the AI.");
        }
        
        const routeData: AI_Route = JSON.parse(jsonText);
        return routeData;
    } catch (error) {
        console.warn("Error generating route with the AI model, using curated fallback:", error);
        return {
            title: `${activityMode} Canyon Scenic Loop`,
            description: `A hand-curated ${difficulty.toLowerCase()} route tailored for ${activityMode}, featuring sweeping panoramic turns, clean asphalt, and scenic overlooks.`,
            distance: "85 km",
            duration: "2h 15m",
            waypoints: [
                "Valley Vista Staging Post",
                "Pinecrest Mountain Pass",
                "Red Rock Overlook & Fuel Stop",
                "Canyon Dam Lookout",
                "Meadow Creek Return Waypoint"
            ]
        };
    }
};

export const generateGroupJourney = async (prompt: string, activityMode: ActivityType, groupSize: number): Promise<AI_Route> => {
     try {
        const systemInstruction = `You are an expert route planner for group ${activityMode} activities. Create an exciting journey suitable for a group of ${groupSize} people. The route should include good meeting points, scenic paths, and appropriate stops for a group. You must respond with a JSON object that adheres to the provided schema.`;
        
        const response = await generateContent({ system: systemInstruction, prompt: prompt, json: true, schema });
        
        const jsonText = response.text ? response.text.trim() : "";
        if (!jsonText) {
             throw new Error("Received an empty response from the AI.");
        }
        
        const routeData: AI_Route = JSON.parse(jsonText);
        return routeData;
    } catch (error) {
        console.warn("Error generating group journey with the AI model, using curated fallback:", error);
        return {
            title: `Group ${activityMode} Expedition for ${groupSize}`,
            description: `Specially planned for a group of ${groupSize} participants with wide staging lanes, organized regrouping rest stops, and picturesque scenic vistas.`,
            distance: "120 km",
            duration: "3h 30m",
            waypoints: [
                "Grand Central Muster Point (Wide Parking)",
                "Crestline Ridge Overlook",
                "Timberline Cafe Regroup Stop",
                "Summit Highway Stretch",
                "Basecamp Club Pavilion"
            ]
        };
    }
};

export const generateSafetyTip = async (context?: string): Promise<string> => {
    const key = context || 'General';
    const fallbackList = FALLBACK_SAFETY_TIPS[key] || FALLBACK_SAFETY_TIPS.General;
    const fallbackTip = fallbackList[Math.floor(Math.random() * fallbackList.length)];

    try {
        const prompt = `Provide a concise, actionable motorcycle safety tip. ${context ? `The tip should be relevant for a rider who is focused on: ${context}.` : 'Focus on a general, important safety principle.'} The tip should be easy to read and understand quickly. Do not include any introductory phrases like "Here's a tip:". Only return the tip itself.`;

        const response = await generateContent({ system: "You are a motorcycle safety expert providing helpful tips to riders. Be clear, concise, and encouraging. Your response should only be the tip itself, with no extra formatting or conversational text.", prompt: prompt });
        
        const tip = response.text ? response.text.trim() : "";
        if (!tip) {
            return fallbackTip;
        }
        return tip;
    } catch (error) {
        console.warn("Using curated safety tip fallback:", error);
        return fallbackTip;
    }
};

export const generateRideInsights = async (stats: RideAnalysisStats): Promise<string> => {
    try {
        const prompt = `Analyze the following motorcycle ride data and provide a short, positive, and encouraging summary (2-3 sentences) for the rider. Focus on their achievement. Here is the data:
- Distance: ${stats.distance} km
- Duration: ${stats.duration}
- Average Speed: ${stats.speed} km/h`;

        const response = await generateContent({ system: "You are a friendly and encouraging motorcycle companion AI. Your tone should be positive and celebratory. Do not just repeat the stats; interpret them in an uplifting way for a rider.", prompt: prompt });

        const insights = response.text ? response.text.trim() : "";
        if (!insights) {
            throw new Error("Received empty insights from AI.");
        }
        return insights;
    } catch (error) {
        console.warn("Using fallback ride insights:", error);
        return `Awesome effort logging ${stats.distance} km at an average speed of ${stats.speed} km/h over ${stats.duration}! You maintained great consistency and built valuable endurance toward your riding goals.`;
    }
};