// In-browser highlight-reel renderer: plays each selected segment into a canvas,
// adds a title card, lower-third labels and an end card, and records the result
// with MediaRecorder (MP4 where the browser supports it, otherwise WebM).
// Works with no server at all; the FFmpeg server path is faster for long reels.

import { loadVideo, seek } from './videoAnalysis';

export interface ReelSegment { start: number; end: number; label: string }

export interface RenderOptions {
  src: string;
  segments: ReelSegment[];
  title: string;
  location: string;
  endLines: string[];
  aspect: 'landscape' | 'vertical';
  onProgress?: (fraction: number, stage: string) => void;
  signal?: AbortSignal;
}

export interface RenderResult { blob: Blob; mimeType: string; extension: 'mp4' | 'webm' }

const MIME_CANDIDATES = [
  'video/mp4;codecs=avc1.42E01E,mp4a.40.2', // H.264 MP4 — plays everywhere (Chrome 126+, Safari)
  'video/mp4;codecs=avc1',
  'video/webm;codecs=vp9,opus',
  'video/webm;codecs=vp8,opus',
  'video/webm',
];

export function browserCanRender(): boolean {
  return typeof MediaRecorder !== 'undefined' && typeof HTMLCanvasElement.prototype.captureStream === 'function';
}

export async function renderReelInBrowser(opts: RenderOptions): Promise<RenderResult> {
  if (!browserCanRender()) throw new Error('This browser cannot record canvas video. Use Chrome, Edge or Firefox, or render on the server.');
  const { segments, title, location, endLines, aspect, onProgress, signal } = opts;
  const mimeType = MIME_CANDIDATES.find(t => MediaRecorder.isTypeSupported(t)) || '';
  const extension: 'mp4' | 'webm' = mimeType.includes('mp4') ? 'mp4' : 'webm';

  const video = await loadVideo(opts.src, { muted: false });
  const W = aspect === 'vertical' ? 720 : 1280;
  const H = aspect === 'vertical' ? 1280 : 720;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;

  // Route the clip audio into the recording (and away from the speakers).
  const stream = canvas.captureStream(30);
  let audioCtx: AudioContext | null = null;
  try {
    audioCtx = new AudioContext();
    const source = audioCtx.createMediaElementSource(video);
    const dest = audioCtx.createMediaStreamDestination();
    source.connect(dest);
    dest.stream.getAudioTracks().forEach(track => stream.addTrack(track));
    await audioCtx.resume();
  } catch {
    video.muted = true; // silent reel rather than failing
  }

  const recorder = new MediaRecorder(stream, { mimeType: mimeType || undefined, videoBitsPerSecond: 6_000_000 });
  const chunks: Blob[] = [];
  recorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
  const stopped = new Promise<void>(resolve => { recorder.onstop = () => resolve(); });

  const totalSeconds = segments.reduce((s, x) => s + (x.end - x.start), 0) + 5;
  let elapsed = 0;
  const abortIfNeeded = () => { if (signal?.aborted) throw new DOMException('Render cancelled', 'AbortError'); };

  const drawCover = () => {
    const vw = video.videoWidth || W, vh = video.videoHeight || H;
    const scale = Math.max(W / vw, H / vh);
    const dw = vw * scale, dh = vh * scale;
    ctx.drawImage(video, (W - dw) / 2, (H - dh) / 2, dw, dh);
  };

  const drawCard = (heading: string, sub: string, lines: string[], alpha: number) => {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#0f172a');
    g.addColorStop(1, '#431407');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = alpha;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#f97316';
    ctx.font = `800 ${Math.round(W * 0.018)}px system-ui, sans-serif`;
    ctx.fillText('RIDESTORY AI', W / 2, H * 0.36);
    ctx.fillStyle = '#ffffff';
    ctx.font = `800 ${Math.round(W * (aspect === 'vertical' ? 0.07 : 0.05))}px system-ui, sans-serif`;
    wrap(heading, W * 0.84).forEach((line, i) => ctx.fillText(line, W / 2, H * 0.47 + i * W * 0.065));
    ctx.fillStyle = '#fbbf24';
    ctx.font = `600 ${Math.round(W * (aspect === 'vertical' ? 0.04 : 0.025))}px system-ui, sans-serif`;
    ctx.fillText(sub, W / 2, H * 0.62);
    ctx.fillStyle = '#cbd5e1';
    ctx.font = `500 ${Math.round(W * (aspect === 'vertical' ? 0.032 : 0.02))}px system-ui, sans-serif`;
    lines.forEach((line, i) => ctx.fillText(line, W / 2, H * 0.7 + i * W * 0.04));
    ctx.globalAlpha = 1;
  };

  const wrap = (text: string, max: number) => {
    const words = text.split(/\s+/);
    const out: string[] = [];
    let line = '';
    for (const w of words) {
      const test = line ? `${line} ${w}` : w;
      if (ctx.measureText(test).width > max && line) { out.push(line); line = w; } else line = test;
    }
    if (line) out.push(line);
    return out.slice(0, 3);
  };

  const drawLowerThird = (label: string, index: number, t: number) => {
    const pad = W * 0.03;
    const fade = Math.min(1, t / 0.4);
    ctx.globalAlpha = fade;
    ctx.fillStyle = 'rgba(2,6,23,0.62)';
    ctx.font = `700 ${Math.round(W * (aspect === 'vertical' ? 0.04 : 0.024))}px system-ui, sans-serif`;
    const text = `${index + 1}/${segments.length} · ${label}`;
    const tw = ctx.measureText(text).width;
    const bh = W * (aspect === 'vertical' ? 0.07 : 0.045);
    ctx.fillRect(pad, H - pad - bh, tw + pad * 1.4, bh);
    ctx.fillStyle = '#f97316';
    ctx.fillRect(pad, H - pad - bh, W * 0.006, bh);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, pad + pad * 0.7, H - pad - bh / 2);
    ctx.textBaseline = 'alphabetic';
    ctx.globalAlpha = 1;
    // progress bar
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.fillRect(0, 0, W, 5);
    ctx.fillStyle = '#f97316';
    ctx.fillRect(0, 0, W * Math.min(1, elapsed / totalSeconds), 5);
  };

  const holdCard = async (seconds: number, heading: string, sub: string, lines: string[]) => {
    const start = performance.now();
    while ((performance.now() - start) / 1000 < seconds) {
      abortIfNeeded();
      const t = (performance.now() - start) / 1000;
      drawCard(heading, sub, lines, Math.min(1, t / 0.5, (seconds - t) / 0.4));
      await frame();
    }
    elapsed += seconds;
  };

  recorder.start(1000);
  try {
    onProgress?.(0, 'Title card');
    await holdCard(2.5, title || 'My ride story', location, []);

    for (let i = 0; i < segments.length; i++) {
      abortIfNeeded();
      const seg = segments[i];
      onProgress?.(elapsed / totalSeconds, `Recording clip ${i + 1} of ${segments.length}`);
      await seek(video, seg.start);
      await video.play();
      const segStartWall = performance.now();
      const segLen = seg.end - seg.start;
      while (!video.ended && video.currentTime < seg.end && (performance.now() - segStartWall) / 1000 < segLen + 3) {
        abortIfNeeded();
        drawCover();
        const t = video.currentTime - seg.start;
        // short fade in/out at clip edges
        const edge = Math.min(t, seg.end - video.currentTime);
        if (edge < 0.25) { ctx.fillStyle = `rgba(0,0,0,${1 - edge / 0.25})`; ctx.fillRect(0, 0, W, H); }
        drawLowerThird(seg.label, i, t);
        onProgress?.(Math.min(0.99, (elapsed + t) / totalSeconds), `Recording clip ${i + 1} of ${segments.length}`);
        await frame();
      }
      video.pause();
      elapsed += segLen;
    }

    onProgress?.(0.97, 'End card');
    await holdCard(2.5, title || 'My ride story', location, endLines.slice(0, 3));
  } finally {
    if (recorder.state !== 'inactive') recorder.stop();
    await stopped;
    stream.getTracks().forEach(t => t.stop());
    video.pause();
    video.removeAttribute('src');
    video.load();
    audioCtx?.close().catch(() => {});
  }

  onProgress?.(1, 'Done');
  return { blob: new Blob(chunks, { type: mimeType || 'video/webm' }), mimeType: mimeType || 'video/webm', extension };
}

/** rAF when visible; a timer when the tab is hidden (rAF pauses in background tabs). */
function frame(): Promise<void> {
  return new Promise(resolve => {
    if (document.visibilityState === 'visible') requestAnimationFrame(() => resolve());
    else window.setTimeout(resolve, 33);
  });
}
