// RideStory AI backend — zero external dependencies (Node 20+ built-ins only).
//
//  • Keeps model credentials on the server (never in the browser bundle).
//  • Talks to Meta Model API (OpenAI-compatible chat completions) or any other
//    OpenAI-compatible host serving Meta open-weights models (Fireworks, Baseten, Modal…).
//  • Renders highlight reels with FFmpeg when it is installed.
//  • In production (`npm run build && npm start`) it also serves the built app from /dist.

import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { pipeline } from 'node:stream/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

loadEnvFile(path.join(ROOT, '.env'));
loadEnvFile(path.join(ROOT, '.env.local'));

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const API_KEY = process.env.MODEL_API_KEY || process.env.META_API_KEY || '';
const API_BASE = (process.env.MODEL_API_BASE_URL || 'https://api.meta.ai/v1').replace(/\/+$/, '');
const TEXT_MODEL = process.env.MODEL_TEXT || 'muse-spark-1.3';
const VISION_MODEL = process.env.MODEL_VISION || TEXT_MODEL;
const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
const FFPROBE = process.env.FFPROBE_PATH || 'ffprobe';
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 4096);
const MAX_JSON_MB = 30;
const DIST = path.join(ROOT, 'dist');

let ffmpegAvailable = false;

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (!m || line.trim().startsWith('#')) continue;
    const value = m[2].replace(/^['"]|['"]$/g, '');
    if (!(m[1] in process.env)) process.env[m[1]] = value;
  }
}

function sendJson(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(data);
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_JSON_MB * 1024 * 1024) throw Object.assign(new Error('Request body too large'), { status: 413 });
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
  } catch {
    throw Object.assign(new Error('Invalid JSON body'), { status: 400 });
  }
}

function run(cmd, args, { timeoutMs = 30 * 60 * 1000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => child.kill('SIGKILL'), timeoutMs);
    child.stdout.on('data', d => { stdout += d; });
    child.stderr.on('data', d => { stderr = (stderr + d).slice(-8000); });
    child.on('error', err => { clearTimeout(timer); reject(err); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code === 0) resolve({ stdout, stderr });
      else reject(Object.assign(new Error(`${cmd} exited with code ${code}`), { stderr }));
    });
  });
}

/** Pull the first JSON object/array out of a model reply (handles ```json fences and chatter). */
function extractJson(text) {
  if (!text) throw new Error('Empty model response');
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.search(/[[{]/);
  if (start < 0) throw new Error('No JSON found in model response');
  const open = candidate[start];
  const close = open === '{' ? '}' : ']';
  let depth = 0, inString = false, escaped = false;
  for (let i = start; i < candidate.length; i++) {
    const ch = candidate[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === open) depth++;
    else if (ch === close && --depth === 0) return JSON.parse(candidate.slice(start, i + 1));
  }
  throw new Error('Unterminated JSON in model response');
}

const clampText = (value, max) => String(value ?? '').slice(0, max);

// ---------------------------------------------------------------------------
// Meta Model API (OpenAI-compatible chat completions)
// ---------------------------------------------------------------------------

async function chat({ model = TEXT_MODEL, messages, temperature = 0.7, maxTokens = 1200 }) {
  if (!API_KEY) throw Object.assign(new Error('MODEL_API_KEY is not set on the server'), { status: 503 });
  const response = await fetch(`${API_BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${API_KEY}` },
    body: JSON.stringify({ model, messages, temperature, max_tokens: maxTokens }),
    signal: AbortSignal.timeout(120_000),
  });
  const raw = await response.text();
  if (!response.ok) {
    throw Object.assign(new Error(`Model API ${response.status}: ${raw.slice(0, 400)}`), { status: 502 });
  }
  const data = JSON.parse(raw);
  const content = data?.choices?.[0]?.message?.content;
  if (Array.isArray(content)) return content.map(part => part?.text ?? '').join('');
  return typeof content === 'string' ? content : '';
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

async function handleHealth(_req, res) {
  sendJson(res, 200, {
    ok: true,
    ai: { configured: Boolean(API_KEY), provider: API_BASE.includes('meta.ai') ? 'Meta Model API' : 'OpenAI-compatible', textModel: TEXT_MODEL, visionModel: VISION_MODEL },
    ffmpeg: ffmpegAvailable,
  });
}

/** Generic text generation used by route planner, safety tips and ride insights. */
async function handleAi(req, res) {
  const body = await readJson(req);
  const system = clampText(body.system, 4000);
  const prompt = clampText(body.prompt, 12000);
  if (!prompt) return sendJson(res, 400, { error: 'prompt is required' });
  const messages = [];
  if (system || body.json) {
    messages.push({ role: 'system', content: `${system}${body.json ? `\nRespond with ONLY valid JSON, no markdown.${body.schema ? ` JSON shape: ${JSON.stringify(body.schema)}` : ''}` : ''}` });
  }
  messages.push({ role: 'user', content: prompt });
  let text = await chat({ messages, temperature: body.json ? 0.4 : 0.7 });
  if (body.json) text = JSON.stringify(extractJson(text));
  sendJson(res, 200, { text });
}

/** Vision pass: label candidate ride moments from keyframes. */
async function handleMoments(req, res) {
  const body = await readJson(req);
  const moments = Array.isArray(body.moments) ? body.moments.slice(0, 16) : [];
  if (!moments.length) return sendJson(res, 400, { error: 'moments[] is required' });
  for (const m of moments) {
    if (typeof m.image !== 'string' || !m.image.startsWith('data:image/')) {
      return sendJson(res, 400, { error: 'each moment needs a data:image/* keyframe' });
    }
  }
  const location = clampText(body.location, 120) || 'unknown';
  const content = [
    {
      type: 'text',
      text:
        `You are the editor for RideStory AI, which turns long motorcycle/bicycle ride footage into short highlight reels. ` +
        `The ride took place around: ${location}. Below are ${moments.length} keyframes, each from a candidate moment. ` +
        `For every image return an object with: "index" (1-based), "label" (3-6 words, vivid, no emojis), ` +
        `"description" (one sentence of what is visible), "score" (0-10: how good this moment is for a highlight reel — scenery, action, emotion, clarity), ` +
        `"tags" (up to 4 lowercase words like scenic, mountains, coast, forest, city, group, action, food-stop, landmark, sunset, rain, night), ` +
        `"privacy" ({"faces": boolean, "plates": boolean} — whether identifiable faces or readable licence plates are visible). ` +
        `Return ONLY a JSON array.`,
    },
  ];
  moments.forEach((m, i) => {
    content.push({ type: 'text', text: `Image ${i + 1} — t=${Math.round(Number(m.time) || 0)}s` });
    content.push({ type: 'image_url', image_url: { url: m.image } });
  });
  const text = await chat({ model: VISION_MODEL, messages: [{ role: 'user', content }], temperature: 0.3, maxTokens: 2000 });
  const parsed = extractJson(text);
  const list = Array.isArray(parsed) ? parsed : parsed.moments || [];
  const labels = list
    .map(item => {
      const index = Number(item.index) - 1;
      const source = moments[index];
      if (!source) return null;
      return {
        id: source.id,
        label: clampText(item.label, 60),
        description: clampText(item.description, 240),
        score: Math.max(0, Math.min(10, Number(item.score) || 0)),
        tags: Array.isArray(item.tags) ? item.tags.slice(0, 4).map(t => clampText(t, 20)) : [],
        privacy: { faces: Boolean(item.privacy?.faces), plates: Boolean(item.privacy?.plates) },
      };
    })
    .filter(Boolean);
  sendJson(res, 200, { model: VISION_MODEL, labels });
}

/** Write caption, diary, hashtags and chapter titles from the selected moments. */
async function handleWrite(req, res) {
  const body = await readJson(req);
  const language = clampText(body.language, 30) || 'English';
  const moments = (Array.isArray(body.moments) ? body.moments : []).slice(0, 24).map(m => ({
    time: Math.round(Number(m.time) || 0),
    label: clampText(m.label, 80),
    description: clampText(m.description, 240),
  }));
  const prompt =
    `Write social copy for a ride highlight reel.\n` +
    `Title: ${clampText(body.title, 120)}\nLocation: ${clampText(body.location, 120)}\n` +
    `Source footage: ${Math.round(Number(body.stats?.sourceDuration) || 0)} s; reel: ${Math.round(Number(body.stats?.reelDuration) || 0)} s; clips: ${moments.length}.\n` +
    `Moments in order:\n${moments.map(m => `- ${m.time}s: ${m.label}${m.description ? ` — ${m.description}` : ''}`).join('\n')}\n\n` +
    `Write everything in ${language}. Be warm and specific to the moments; do not invent facts such as altitudes, speeds or names that are not given. ` +
    `Return ONLY JSON: {"caption": string (max 280 chars), "diary": string (2-3 short paragraphs), "hashtags": string[] (5-8, no spaces), ` +
    `"chapters": [{"time": number, "title": string}] (one per moment), "narration": string (a 20-40 second voice-over script)}`;
  const text = await chat({
    messages: [
      { role: 'system', content: 'You are a travel storyteller for adventure riders in India and beyond. Respond with ONLY valid JSON.' },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    maxTokens: 1500,
  });
  const story = extractJson(text);
  sendJson(res, 200, {
    model: TEXT_MODEL,
    caption: clampText(story.caption, 600),
    diary: clampText(story.diary, 4000),
    hashtags: Array.isArray(story.hashtags) ? story.hashtags.slice(0, 10).map(h => clampText(h, 40)) : [],
    chapters: Array.isArray(story.chapters) ? story.chapters.slice(0, 24).map(c => ({ time: Number(c.time) || 0, title: clampText(c.title, 80) })) : [],
    narration: clampText(story.narration, 2000),
  });
}

/**
 * Render an MP4 highlight reel with FFmpeg.
 * Body: raw video bytes. Header `X-Render-Plan`: base64 JSON
 *   { segments: [{start, end, label?}], title?, location?, aspect?: 'landscape' | 'vertical' }
 */
async function handleRender(req, res) {
  if (!ffmpegAvailable) return sendJson(res, 503, { error: 'FFmpeg is not installed on the server' });
  let plan;
  try {
    plan = JSON.parse(Buffer.from(String(req.headers['x-render-plan'] || ''), 'base64').toString('utf8'));
  } catch {
    return sendJson(res, 400, { error: 'X-Render-Plan header must be base64-encoded JSON' });
  }
  const segments = (Array.isArray(plan.segments) ? plan.segments : [])
    .map(s => ({ start: Math.max(0, Number(s.start) || 0), end: Number(s.end) || 0, label: clampText(s.label, 60) }))
    .filter(s => s.end - s.start >= 0.5)
    .slice(0, 30);
  if (!segments.length) return sendJson(res, 400, { error: 'plan.segments must contain at least one segment' });
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > MAX_UPLOAD_MB * 1024 * 1024) return sendJson(res, 413, { error: `Upload exceeds ${MAX_UPLOAD_MB} MB` });

  const workDir = await fsp.mkdtemp(path.join(os.tmpdir(), 'ridestory-'));
  const input = path.join(workDir, 'source');
  const output = path.join(workDir, 'reel.mp4');
  try {
    let received = 0;
    req.on('data', chunk => {
      received += chunk.length;
      if (received > MAX_UPLOAD_MB * 1024 * 1024) req.destroy(new Error('Upload too large'));
    });
    await pipeline(req, fs.createWriteStream(input));

    const { stdout } = await run(FFPROBE, ['-v', 'error', '-show_entries', 'stream=codec_type', '-of', 'csv=p=0', input], { timeoutMs: 60_000 });
    const hasAudio = stdout.split(/\s+/).includes('audio');
    const vertical = plan.aspect === 'vertical';
    const W = vertical ? 1080 : 1920;
    const H = vertical ? 1920 : 1080;

    const args = ['-y', '-hide_banner', '-loglevel', 'error'];
    segments.forEach(s => args.push('-ss', s.start.toFixed(3), '-t', (s.end - s.start).toFixed(3), '-i', input));
    const filters = [];
    const concatInputs = [];
    segments.forEach((_, i) => {
      filters.push(`[${i}:v]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=30,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[v${i}]`);
      if (hasAudio) filters.push(`[${i}:a]aresample=48000,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a${i}]`);
      concatInputs.push(hasAudio ? `[v${i}][a${i}]` : `[v${i}]`);
    });
    filters.push(`${concatInputs.join('')}concat=n=${segments.length}:v=1:a=${hasAudio ? 1 : 0}[vcat]${hasAudio ? '[aout]' : ''}`);

    const safe = text => String(text || '').replace(/[\\':%"\n\r]/g, ' ').trim().slice(0, 60);
    const title = safe(plan.title);
    const location = safe(plan.location);
    const overlay =
      `[vcat]drawtext=text='${title}':fontcolor=white:fontsize=${vertical ? 72 : 64}:x=(w-tw)/2:y=h*0.72:box=1:boxcolor=black@0.45:boxborderw=24:enable='lt(t,3.5)',` +
      `drawtext=text='${location}':fontcolor=0xFBBF24:fontsize=${vertical ? 44 : 38}:x=(w-tw)/2:y=h*0.72+${vertical ? 120 : 100}:enable='lt(t,3.5)'[vout]`;

    const encode = (withText) => {
      const graph = [...filters, withText && title ? overlay : '[vcat]null[vout]'].join(';');
      return run(FFMPEG, [
        ...args,
        '-filter_complex', graph,
        '-map', '[vout]', ...(hasAudio ? ['-map', '[aout]', '-c:a', 'aac', '-b:a', '160k'] : []),
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-movflags', '+faststart', output,
      ]);
    };
    try {
      await encode(true);
    } catch (err) {
      // drawtext needs fontconfig/freetype; fall back to a clean render without titles.
      console.warn('[render] text overlay failed, retrying without it:', err.stderr?.slice(-300) || err.message);
      await encode(false);
    }

    const stat = await fsp.stat(output);
    res.writeHead(200, {
      'Content-Type': 'video/mp4',
      'Content-Length': stat.size,
      'Content-Disposition': 'attachment; filename="ridestory-reel.mp4"',
      'Cache-Control': 'no-store',
    });
    await pipeline(fs.createReadStream(output), res);
  } finally {
    fsp.rm(workDir, { recursive: true, force: true }).catch(() => {});
  }
}

// ---------------------------------------------------------------------------
// Static hosting for the production build
// ---------------------------------------------------------------------------

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.json': 'application/json', '.ico': 'image/x-icon', '.webp': 'image/webp', '.woff2': 'font/woff2' };

async function serveStatic(req, res) {
  if (!fs.existsSync(DIST)) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    return res.end('RideStory API is running. Start the web app with `npm run dev`, or run `npm run build` to serve it from here.');
  }
  const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  let file = path.normalize(path.join(DIST, urlPath));
  if (!file.startsWith(DIST)) { res.writeHead(403); return res.end(); }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, 'index.html');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------

const routes = {
  'GET /api/health': handleHealth,
  'POST /api/ai': handleAi,
  'POST /api/story/moments': handleMoments,
  'POST /api/story/write': handleWrite,
  'POST /api/render': handleRender,
};

const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://x').pathname;
  const handler = routes[`${req.method} ${pathname}`];
  const started = Date.now();
  try {
    if (handler) await handler(req, res);
    else if (pathname.startsWith('/api/')) sendJson(res, 404, { error: 'Not found' });
    else if (req.method === 'GET') await serveStatic(req, res);
    else sendJson(res, 405, { error: 'Method not allowed' });
  } catch (err) {
    const status = err.status || 500;
    console.error(`[${req.method} ${pathname}]`, err.message);
    if (!res.headersSent) sendJson(res, status, { error: err.message || 'Server error' });
    else res.destroy();
  } finally {
    if (pathname.startsWith('/api/')) console.log(`${req.method} ${pathname} ${res.statusCode} ${Date.now() - started}ms`);
  }
});
server.requestTimeout = 0; // long uploads/renders

run(FFMPEG, ['-version'], { timeoutMs: 10_000 })
  .then(() => { ffmpegAvailable = true; })
  .catch(() => { ffmpegAvailable = false; })
  .finally(() => {
    server.listen(PORT, HOST, () => {
      console.log(`RideStory API on http://${HOST}:${PORT}`);
      console.log(`  model API : ${API_KEY ? `${API_BASE} (${TEXT_MODEL} / ${VISION_MODEL})` : 'not configured — set MODEL_API_KEY in .env'}`);
      console.log(`  ffmpeg    : ${ffmpegAvailable ? 'available' : 'not found — browser rendering only'}`);
    });
  });

