
import React, { useState, useMemo, useRef, useEffect } from 'react';
import Dashboard from './components/Dashboard';
import StreamsPanel from './components/StreamsPanel';
import StreamViewer from './components/StreamViewer';
import ShotsPanel from './components/ShotsPanel';
import MessagesPanel from './components/MessagesPanel';
import NotificationsPanel from './components/NotificationsPanel';
import ProfilePanel from './components/ProfilePanel';
import GpsTracker from './components/GpsTracker';
import JourneyPlanner from './components/JourneyPlanner';
import LeaderboardsPanel from './components/LeaderboardsPanel';
import ClubPanel from './components/ClubPanel';
import RideStory from './components/RideStory';
import CreatePost from './components/CreatePost';
import FriendRequestsPanel from './components/FriendRequestsPanel';
import ApexMotoGame from './components/game/ApexMotoGame';
import { GamificationHub } from './components/gamification/GamificationHub';
import { gamificationService } from './services/gamificationService';
import { IndiaExpeditions } from './components/india/IndiaExpeditions';
import { IndiaRoadsideRadar } from './components/india/IndiaRoadsideRadar';
import { TripBudgetModal } from './components/india/TripBudgetModal';
import { AiStoryStudioModal } from './components/india/AiStoryStudioModal';
import { ArchitectureModal } from './components/india/ArchitectureModal';
import { SUPPORTED_LANGUAGES, type SupportedLanguage, getTranslation } from './services/i18nService';
import { 
    HomeIcon, StreamIcon, MessageIcon, ProfileIcon, PlusIcon, RouteIcon, NotificationIcon, 
    UsersIcon, TrophyIcon, ShortsIcon, LogoIcon, ClubIcon, PencilIcon, MapPinIcon, 
    GamepadIcon, FlameIcon, CompassIcon, ShieldAlertIcon, RupeeIcon, SparklesIcon, 
    ArchitectureIcon, TranslateIcon 
} from './components/icons';
import type { Stream, ActivityType, RideStory as RideStoryType, FeedItem, Post, FriendRequest } from './types';
import { CONVERSATIONS, CURRENT_USER, FEED_ITEMS, FRIEND_REQUESTS, PROFILES } from './constants';

type View = 'home' | 'expeditions' | 'radar' | 'streams' | 'shots' | 'clubs' | 'leaderboards' | 'messages' | 'notifications' | 'profile';

const App: React.FC = () => {
    const [activeView, setActiveView] = useState<View>('home');
    const [language, setLanguage] = useState<SupportedLanguage>('en');
    const [showLangMenu, setShowLangMenu] = useState(false);
    const [showArchitectureModal, setShowArchitectureModal] = useState(false);
    const [showBudgetModal, setShowBudgetModal] = useState(false);
    const [showStoryStudio, setShowStoryStudio] = useState(false);
    const [activityMode, setActivityMode] = useState<ActivityType>('Motorcycling');
    const [selectedStream, setSelectedStream] = useState<Stream | null>(null);
    const [selectedRideStory, setSelectedRideStory] = useState<RideStoryType | null>(null);
    const [showGps, setShowGps] = useState(false);
    const [showJourneyPlanner, setShowJourneyPlanner] = useState(false);
    const [showCreateMenu, setShowCreateMenu] = useState(false);
    const [viewedProfileId, setViewedProfileId] = useState<string | null>(null);
    const [feedItems, setFeedItems] = useState<FeedItem[]>(FEED_ITEMS);
    const [showCreatePost, setShowCreatePost] = useState(false);
    const [showFriendsPanel, setShowFriendsPanel] = useState(false);
    const [showGame, setShowGame] = useState(false);
    const [showGamificationHub, setShowGamificationHub] = useState(false);
    const [riderGamification, setRiderGamification] = useState(gamificationService.getState());

    useEffect(() => {
        const unsub = gamificationService.subscribe((updated) => {
            setRiderGamification(updated);
        });
        return () => unsub();
    }, []);

    const handleShareGameRun = (stats: { distanceKm: number; topSpeedKmH: number; score: number }) => {
        gamificationService.recordActivityProgress({
            distanceKm: stats.distanceKm,
            speedKmH: stats.topSpeedKmH,
            elevationM: 320,
        });
        const newPost: Post = {
            id: `game-run-${Date.now()}`,
            user: CURRENT_USER,
            timestamp: 'Just now',
            date: new Date(),
            caption: `🔥 Just carved the canyon in Apex Moto 3D! Scored ${stats.score.toLocaleString()} pts with top speed of ${stats.topSpeedKmH} km/h over ${stats.distanceKm} km! Who's taking on the challenge? 🏍️💨`,
            rideStats: {
                distance: stats.distanceKm,
                duration: `${Math.max(1, Math.round(stats.distanceKm * 0.8))}m 12s`,
                elevation: Math.round(stats.distanceKm * 32),
            },
            likes: 1,
            comments: [],
        };
        handleAddPost(newPost);
    };

    // Friend System State
    const [friends, setFriends] = useState<string[]>(PROFILES[CURRENT_USER.id].friends);
    const [friendRequests, setFriendRequests] = useState<FriendRequest[]>(FRIEND_REQUESTS);
    const [sentRequests, setSentRequests] = useState<string[]>([]); // To track outgoing requests

    // Hold-to-start-ride feature state
    const [isHolding, setIsHolding] = useState(false);
    const holdTimeoutRef = useRef<number | null>(null);
    const wasHoldSuccessfulRef = useRef(false);
    const progressRingRef = useRef<SVGCircleElement | null>(null);
    const HOLD_DURATION = 1500; // 1.5 seconds

    const hasUnreadMessages = useMemo(() => {
        return CONVERSATIONS.some(c => !c.lastMessage.isRead && c.lastMessage.sender.id !== CURRENT_USER.id);
    }, []);
    
    const friendsAndMe = useMemo(() => [CURRENT_USER.id, ...friends], [friends]);
    const feedForDashboard = useMemo(() => feedItems.filter(item => friendsAndMe.includes(item.data.user.id)), [feedItems, friendsAndMe]);

    const handleUserSelect = (userId: string) => {
        if (userId === CURRENT_USER.id) {
            setViewedProfileId(null);
            setActiveView('profile');
        } else {
            setViewedProfileId(userId);
        }
    }

    const handleAddPost = (newPost: Post) => {
        const newFeedItem: FeedItem = { type: 'post', data: newPost };
        setFeedItems(prevItems => [newFeedItem, ...prevItems]);
    };

    const handleAddFriend = (userId: string) => {
        if (!sentRequests.includes(userId)) {
            setSentRequests([...sentRequests, userId]);
            // In a real app, this would be an API call
        }
    };
    
    const handleAcceptRequest = (userId: string) => {
        setFriends(prev => [...prev, userId]);
        setFriendRequests(prev => prev.filter(req => req.from.id !== userId));
    };

    const handleDeclineRequest = (userId: string) => {
        setFriendRequests(prev => prev.filter(req => req.from.id !== userId));
    };

    // --- Hold-to-Start Logic ---
    const handleHoldStart = () => {
        wasHoldSuccessfulRef.current = false;
        setIsHolding(true);
        
        if (progressRingRef.current) {
            progressRingRef.current.style.transition = `stroke-dashoffset ${HOLD_DURATION}ms linear`;
            progressRingRef.current.style.strokeDashoffset = '0';
        }

        holdTimeoutRef.current = window.setTimeout(() => {
            setIsHolding(false);
            if (showCreateMenu) setShowCreateMenu(false);
            setShowGps(true);
            wasHoldSuccessfulRef.current = true;
            if (progressRingRef.current) {
                progressRingRef.current.style.transition = 'none';
                progressRingRef.current.style.strokeDashoffset = '264';
            }
        }, HOLD_DURATION);
    };

    const handleHoldEnd = () => {
        setIsHolding(false);
        if (holdTimeoutRef.current) {
            clearTimeout(holdTimeoutRef.current);
            holdTimeoutRef.current = null;
        }
        if (progressRingRef.current) {
            progressRingRef.current.style.transition = 'stroke-dashoffset 0.2s ease-out';
            progressRingRef.current.style.strokeDashoffset = '264';
        }
    };
    
    const handleButtonClick = () => {
        setTimeout(() => {
            if (!wasHoldSuccessfulRef.current) {
                setShowCreateMenu(prev => !prev);
            }
            wasHoldSuccessfulRef.current = false;
        }, 50); // Small delay to prevent menu opening on failed hold release
    };
    
    const renderView = () => {
        const dashboardProps = {
            onShowShots: () => setActiveView('shots'),
            onShowStreams: () => setActiveView('streams'),
            onShowClubs: () => setActiveView('clubs'),
            onUserSelect: handleUserSelect,
            activityMode: activityMode,
            setActivityMode: setActivityMode,
            onShowRideStory: setSelectedRideStory,
            feedItems: feedForDashboard,
            onShowGps: () => setShowGps(true),
            onShowGame: () => setShowGame(true),
            onOpenGamification: () => setShowGamificationHub(true),
            onOpenExpeditions: () => setActiveView('expeditions'),
            onOpenRadar: () => setActiveView('radar'),
            onOpenBudget: () => setShowBudgetModal(true),
            onOpenStoryStudio: () => setShowStoryStudio(true),
            onOpenArchitecture: () => setShowArchitectureModal(true),
            language: language,
        };

        switch (activeView) {
            case 'home':
                return <Dashboard {...dashboardProps} />;
            case 'expeditions':
                return <IndiaExpeditions language={language} onOpenSos={() => setActiveView('radar')} />;
            case 'radar':
                return <IndiaRoadsideRadar language={language} />;
            case 'streams':
                return <StreamsPanel onStreamSelect={setSelectedStream} />;
            case 'shots':
                return null; // Rendered as a full-screen panel at the top level
            case 'clubs':
                return <ClubPanel onUserSelect={handleUserSelect} />;
            case 'leaderboards':
                return <LeaderboardsPanel onUserSelect={handleUserSelect} />;
            case 'messages':
                return <MessagesPanel />;
            case 'notifications':
                return <NotificationsPanel />;
            case 'profile':
                return <ProfilePanel onUserSelect={handleUserSelect} friends={friends} friendRequests={friendRequests} sentRequests={sentRequests} onAddFriend={handleAddFriend} onAcceptRequest={handleAcceptRequest}/>;
            default:
                return <Dashboard {...dashboardProps} />;
        }
    };

    const NavItem: React.FC<{ view: View; icon: React.ReactNode; label: string; notification?: boolean; }> = ({ view, icon, label, notification }) => (
        <button onClick={() => { setViewedProfileId(null); setActiveView(view); }} className={`flex flex-col items-center justify-center space-y-1 w-full transition-colors ${activeView === view && !viewedProfileId ? 'text-orange-500' : 'text-gray-400 hover:text-white'}`}>
            <div className="relative">
                {icon}
                {notification && <span className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4 block h-2 w-2 rounded-full bg-red-500 ring-1 ring-slate-900" />}
            </div>
            <span className="text-xs font-medium">{label}</span>
        </button>
    );

    const currentLangLabel = SUPPORTED_LANGUAGES.find(l => l.code === language)?.nativeName || 'English';

    const mainContent = (
        <div className="bg-slate-950 text-gray-100 min-h-screen font-sans">
             <header className="fixed top-0 left-0 right-0 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 h-16 z-40 flex items-center justify-between px-3 md:px-5">
                <div className="flex items-center space-x-3">
                    <button onClick={() => { setViewedProfileId(null); setActiveView('home'); }} className="flex items-center space-x-2 group" aria-label="Go to Home page">
                        <LogoIcon className="w-8 h-8 text-orange-500 transition-transform group-hover:scale-110" />
                        <div>
                            <h1 className="text-lg md:text-xl font-bold text-white tracking-tight group-hover:text-orange-400 transition-colors">
                                {getTranslation('app_title', language)}
                            </h1>
                        </div>
                    </button>

                    {/* Nav link pills for Expeditions and Radar */}
                    <div className="hidden lg:flex items-center space-x-1.5 ml-3">
                        <button
                            onClick={() => { setViewedProfileId(null); setActiveView('expeditions'); }}
                            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                                activeView === 'expeditions'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                            }`}
                        >
                            <CompassIcon className="w-3.5 h-3.5 text-amber-400" />
                            <span>{getTranslation('nav_expeditions', language)}</span>
                        </button>

                        <button
                            onClick={() => { setViewedProfileId(null); setActiveView('radar'); }}
                            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                                activeView === 'radar'
                                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/50'
                                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                            }`}
                        >
                            <ShieldAlertIcon className="w-3.5 h-3.5 text-rose-400" />
                            <span>{getTranslation('nav_radar', language)}</span>
                        </button>
                    </div>
                </div>

                <div className="flex items-center space-x-2">
                    {/* Multilingual Selector */}
                    <div className="relative">
                        <button
                            onClick={() => setShowLangMenu(!showLangMenu)}
                            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-full bg-slate-800/90 border border-slate-700 hover:border-amber-400 text-xs font-medium text-slate-200 transition-all shadow-sm"
                            title="Switch Language"
                        >
                            <TranslateIcon className="w-3.5 h-3.5 text-amber-400" />
                            <span className="hidden sm:inline">{currentLangLabel}</span>
                        </button>

                        {showLangMenu && (
                            <div className="absolute right-0 mt-2 w-36 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-50 animate-fadeIn">
                                {SUPPORTED_LANGUAGES.map(lang => (
                                    <button
                                        key={lang.code}
                                        onClick={() => {
                                            setLanguage(lang.code);
                                            setShowLangMenu(false);
                                        }}
                                        className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                                            language === lang.code
                                                ? 'bg-amber-500/20 text-amber-300 font-bold'
                                                : 'text-slate-300 hover:bg-slate-800'
                                        }`}
                                    >
                                        <span>{lang.nativeName}</span>
                                        {language === lang.code && <span className="text-amber-400 text-xs">✓</span>}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Architecture Blueprint Modal Trigger */}
                    <button
                        onClick={() => setShowArchitectureModal(true)}
                        className="hidden md:flex items-center space-x-1 px-2.5 py-1.5 rounded-full bg-slate-800 border border-slate-700 hover:border-cyan-400 text-cyan-300 text-xs font-semibold transition-all shadow-sm"
                        title="System Architecture & Sequence Blueprint"
                    >
                        <ArchitectureIcon className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="hidden xl:inline">Blueprint</span>
                    </button>

                    {/* Trip Budget Modal Trigger */}
                    <button
                        onClick={() => setShowBudgetModal(true)}
                        className="hidden sm:flex items-center space-x-1 px-2.5 py-1.5 rounded-full bg-slate-800 border border-slate-700 hover:border-emerald-400 text-emerald-300 text-xs font-semibold transition-all shadow-sm"
                        title="Trip Expense & FASTag Splitter"
                    >
                        <RupeeIcon className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Budget</span>
                    </button>

                    {/* AI Story Studio Modal Trigger */}
                    <button
                        onClick={() => setShowStoryStudio(true)}
                        className="hidden sm:flex items-center space-x-1 px-2.5 py-1.5 rounded-full bg-slate-800 border border-slate-700 hover:border-fuchsia-400 text-fuchsia-300 text-xs font-semibold transition-all shadow-sm"
                        title="Live Helmet Stream & AI Reel"
                    >
                        <SparklesIcon className="w-3.5 h-3.5 text-fuchsia-400" />
                        <span>Studio</span>
                    </button>

                    {/* Rider Level & Streak Badge */}
                    <button
                        onClick={() => setShowGamificationHub(true)}
                        className="flex items-center space-x-1 px-2.5 py-1.5 rounded-full bg-slate-800 border border-slate-700 hover:border-orange-500 text-xs font-mono font-bold transition-all shadow-sm"
                        aria-label="Open Gamification Hub"
                        title="Rider Level & Quests"
                    >
                        <FlameIcon className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-white">L{riderGamification.level}</span>
                    </button>

                    <button
                        onClick={() => setShowGame(true)}
                        className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-orange-600/20 border border-orange-500/40 text-orange-400 hover:bg-orange-600 hover:text-white transition-all text-xs font-bold"
                        aria-label="Play Apex Moto 3D Arcade"
                    >
                        <GamepadIcon className="w-4 h-4" />
                        <span className="hidden md:inline">3D Arcade</span>
                    </button>
                    <button 
                        onClick={() => setShowFriendsPanel(true)}
                        className="relative p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
                        aria-label="Friend Requests"
                    >
                        <UsersIcon className="w-6 h-6" />
                        {friendRequests.length > 0 && <span className="absolute top-1 right-1 transform translate-x-1/4 -translate-y-1/4 block h-2 w-2 rounded-full bg-red-500 ring-1 ring-slate-900" />}
                    </button>
                    <button 
                        onClick={() => setActiveView('notifications')} 
                        className="relative p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
                        aria-label="Notifications"
                    >
                        <NotificationIcon className="w-6 h-6" />
                        <span className="absolute top-1 right-1 transform translate-x-1/4 -translate-y-1/4 block h-2 w-2 rounded-full bg-red-500 ring-1 ring-slate-900" />
                    </button>
                    <button 
                        onClick={() => setActiveView('messages')} 
                        className="relative p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
                        aria-label="Messages"
                    >
                        <MessageIcon className="w-6 h-6" />
                        {hasUnreadMessages && <span className="absolute top-1 right-1 transform translate-x-1/4 -translate-y-1/4 block h-2 w-2 rounded-full bg-red-500 ring-1 ring-slate-900" />}
                    </button>
                    <button 
                        onClick={() => { setViewedProfileId(null); setActiveView('profile'); }} 
                        className="ml-2"
                        aria-label="My Profile"
                    >
                        <img 
                            src={CURRENT_USER.avatarUrl} 
                            alt="My Profile" 
                            className="w-8 h-8 rounded-full border-2 border-slate-700 hover:border-orange-500 transition-colors"
                        />
                    </button>
                </div>
            </header>

            <main className="container mx-auto px-4 pt-20 md:pt-24 pb-20">
                {!viewedProfileId && renderView()}
            </main>

            {/* Bottom Nav - All screens */}
            <nav className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 flex items-center justify-around h-20 z-40">
                <NavItem view="home" label="Home" icon={<HomeIcon className="w-6 h-6"/>} />
                <NavItem view="streams" label="Streams" icon={<StreamIcon className="w-6 h-6"/>} />
                <NavItem view="shots" label="Shorts" icon={<ShortsIcon className="w-6 h-6"/>} />
                <NavItem view="clubs" label="Clubs" icon={<ClubIcon className="w-6 h-6"/>} />
                <NavItem view="leaderboards" label="Leaders" icon={<TrophyIcon className="w-6 h-6"/>} />
                
                {/* Central button taken out of flow and centered */}
                <div className="absolute left-1/2 top-0 -translate-x-1/2">
                    <div className="relative flex justify-center">
                        <svg className="absolute w-24 h-24 pointer-events-none" style={{ top: '-4.625rem', transform: 'rotate(-90deg)' }} viewBox="0 0 100 100">
                            <circle
                                ref={progressRingRef}
                                cx="50"
                                cy="50"
                                r="42"
                                stroke="#ea580c"
                                strokeWidth="5"
                                fill="transparent"
                                strokeDasharray="264"
                                strokeDashoffset="264"
                            />
                        </svg>

                        <button
                            onClick={handleButtonClick}
                            onMouseDown={handleHoldStart}
                            onMouseUp={handleHoldEnd}
                            onMouseLeave={handleHoldEnd}
                            onTouchStart={handleHoldStart}
                            onTouchEnd={handleHoldEnd}
                            className={`bg-orange-600 rounded-full p-4 -mt-14 shadow-lg shadow-orange-900/50 hover:bg-orange-700 transition-all duration-200 relative z-10 no-select ${isHolding ? 'scale-110' : ''}`}
                            aria-label="Create new content or hold to start a ride"
                        >
                            <LogoIcon className="w-7 h-7 text-white"/>
                        </button>
                        {showCreateMenu && (
                            <div className="absolute bottom-full mb-10 w-48 bg-slate-800 rounded-lg shadow-lg p-2 animate-fade-in left-1/2 -translate-x-1/2">
                                <button 
                                    onClick={() => { setShowCreatePost(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <PencilIcon className="w-5 h-5 text-blue-400"/>
                                    <span>Create Post</span>
                                </button>
                                <button 
                                    onClick={() => { setShowJourneyPlanner(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <RouteIcon className="w-5 h-5 text-orange-400"/>
                                    <span>AI Journey Planner</span>
                                </button>
                                <button 
                                    onClick={() => { setShowGps(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <MapPinIcon className="w-5 h-5 text-green-400" />
                                    <span>Start GPS Ride</span>
                                </button>
                                <button 
                                    onClick={() => { setShowGame(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <GamepadIcon className="w-5 h-5 text-purple-400" />
                                    <span>Play Apex 3D</span>
                                </button>
                                <button 
                                    onClick={() => { setShowGamificationHub(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <TrophyIcon className="w-5 h-5 text-amber-400" />
                                    <span>Gamification Hub</span>
                                </button>
                                <button 
                                    onClick={() => { setActiveView('expeditions'); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <CompassIcon className="w-5 h-5 text-amber-400" />
                                    <span>Himalayan Routes</span>
                                </button>
                                <button 
                                    onClick={() => { setActiveView('radar'); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <ShieldAlertIcon className="w-5 h-5 text-rose-400" />
                                    <span>Road Radar & 112 SOS</span>
                                </button>
                                <button 
                                    onClick={() => { setShowBudgetModal(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <RupeeIcon className="w-5 h-5 text-cyan-400" />
                                    <span>Trip Budget (₹)</span>
                                </button>
                                <button 
                                    onClick={() => { setShowStoryStudio(true); setShowCreateMenu(false); }}
                                    className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-slate-700 text-left text-gray-200"
                                >
                                    <SparklesIcon className="w-5 h-5 text-fuchsia-400" />
                                    <span>AI Story Studio</span>
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </nav>
        </div>
    );

    if (showGame) {
        return (
            <ApexMotoGame
                onExit={() => setShowGame(false)}
                onShareToFeed={handleShareGameRun}
            />
        );
    }

    return (
        <>
            {mainContent}
            {selectedStream && <StreamViewer stream={selectedStream} onBack={() => setSelectedStream(null)} />}
            {selectedRideStory && <RideStory story={selectedRideStory} onBack={() => setSelectedRideStory(null)} />}
            {viewedProfileId && <ProfilePanel profileId={viewedProfileId} onBack={() => setViewedProfileId(null)} onUserSelect={handleUserSelect} friends={friends} friendRequests={friendRequests} sentRequests={sentRequests} onAddFriend={handleAddFriend} onAcceptRequest={handleAcceptRequest}/>}
            {activeView === 'shots' && <ShotsPanel onBack={() => setActiveView('home')} onUserSelect={handleUserSelect} />}
            {showGps && <GpsTracker onBack={() => setShowGps(false)} />}
            {showCreatePost && <CreatePost onAddPost={handleAddPost} onBack={() => setShowCreatePost(false)} />}
            {showJourneyPlanner && <JourneyPlanner onBack={() => setShowJourneyPlanner(false)} activityMode={activityMode} />}
            {showFriendsPanel && <FriendRequestsPanel onBack={() => setShowFriendsPanel(false)} onUserSelect={handleUserSelect} requests={friendRequests} friends={friends} onAccept={handleAcceptRequest} onDecline={handleDeclineRequest} />}
            {showGamificationHub && (
                <GamificationHub
                    onClose={() => setShowGamificationHub(false)}
                    onStartGame={() => {
                        setShowGamificationHub(false);
                        setShowGame(true);
                    }}
                />
            )}
            {showArchitectureModal && (
                <ArchitectureModal onClose={() => setShowArchitectureModal(false)} />
            )}
            {showBudgetModal && (
                <TripBudgetModal language={language} onClose={() => setShowBudgetModal(false)} />
            )}
            {showStoryStudio && (
                <AiStoryStudioModal language={language} onClose={() => setShowStoryStudio(false)} />
            )}
        </>
    );
};

export default App;
