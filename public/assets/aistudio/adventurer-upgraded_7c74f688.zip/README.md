# Adventurer — Ride community + RideStory AI

A React + TypeScript prototype for adventure riders, with India-focused expeditions, route planning, community features, gamification, roadside assistance concepts, and an AI Ride Studio.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the URL printed by Vite (normally `http://localhost:3000`).

## New in this upgrade

- Local ride-video selection and browser preview in AI Ride Studio.
- Ride title, location, target story length, and narration-language controls.
- A visible draft highlight timeline and downloadable JSON edit decision list (EDL).
- Copyable travel-story caption for sharing.
- Clear local-first messaging: selecting a video does not upload it or start a live broadcast.
- Removed the bundled `.env.local` file from the delivery archive; use server-side secrets for any provider API.

## Important prototype boundaries

- The highlight timeline currently samples candidate time windows evenly. It is **not** AI scene recognition, and it does not render a finished video file. Connect a server-side video-understanding model and a media-rendering worker (for example FFmpeg) to make this production-grade.
- The live-stream screen is a UI concept, not a real broadcast pipeline. Production live streaming needs authenticated ingest, transcoding, playback delivery, moderation, and consent/privacy controls.
- AI provider credentials must remain on the server. Do not place provider keys in `VITE_*` variables or commit `.env.local`.
- Route, weather, safety, location, and health information shown in sample screens may be illustrative. Do not rely on demo content for real-world safety decisions.

## Suggested production integration

1. Add authenticated server endpoints for route generation, story generation, and video-analysis jobs.
2. Store uploaded media in private object storage using short-lived signed upload URLs.
3. Queue long-running analysis/render jobs and return job status to the client.
4. Run scene detection, model-based scene ranking, face/license-plate blurring, caption/narration generation, and FFmpeg rendering server-side.
5. Add deletion controls, retention policies, per-ride visibility, and moderation before public sharing.
