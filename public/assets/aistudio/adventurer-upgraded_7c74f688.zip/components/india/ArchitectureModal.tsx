import React, { useState } from 'react';
import { ArchitectureIcon, XIcon, ShieldAlertIcon, SparklesIcon, RouteIcon, CheckIcon, PlayIcon } from '../icons';

interface ArchitectureModalProps {
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'topology' | 'services' | 'sequences' | 'security'>('topology');
  const [simulatingSequence, setSimulatingSequence] = useState<'sos' | 'stream' | 'story' | null>(null);
  const [sequenceStep, setSequenceStep] = useState<number>(0);

  const startSequence = (seq: 'sos' | 'stream' | 'story') => {
    setSimulatingSequence(seq);
    setSequenceStep(1);

    const interval = setInterval(() => {
      setSequenceStep(prev => {
        if (prev >= 4) {
          clearInterval(interval);
          return 4;
        }
        return prev + 1;
      });
    }, 1100);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full p-6 shadow-2xl space-y-6 my-6 animate-fadeIn text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <ArchitectureIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white tracking-tight">
                  Apex Moto System Architecture & Sequence Blueprint
                </h2>
                <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 font-mono px-2 py-0.5 rounded font-bold uppercase">
                  Production Grade
                </span>
              </div>
              <p className="text-slate-400 text-xs">
                Line-by-line microservices topology, telemetry ingest broker, Gemini 3.8 Flash pipeline, and emergency SOS state machines.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 border border-slate-700 hover:border-slate-600 transition-colors"
          >
            <XIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('topology')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'topology'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            High-Level Topology (SVG)
          </button>
          <button
            onClick={() => setActiveTab('services')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'services'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            Line-by-Line Service Specs
          </button>
          <button
            onClick={() => setActiveTab('sequences')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'sequences'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            Interactive Sequence Simulators
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'security'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            Zero-Network & Offline-First CRDT
          </button>
        </div>

        {/* Tab 1: High Level SVG Topology */}
        {activeTab === 'topology' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 relative overflow-hidden">
              <div className="text-center mb-4">
                <span className="text-[11px] font-mono text-amber-400 uppercase tracking-widest font-bold">
                  Apex Moto Distributed Cloud & Edge Architecture
                </span>
              </div>

              {/* SVG Topology Diagram */}
              <div className="w-full flex justify-center py-2">
                <svg viewBox="0 0 860 380" className="w-full max-w-4xl text-xs font-mono select-none">
                  <defs>
                    <linearGradient id="gradAmber" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#d97706" stopOpacity="0.8" />
                    </linearGradient>
                    <linearGradient id="gradCyan" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#0891b2" stopOpacity="0.8" />
                    </linearGradient>
                    <linearGradient id="gradRose" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#e11d48" stopOpacity="0.8" />
                    </linearGradient>
                  </defs>

                  {/* Layer 1: Edge & Client Tier */}
                  <g>
                    <rect x="20" y="20" width="820" height="70" rx="12" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
                    <text x="40" y="44" fill="#94a3b8" fontWeight="bold" fontSize="11">TIER 1: EDGE CLIENTS & SENSORS</text>
                    <rect x="180" y="32" width="130" height="42" rx="8" fill="#1e293b" stroke="#f59e0b" strokeWidth="1.2" />
                    <text x="195" y="52" fill="#f8fafc" fontWeight="bold" fontSize="10">Mobile PWA / React</text>
                    <text x="195" y="65" fill="#f59e0b" fontSize="8">IndexedDB / GPS Sensor</text>

                    <rect x="330" y="32" width="130" height="42" rx="8" fill="#1e293b" stroke="#06b6d4" strokeWidth="1.2" />
                    <text x="345" y="52" fill="#f8fafc" fontWeight="bold" fontSize="10">Helmet HUD / BLE</text>
                    <text x="345" y="65" fill="#06b6d4" fontSize="8">Lean / Pulse / Cam</text>

                    <rect x="480" y="32" width="130" height="42" rx="8" fill="#1e293b" stroke="#f43f5e" strokeWidth="1.2" />
                    <text x="495" y="52" fill="#f8fafc" fontWeight="bold" fontSize="10">Emergency 112 Beacon</text>
                    <text x="495" y="65" fill="#f43f5e" fontSize="8">Satellite / SMS Fallback</text>

                    <rect x="630" y="32" width="130" height="42" rx="8" fill="#1e293b" stroke="#10b981" strokeWidth="1.2" />
                    <text x="645" y="52" fill="#f8fafc" fontWeight="bold" fontSize="10">3D Canyon Engine</text>
                    <text x="645" y="65" fill="#10b981" fontSize="8">Three.js WebGL Audio</text>
                  </g>

                  {/* Connectors */}
                  <path d="M 245 90 L 245 130" stroke="#f59e0b" strokeWidth="2" strokeDasharray="4 2" />
                  <path d="M 395 90 L 395 130" stroke="#06b6d4" strokeWidth="2" strokeDasharray="4 2" />
                  <path d="M 545 90 L 545 130" stroke="#f43f5e" strokeWidth="2" strokeDasharray="4 2" />
                  <path d="M 695 90 L 695 130" stroke="#10b981" strokeWidth="2" strokeDasharray="4 2" />

                  {/* Layer 2: Ingest & API Gateway */}
                  <g>
                    <rect x="20" y="130" width="820" height="70" rx="12" fill="#0b1329" stroke="#38bdf8" strokeWidth="1.5" />
                    <text x="40" y="154" fill="#38bdf8" fontWeight="bold" fontSize="11">TIER 2: REAL-TIME INGESTION GATEWAY</text>

                    <rect x="200" y="142" width="180" height="42" rx="8" fill="#1e293b" stroke="#38bdf8" strokeWidth="1.2" />
                    <text x="215" y="162" fill="#f8fafc" fontWeight="bold" fontSize="10">WebSocket / MQTT Broker</text>
                    <text x="215" y="175" fill="#94a3b8" fontSize="8">1Hz GPS Telemetry Ingest</text>

                    <rect x="420" y="142" width="180" height="42" rx="8" fill="#1e293b" stroke="#a855f7" strokeWidth="1.2" />
                    <text x="435" y="162" fill="#f8fafc" fontWeight="bold" fontSize="10">REST & GraphQL Gateway</text>
                    <text x="435" y="175" fill="#94a3b8" fontSize="8">Auth & Rate-Limiting</text>
                  </g>

                  {/* Connectors */}
                  <path d="M 290 200 L 290 240" stroke="#38bdf8" strokeWidth="2" />
                  <path d="M 510 200 L 510 240" stroke="#a855f7" strokeWidth="2" />

                  {/* Layer 3: Microservices Tier */}
                  <g>
                    <rect x="20" y="240" width="820" height="70" rx="12" fill="#0f172a" stroke="#64748b" strokeWidth="1.5" />
                    <text x="40" y="264" fill="#94a3b8" fontWeight="bold" fontSize="11">TIER 3: SPECIALIZED MICROSERVICES</text>

                    <rect x="180" y="252" width="140" height="44" rx="8" fill="#1e293b" stroke="#f43f5e" strokeWidth="1.2" />
                    <text x="190" y="270" fill="#f8fafc" fontWeight="bold" fontSize="9">112 SOS Dispatcher</text>
                    <text x="190" y="284" fill="#f43f5e" fontSize="8">Geofence / SMS Alert</text>

                    <rect x="340" y="252" width="140" height="44" rx="8" fill="#1e293b" stroke="#f59e0b" strokeWidth="1.2" />
                    <text x="350" y="270" fill="#f8fafc" fontWeight="bold" fontSize="9">Gemini 3.8 AI Engine</text>
                    <text x="350" y="284" fill="#f59e0b" fontSize="8">Highlights & Narration</text>

                    <rect x="500" y="252" width="140" height="44" rx="8" fill="#1e293b" stroke="#10b981" strokeWidth="1.2" />
                    <text x="510" y="270" fill="#f8fafc" fontWeight="bold" fontSize="9">Gamification Engine</text>
                    <text x="510" y="284" fill="#10b981" fontSize="8">XP, Streaks & Anti-Cheat</text>

                    <rect x="660" y="252" width="140" height="44" rx="8" fill="#1e293b" stroke="#06b6d4" strokeWidth="1.2" />
                    <text x="670" y="270" fill="#f8fafc" fontWeight="bold" fontSize="9">Trip Split (UPI 2.0)</text>
                    <text x="670" y="284" fill="#06b6d4" fontSize="8">Tolls & Dhaba Balancer</text>
                  </g>

                  {/* Connectors */}
                  <path d="M 430 310 L 430 330" stroke="#64748b" strokeWidth="2" />

                  {/* Layer 4: Storage */}
                  <g>
                    <rect x="150" y="330" width="560" height="38" rx="8" fill="#020617" stroke="#475569" strokeWidth="1.2" />
                    <text x="180" y="354" fill="#cbd5e1" fontWeight="bold" fontSize="10">PERSISTENCE: Firestore / TimescaleDB (GPS telemetry) • Redis Cache • GCS Media</text>
                  </g>
                </svg>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-amber-400 font-bold block mb-1">Latency SLA</span>
                <p className="text-slate-400">&lt;250ms GPS packet broadcast to convoy members via WebSockets.</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-rose-400 font-bold block mb-1">112 Dispatch SLA</span>
                <p className="text-slate-400">&lt;2.0s SMS & satellite burst to police/medical grid in mountain zones.</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-cyan-400 font-bold block mb-1">AI Video Pipeline</span>
                <p className="text-slate-400">Gemini 3.8 Flash extracts multi-modal highlights in &lt;3.5s per day run.</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Line by line specs */}
        {activeTab === 'services' && (
          <div className="space-y-3">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                    <th className="py-2.5 px-3">Service Name</th>
                    <th className="py-2.5 px-3">Protocol / Tech</th>
                    <th className="py-2.5 px-3">Key Responsibility</th>
                    <th className="py-2.5 px-3">Failover & Redundancy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  <tr className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-bold text-amber-400">gps-telemetry-broker</td>
                    <td className="py-3 px-3 text-slate-300">MQTT over WSS (1Hz)</td>
                    <td className="py-3 px-3 text-slate-300 font-sans">
                      Ingests lat/long, altitude, lean angle, heart rate; dead-reckoning Kalman filter.
                    </td>
                    <td className="py-3 px-3 text-emerald-400 font-sans">Local IndexedDB batch on disconnect</td>
                  </tr>

                  <tr className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-bold text-rose-400">emergency-sos-orchestrator</td>
                    <td className="py-3 px-3 text-slate-300">gRPC + Webhooks</td>
                    <td className="py-3 px-3 text-slate-300 font-sans">
                      Dispatches SOS coordinates, blood type, and bike model to 112 emergency grid and 15km geofence.
                    </td>
                    <td className="py-3 px-3 text-emerald-400 font-sans">SMS GSM fallback + satellite transponder</td>
                  </tr>

                  <tr className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-bold text-cyan-400">gemini-story-synthesizer</td>
                    <td className="py-3 px-3 text-slate-300">@google/genai (3.8-flash)</td>
                    <td className="py-3 px-3 text-slate-300 font-sans">
                      Curates summit photos, detects peak lean angles, writes multilingual travel diaries and voice scripts.
                    </td>
                    <td className="py-3 px-3 text-emerald-400 font-sans">Deterministic template fallback generator</td>
                  </tr>

                  <tr className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-bold text-emerald-400">gamification-xp-ledger</td>
                    <td className="py-3 px-3 text-slate-300">Distributed Counter + CRDT</td>
                    <td className="py-3 px-3 text-slate-300 font-sans">
                      Tracks Rider Rank 1-50, XP per km, streak multipliers, anti-spoof speed validation (capped at 160km/h).
                    </td>
                    <td className="py-3 px-3 text-emerald-400 font-sans">Cryptographic HMAC GPS sign</td>
                  </tr>

                  <tr className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-bold text-purple-400">upi-trip-ledger</td>
                    <td className="py-3 px-3 text-slate-300">NPCI UPI 2.0 Spec</td>
                    <td className="py-3 px-3 text-slate-300 font-sans">
                      Splits fuel, FASTag tolls, dhaba chai stops, generates deep-link payment QR codes per rider.
                    </td>
                    <td className="py-3 px-3 text-emerald-400 font-sans">Idempotent split hashing</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Interactive Sequence Simulators */}
        {activeTab === 'sequences' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => startSequence('sos')}
                className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <PlayIcon className="w-3.5 h-3.5" />
                <span>Simulate: 112 Emergency SOS Trigger</span>
              </button>

              <button
                onClick={() => startSequence('stream')}
                className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5"
              >
                <PlayIcon className="w-3.5 h-3.5" />
                <span>Simulate: Helmet HUD Live Go-Live</span>
              </button>

              <button
                onClick={() => startSequence('story')}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
              >
                <PlayIcon className="w-3.5 h-3.5" />
                <span>Simulate: AI Highlight Reel Extraction</span>
              </button>
            </div>

            {/* Simulation Execution Log */}
            {simulatingSequence ? (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400">
                  <span>SEQUENCE: {simulatingSequence.toUpperCase()} STATE MACHINE</span>
                  <span className="text-amber-400">{sequenceStep}/4 STEPS EXECUTED</span>
                </div>

                <div className="space-y-2">
                  <div
                    className={`p-2.5 rounded-lg border transition-all ${
                      sequenceStep >= 1 ? 'bg-slate-900 border-amber-500/60 text-slate-200' : 'opacity-40 border-slate-800'
                    }`}
                  >
                    <span className="text-amber-400 font-bold mr-2">[STEP 1]</span>
                    {simulatingSequence === 'sos' && 'Client button pressed -> Locks GPS Lat/Lng (34.1526, 77.5771, Alt 17,982ft) & Blood Group (O+ve).'}
                    {simulatingSequence === 'stream' && 'BLE connects to helmet HUD -> Negotiates 1080p60 WebRTC peer connection to Edge Media Relay.'}
                    {simulatingSequence === 'story' && 'Ride finished -> Queries 1,240 km GPS log for peak elevation, max lean angle & photo tags.'}
                  </div>

                  <div
                    className={`p-2.5 rounded-lg border transition-all ${
                      sequenceStep >= 2 ? 'bg-slate-900 border-amber-500/60 text-slate-200' : 'opacity-40 border-slate-800'
                    }`}
                  >
                    <span className="text-amber-400 font-bold mr-2">[STEP 2]</span>
                    {simulatingSequence === 'sos' && 'Emergency Broker dispatches webhook to National 112 Gateway + sends geofenced MQTT alerts to 4 convoys within 15km.'}
                    {simulatingSequence === 'stream' && 'Edge Media Relay provisions low-latency HLS pipeline (1.2s glass-to-glass latency).'}
                    {simulatingSequence === 'story' && 'Gemini 3.8 Flash ingests multimodal timeline -> Generates cinematic narrative in Hindi/English.'}
                  </div>

                  <div
                    className={`p-2.5 rounded-lg border transition-all ${
                      sequenceStep >= 3 ? 'bg-slate-900 border-amber-500/60 text-slate-200' : 'opacity-40 border-slate-800'
                    }`}
                  >
                    <span className="text-amber-400 font-bold mr-2">[STEP 3]</span>
                    {simulatingSequence === 'sos' && 'Nearest certified mechanic (Sardarji Bullet Works, 2.4km) alerted with tools payload.'}
                    {simulatingSequence === 'stream' && 'Subscribers receive telemetry overlay (speed, lean angle, heart rate, altitude) in sync with video frames.'}
                    {simulatingSequence === 'story' && 'Auto-crops 9:16 vertical video reel with telemetry stamp and prayer flag summit badge.'}
                  </div>

                  <div
                    className={`p-2.5 rounded-lg border transition-all ${
                      sequenceStep >= 4 ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200' : 'opacity-40 border-slate-800'
                    }`}
                  >
                    <span className="text-emerald-400 font-bold mr-2">[COMPLETED]</span>
                    {simulatingSequence === 'sos' && 'SOS Beacon active. Live telemetry stream streaming to emergency operators.'}
                    {simulatingSequence === 'stream' && 'Stream active at 4,800 kbps. 840+ viewers connected with live cheers.'}
                    {simulatingSequence === 'story' && 'AI Travel Diary compiled, saved to profile, and published to rider community feed.'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center rounded-2xl bg-slate-950/50 border border-dashed border-slate-800 text-slate-400 text-xs">
                Click any simulator button above to watch the distributed sequence execute in real time.
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Security & Zero Network */}
        {activeTab === 'security' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-emerald-400 font-bold uppercase text-[10px] block">
                  Zero-Network Valley Synchronization (CRDT)
                </span>
                <h4 className="text-white font-bold text-sm">Conflict-Free Replicated Data Types</h4>
                <p className="text-slate-400 leading-relaxed">
                  In high Himalayan valleys (Zanskar, Spiti, Changthang) with zero cellular coverage, peer nodes exchange Bluetooth Low Energy (BLE) gossip packets. When any convoy rider re-enters 4G/5G signal, state reconciles automatically without merge conflicts.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-rose-400 font-bold uppercase text-[10px] block">
                  Women Rider Safety Architecture
                </span>
                <h4 className="text-white font-bold text-sm">Ephemeral Location Masking & Geofenced Safe Stays</h4>
                <p className="text-slate-400 leading-relaxed">
                  Female solo riders can enable 500m fuzzy location obfuscation for public feeds while maintaining 100% precision with trusted contacts and 112 emergency grid. Safe stays are verified by community audits and CCTV coverage.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
