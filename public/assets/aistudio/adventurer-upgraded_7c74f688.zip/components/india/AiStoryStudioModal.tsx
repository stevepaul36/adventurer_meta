import React, { useEffect, useMemo, useState } from 'react';
import { SparklesIcon, XIcon, PlayIcon, ShareIcon, CameraIcon, CheckIcon, MapPinIcon } from '../icons';
import type { SupportedLanguage } from '../../services/i18nService';

interface AiStoryStudioModalProps {
  language: SupportedLanguage;
  onClose: () => void;
}

export const AiStoryStudioModal: React.FC<AiStoryStudioModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'stream' | 'highlights' | 'diary'>('stream');
  const [isPlaying, setIsPlaying] = useState(true);
  const [viewersCount, setViewersCount] = useState(842);
  const [reactionsCount, setReactionsCount] = useState(2450);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiCaption, setAiCaption] = useState(
    '“Riding through the jagged clouds of Khardung La at 17,982 ft. The Himalayan 450 purred against the thin oxygen as prayer flags whipped in the high wind. A ride not just across mountains, but into the soul.”'
  );
  const [copiedShare, setCopiedShare] = useState(false);
  const [sourceVideo, setSourceVideo] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState(0);
  const [targetMinutes, setTargetMinutes] = useState(2);
  const [tripLocation, setTripLocation] = useState('Western Ghats, India');
  const [storyLanguage, setStoryLanguage] = useState('English');
  const [editPlanReady, setEditPlanReady] = useState(false);
  const [storyTitle, setStoryTitle] = useState('My ride, my story');

  useEffect(() => {
    if (!sourceVideo) { setVideoUrl(null); return; }
    const url = URL.createObjectURL(sourceVideo);
    setVideoUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [sourceVideo]);

  const highlightSegments = useMemo(() => {
    if (!videoDuration) return [];
    const count = Math.max(3, Math.min(8, Math.round(targetMinutes * 2)));
    const clipLength = Math.max(5, Math.min(18, (targetMinutes * 60) / count));
    return Array.from({ length: count }, (_, index) => {
      const center = videoDuration * ((index + 0.5) / count);
      const start = Math.max(0, Math.min(videoDuration - 1, center - clipLength / 2));
      const end = Math.min(videoDuration, start + clipLength);
      return { index: index + 1, start: Math.round(start), end: Math.round(end), duration: Math.max(1, Math.round(end - start)) };
    });
  }, [videoDuration, targetMinutes]);

  const formatTime = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

  const downloadEditPlan = () => {
    const plan = {
      product: 'RideStory AI',
      sourceFile: sourceVideo?.name ?? null,
      sourceDurationSeconds: videoDuration,
      targetDurationSeconds: targetMinutes * 60,
      location: tripLocation,
      language: storyLanguage,
      title: storyTitle,
      note: 'Draft edit decision list. Segment selection is evenly sampled, not AI scene recognition. Connect a video-analysis model and media renderer for production highlights.',
      segments: highlightSegments,
      caption: `${storyTitle} — ${tripLocation}. ${aiCaption.replace(/[“”]/g, '')}`
    };
    const blob = new Blob([JSON.stringify(plan, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'ridestory-edit-plan.json';
    anchor.click();
    URL.revokeObjectURL(url);
    setEditPlanReady(true);
  };

  const copyStoryCaption = async () => {
    const caption = `${storyTitle} — ${tripLocation}. ${aiCaption.replace(/[“”]/g, '')}`;
    try {
      await navigator.clipboard.writeText(caption);
      setCopiedShare(true);
      window.setTimeout(() => setCopiedShare(false), 2500);
    } catch {
      setCopiedShare(false);
    }
  };

  const handleSimulateAiCaption = () => {
    setAiGenerating(true);
    window.setTimeout(() => {
      const location = tripLocation.trim() || 'the open road';
      const title = storyTitle.trim() || 'A ride to remember';
      setAiCaption(`“${title} — a journey through ${location}. From winding roads to unexpected viewpoints, this ride is a reminder to explore thoughtfully, ride safely, and leave room for the moments that make the journey memorable.”`);
      setAiGenerating(false);
    }, 250);
  };

  const handleSendReaction = () => {
    setReactionsCount(prev => prev + 1);
    setViewersCount(prev => prev + Math.floor(Math.random() * 3));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full p-6 shadow-2xl space-y-6 my-6 animate-fadeIn text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-slate-950 font-bold shadow-lg">
              <SparklesIcon className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>AI Ride Studio & 24x7 Live Stream Hub</span>
                <span className="bg-rose-950 text-rose-300 text-[10px] font-bold px-2 py-0.5 rounded border border-rose-800 uppercase animate-pulse">
                  Live
                </span>
              </h2>
              <p className="text-slate-400 text-xs">
                Live-stream concept, source-video preview, and a downloadable highlight edit plan. Live broadcast and model-backed scene analysis need backend integration.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 border border-slate-700 hover:border-slate-600 transition-colors"
          >
            <XIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('stream')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'stream'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            Helmet HUD Live (1080p60)
          </button>
          <button
            onClick={() => setActiveTab('highlights')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'highlights'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            AI Highlight Reel
          </button>
          <button
            onClick={() => setActiveTab('diary')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'diary'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
            }`}
          >
            Shareable Travel Diary
          </button>
        </div>

        {/* Real source-media workspace: local-first, no upload without consent */}
        <section className="rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-950/30 to-slate-950 p-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-400">Creator workspace · local preview</p>
              <h3 className="text-base font-bold text-white mt-1">Turn a long ride into a shareable story</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl">Choose a video from your device, preview it, and create a downloadable edit plan. Your video stays in this browser in this prototype; no upload or live broadcast starts automatically.</p>
            </div>
            <label className="shrink-0 cursor-pointer rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400">
              {sourceVideo ? 'Replace video' : 'Choose ride video'}
              <input type="file" accept="video/*" className="hidden" onChange={event => {
                const file = event.currentTarget.files?.[0];
                if (file) { setSourceVideo(file); setVideoDuration(0); setEditPlanReady(false); }
                event.currentTarget.value = '';
              }} />
            </label>
          </div>
          {videoUrl && (
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
              <div className="lg:col-span-3">
                <video src={videoUrl} controls playsInline className="w-full max-h-72 rounded-xl bg-black" onLoadedMetadata={event => setVideoDuration(Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration : 0)} />
                <p className="text-[11px] text-slate-400 mt-2 break-all">{sourceVideo?.name} · {sourceVideo ? (sourceVideo.size / (1024 * 1024)).toFixed(1) : '0'} MB {videoDuration > 0 ? `· ${formatTime(videoDuration)} total` : '· reading duration…'}</p>
              </div>
              <div className="lg:col-span-2 grid grid-cols-1 gap-3 content-start">
                <label className="text-xs text-slate-300">Story title<input value={storyTitle} onChange={e => setStoryTitle(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" /></label>
                <label className="text-xs text-slate-300">Ride location<input value={tripLocation} onChange={e => setTripLocation(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white" /></label>
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs text-slate-300">Target length<select value={targetMinutes} onChange={e => { setTargetMinutes(Number(e.target.value)); setEditPlanReady(false); }} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-sm text-white"><option value={0.5}>30 sec</option><option value={1}>1 min</option><option value={2}>2 min</option><option value={3}>3 min</option></select></label>
                  <label className="text-xs text-slate-300">Narration language<select value={storyLanguage} onChange={e => setStoryLanguage(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-sm text-white"><option>English</option><option>Hindi</option><option>Tamil</option><option>Marathi</option><option>Bengali</option></select></label>
                </div>
                <button onClick={downloadEditPlan} disabled={!videoDuration || highlightSegments.length === 0} className="rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-extrabold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40 hover:bg-amber-400">Create & download edit plan</button>
                {editPlanReady && <p role="status" className="text-xs text-emerald-300">Edit plan downloaded. Clip times are a starter edit list, not AI-detected scenes.</p>}
              </div>
            </div>
          )}
          {!sourceVideo && <div className="rounded-xl border border-dashed border-slate-700 bg-slate-900/60 p-5 text-center"><p className="text-sm text-slate-300">No video selected yet</p><p className="text-xs text-slate-500 mt-1">Supports browser-playable video formats. Large files may take time to load.</p></div>}
          {sourceVideo && videoDuration > 0 && <div className="space-y-2"><div className="flex items-center justify-between"><span className="text-xs font-bold text-slate-300">Draft highlight timeline</span><span className="text-[10px] text-amber-300">{highlightSegments.length} candidate segments</span></div><div className="flex gap-1 h-3">{highlightSegments.map(segment => <div key={segment.index} title={`${formatTime(segment.start)}–${formatTime(segment.end)}`} className="rounded-sm bg-amber-400/80 border border-amber-200/30" style={{ width: `${100 / highlightSegments.length}%` }} />)}</div><div className="grid grid-cols-2 sm:grid-cols-4 gap-2">{highlightSegments.map(segment => <div key={segment.index} className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-2"><span className="block text-[10px] text-amber-300 font-bold">CLIP {segment.index}</span><span className="text-xs text-slate-200">{formatTime(segment.start)}–{formatTime(segment.end)}</span></div>)}</div></div>}
        </section>

        {/* Tab 1: Live Helmet Stream HUD */}
        {activeTab === 'stream' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Stream Video Player Simulation */}
            <div className="lg:col-span-8 space-y-3">
              <div className="relative aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-xl group">
                <img
                  src="https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1200&q=80"
                  alt="Helmet Cam Stream"
                  className="w-full h-full object-cover opacity-90"
                />

                {/* Live HUD Overlay */}
                <div className="absolute inset-0 p-4 flex flex-col justify-between pointer-events-none">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="bg-rose-600 text-white font-bold text-[10px] px-2 py-0.5 rounded uppercase tracking-wider animate-pulse">
                        LIVE
                      </span>
                      <span className="bg-black/60 backdrop-blur-md text-white text-xs px-2 py-0.5 rounded font-mono">
                        {viewersCount.toLocaleString()} Viewers
                      </span>
                    </div>

                    <div className="bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-[11px] font-mono text-amber-300">
                      ALT: 17,982 FT • KHARDUNG LA
                    </div>
                  </div>

                  {/* Telemetry bottom gauges */}
                  <div className="grid grid-cols-4 gap-2 bg-black/60 backdrop-blur-md p-2.5 rounded-xl border border-white/10 text-center font-mono">
                    <div>
                      <span className="text-[9px] text-slate-400 block">SPEED</span>
                      <span className="text-sm font-bold text-emerald-400">72 KM/H</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 block">LEAN</span>
                      <span className="text-sm font-bold text-amber-400">32° L</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 block">O2 SAT</span>
                      <span className="text-sm font-bold text-rose-400">88%</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 block">HEART</span>
                      <span className="text-sm font-bold text-cyan-400">124 BPM</span>
                    </div>
                  </div>
                </div>

                {/* Play/Pause overlay */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30 pointer-events-auto">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-md border border-white/40 flex items-center justify-center text-white hover:scale-110 transition-transform"
                  >
                    <PlayIcon className="w-6 h-6 ml-0.5" />
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
                  <span>Bitrate: 4,800 kbps</span>
                  <span>•</span>
                  <span>Audio: Wind-filtered stereo</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSendReaction}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-semibold border border-slate-700 flex items-center gap-1.5 transition-all"
                  >
                    <span>🔥 Cheer Convoy</span>
                    <span className="text-slate-300 font-mono text-[11px]">({reactionsCount})</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Live Chat & Convoy Radio */}
            <div className="lg:col-span-4 bg-slate-950/80 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between h-80 lg:h-auto">
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
                  <span className="font-bold text-slate-300">Live Convoy Radio & Chat</span>
                  <span className="text-[10px] text-emerald-400 font-mono">Encrypted P2P</span>
                </div>

                <div className="space-y-2.5 mt-3 text-xs overflow-y-auto max-h-56 pr-1">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-amber-400 block text-[11px]">Lead Rider Vikram:</span>
                    <span className="text-slate-300">"Watch for black ice on the shadow bend before North Pullu!"</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-cyan-400 block text-[11px]">Mechanic Rajinder:</span>
                    <span className="text-slate-300">"Bike #3 chain looks good at last halt. Carrying spare tubes."</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="font-bold text-fuchsia-400 block text-[11px]">Viewer Rohit_Delhi:</span>
                    <span className="text-slate-300">"Incredible view bhai! Ride safe through Pagal Nallah 🔥"</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex gap-2">
                <input
                  type="text"
                  placeholder="Send cheer or convoy note..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  onClick={handleSendReaction}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: AI Highlight Reel */}
        {activeTab === 'highlights' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-white text-base">Highlight Reel Planner</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Plan a short edit from your source footage. True scene understanding and rendered clips require a connected video-analysis model and media-processing backend.
                </p>
              </div>

              <button
                onClick={handleSimulateAiCaption}
                disabled={aiGenerating}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/20"
              >
                <SparklesIcon className="w-4 h-4" />
                <span>{aiGenerating ? 'Analyzing Footage...' : 'Draft Story Caption'}</span>
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80">
              <span className="text-[10px] uppercase font-bold text-amber-400 block mb-1">
                Story Caption Draft
              </span>
              <p className="text-sm italic text-slate-200 leading-relaxed font-serif">
                {aiCaption}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=600&q=80"
                  alt="Highlight 1"
                  className="w-full h-32 object-cover"
                />
                <div className="p-3">
                  <span className="text-[10px] text-amber-400 font-bold">MOMENT 1 • 0:14</span>
                  <h4 className="text-xs font-bold text-white mt-0.5">Summit at Khardung La Top</h4>
                  <span className="text-[10px] text-slate-400">Peak G-Force: 1.4G</span>
                </div>
              </div>

              <div className="rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80"
                  alt="Highlight 2"
                  className="w-full h-32 object-cover"
                />
                <div className="p-3">
                  <span className="text-[10px] text-cyan-400 font-bold">MOMENT 2 • 0:38</span>
                  <h4 className="text-xs font-bold text-white mt-0.5">Glacial Stream Water Crossing</h4>
                  <span className="text-[10px] text-slate-400">Water Depth: 1.2 ft</span>
                </div>
              </div>

              <div className="rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80"
                  alt="Highlight 3"
                  className="w-full h-32 object-cover"
                />
                <div className="p-3">
                  <span className="text-[10px] text-emerald-400 font-bold">MOMENT 3 • 1:04</span>
                  <h4 className="text-xs font-bold text-white mt-0.5">Sunset at Spiti Canyon Edge</h4>
                  <span className="text-[10px] text-slate-400">Lean Angle: 36°</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Shareable Travel Diary */}
        {activeTab === 'diary' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                    Official Expedition Log
                  </span>
                  <h3 className="text-lg font-black text-white">Trans-Himalayan Odyssey 2026</h3>
                </div>
                <div className="text-right text-xs">
                  <span className="text-slate-400 block text-[10px]">VERIFIED MILEAGE</span>
                  <span className="font-bold text-emerald-400">1,240 KM COMPLETE</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {aiCaption}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs pt-2 border-t border-slate-800">
                <div className="p-2 rounded bg-slate-900/60">
                  <span className="text-[9px] text-slate-500 block">PEAK ALTITUDE</span>
                  <span className="font-bold text-white">19,024 FT</span>
                </div>
                <div className="p-2 rounded bg-slate-900/60">
                  <span className="text-[9px] text-slate-500 block">PASSES CROSSED</span>
                  <span className="font-bold text-white">5 High Passes</span>
                </div>
                <div className="p-2 rounded bg-slate-900/60">
                  <span className="text-[9px] text-slate-500 block">HAIRPIN TURNS</span>
                  <span className="font-bold text-white">182 Turns</span>
                </div>
                <div className="p-2 rounded bg-slate-900/60">
                  <span className="text-[9px] text-slate-500 block">CREW MEMBERS</span>
                  <span className="font-bold text-white">4 Certified</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={copyStoryCaption}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/20"
              >
                {copiedShare ? <CheckIcon className="w-4 h-4" /> : <ShareIcon className="w-4 h-4" />}
                <span>{copiedShare ? 'Caption copied!' : 'Copy travel story caption'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
