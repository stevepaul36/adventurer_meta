# Adventurer UI/UX Concept Pack

- `prototype.html` — responsive multi-screen concept, open locally in a modern desktop/mobile browser.
- `workflow.md` — product design intent, screens, primary workflows, privacy/accessibility rules, boundaries and implementation order.
- `adventurer_uiux_workflow_reference.pdf` — source reference supplied by the product owner (kept separately; not copied into this concept pack).

All imagery/route graphics in the concept are original vector illustrations, not scraped product screenshots. Interactions are a prototype only.
