# Adventurer — Original UI/UX Direction & Workflow

**Status:** Design reference and interactive concept only. This does not replace the native Android app or enable any backend integrations.

## Design intent

Adventurer is a multi-activity adventure companion. The main product loop is **Discover → Plan → Prepare → Go & record → Reflect → Share by choice**. Social features should support the adventure rather than dictate the navigation or visual identity. The concept uses a dark field-notes palette, warm orange action colour, quiet mint state colour, large outdoor imagery, topographic line patterns and route-chapter language. These are broad visual cues for outdoor utility, not a reproduction of any social network interface.

## Screens and purpose

1. **Basecamp / Home** — a concise launchpad with three jobs: create an adventure, enter field mode, or shape a trip memory. A resume card exposes the saved plan, incomplete checklist and draft state.
2. **Field Atlas / Explore** — search, activity filters, a map candidate visualization and route cards. Map lines and route estimates must be labelled as sample/unverified until a real map/routing data source supplies them.
3. **Route Brief** — route chapters/stops, distance/time estimates, prep checklist and explicit next actions. Users can save the plan or enter field mode without being forced into recording.
4. **Field Mode** — low-distraction active session with Ready, Active, Paused and Finished states. Only glanceable controls. Missing sensors are marked unavailable rather than fabricated. Clearly disclose the demo state, location state and actual SOS/connectivity status.
5. **Story Studio** — pick an artifact format (route journal, short film, photo essay or trip guide), tone, editable title and caption, audience, route masking and delayed location.
6. **Final Review** — preview current edits and summarise audience, location exposure and media permission. The final action remains disabled until all three checkboxes are explicitly confirmed.
7. **Trail Settings** — multi-activity preferences, voice guidance behaviour, quiet hours, feed mood and a plain-language privacy check-up.

## Primary workflows

### A. Discover an adventure
`Basecamp → Field Atlas → Search / Filter → Route card → Route Brief → Save trip or Use plan → Field Mode`

Success criteria: a new user can find a candidate, identify whether the information is sample or source-backed, inspect its chapters, and understand that starting a session is a separate choice.

### B. Record a field session and make a story
`Basecamp → Field Mode → Start → Pause / Resume → Finish → Story Studio → Edit → Final Review → Confirm demo`

Production requirement: active, paused and finished states must be unambiguous. The finished trip should supply real recorded segments and selected moments; the concept timer and distance are simulated.

### C. Share deliberately
`Story Studio → Select format and tone → Edit title/caption → Choose audience → Mask route start/end → Delay location → Final Review → 3 required confirmations → Save/Publish`

The prototype's final action only confirms the local demo. Production publish must be server-authenticated, enforce audience/privacy settings, handle upload consent/retention and provide a clear result/error. Default audience is private.

## Design system proposal

- **Surface:** near-black navy (#0A1119), layered slate panels (#111D28, #162532), border #263844.
- **Action:** warm orange (#FF8B43); use for the main next step, selected navigation and map-route accent only.
- **Secondary state:** soft mint (#A8DFC4) for completion/private status; red is reserved for genuine warnings or danger states.
- **Typography:** strong, compressed-feeling headline hierarchy; readable system sans-serif body text; uppercase micro-labels only for secondary metadata.
- **Shape:** 10–16 px functional cards, restrained outlines, clear 44 dp+ native touch targets, no decorative card stacks for every line of content.
- **Imagery:** original/appropriately licensed adventure images; use original terrain diagrams as placeholders. Do not extract and reuse a competitor's screenshots, illustrations, icons, map styling, typography pairing or branded assets.
- **Navigation:** five destinations max in mobile primary navigation; Basecamp, Discover, Field, Studio and Me. Deeper route editing remains within its parent journey.

## Key interaction and accessibility rules

- Make screen titles, current mode and primary action clear without relying on colour alone.
- Use high-contrast text and large touch areas suitable for outside and gloves; never encourage riders to use complex controls while moving.
- Use actual Android content descriptions, focus order, scalable font units and TalkBack labels when implementing natively.
- Do not rely on swipe-only gestures for finish/publish/destructive actions.
- Map routes, source freshness, access status and risk reports need explicit source and recency. Candidate UI must not imply verified route access.
- User controls exact-coordinate exposure, history, sharing audience, voice/microphone activation, and media uploads.
- No fabricated speed, altitude, GPS track, emergency dispatch, contact alert, route booking, or public publishing.

## Prototype boundaries

The HTML is a standalone browser concept with local illustrative sample data. It does not access GPS, call route APIs, upload media, sign users in, message a trusted contact, publish content, or activate SOS. It is not a Kotlin/Jetpack Compose implementation and it does not change the app automatically.

## Suggested usability validation

Test with 3–5 people. Ask them to (1) find and save a route, (2) inspect route uncertainty and preparation steps, (3) start, pause and finish a demo field session, (4) produce a playful story draft, (5) mask a route and delay location, and (6) complete the review gate. Record completion, hesitation, labels misunderstood, privacy controls missed and any mistaken assumption that a demo function is connected. Fix high-friction moments before migrating patterns to Compose.

## Implementation order

**Phase 1 — Foundations:** compose theme/tokens, typography, buttons, input styles, navigation semantics, state models and accessibility pass.

**Phase 2 — Planning:** connect Basecamp to the existing Explore & Plan/Room model, route cards, itinerary editor, checklist and clear source status.

**Phase 3 — Field mode:** implement explicit session state machine against the existing recorder; distinguish sensor validity from placeholders; test lifecycle/process death and permission denial.

**Phase 4 — Story:** connect selected trip segments/media to the existing Story Studio workflow; preserve editability; show upload consent and local-export paths.

**Phase 5 — Publish/privacy:** implement a typed share draft and preview; enforce 3 confirmations, route masking, audience choices and server-side access policy. Add integration tests before claiming it is live.

**Phase 6 — Evaluate:** usability testing, accessibility, physical-device field testing and release checklist. Design completeness alone is not production readiness.
